const CACHE_NAME = 'app-cache-v1';

self.addEventListener('install', (event) => {
  self.skipWaiting(); // ngay lập tức activate
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.map(key => caches.delete(key))) // xóa toàn bộ cache cũ
    )
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  const url = new URL(event.request.url);

  // Chỉ xử lý file tĩnh: .js, .css, .png, ...
  if (/\.(js|css|png|jpg|jpeg|svg|woff2?|ttf|eot|json|html)$/.test(url.pathname)) {
    event.respondWith(
      caches.match(event.request).then(cached => {
        const fetchAndCache = fetch(event.request).then(response => {
          return caches.open(CACHE_NAME).then(cache => {
            cache.put(event.request, response.clone());
            return response;
          });
        });
        return cached || fetchAndCache;
      })
    );
  }
});
