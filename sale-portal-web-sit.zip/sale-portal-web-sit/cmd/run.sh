#!/usr/bin/env sh

set -e

exec nginx -g 'daemon off;'
