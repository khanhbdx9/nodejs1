#!/usr/bin/env sh

set -e

buildEnv=$1

case ${buildEnv} in
  "sit")
    buildTarget="build:sit"
    ;;
  "uat")
    buildTarget="build:uat"
    ;;
  "staging")
    buildTarget="build:staging"
    ;;
  *)
    echo "Not supported to build env: ${buildEnv}"
    exit 1
    ;;
esac

npm run ${buildTarget}
