/* eslint-disable no-undef */
import react from "@vitejs/plugin-react-swc";
import { fileURLToPath, URL } from "url";
// import viteImagemin from 'vite-plugin-imagemin'
import { defineConfig, transformWithEsbuild, loadEnv } from "vite";
import dynamicImport from "vite-plugin-dynamic-import";
import viteSvgr from "vite-plugin-svgr";

import * as viteHelper from "./internals/helpers";
import * as viteOption from "./internals/vite";
import packageJson from "./package.json";

export default ({ mode }) => {
  const options = viteOption[mode] || {};
  loadEnv(mode, process.cwd(), "");

  return defineConfig({
    define: {
      "import.meta.env.VERSION": JSON.stringify(packageJson.version), // Inject version vào môi trường
    },
    plugins: [
      react(),
      dynamicImport(),
      viteSvgr({
        svgo: true, // auto resize svg
        svgrOptions: {
          plugins: ["@svgr/plugin-svgo", "@svgr/plugin-jsx"],
          svgoConfig: {
            floatPrecision: 2,
          },
        },
      }),
      // viteImagemin({
      //   verbose: true,
      //   gifsicle: {
      //     optimizationLevel: 3,
      //   },
      //   optipng: {
      //     optimizationLevel: 5,
      //   },
      //   mozjpeg: {
      //     quality: 75,
      //   },
      //   pngquant: {
      //     quality: [0.65, 0.80],
      //     speed: 4,
      //   },
      //   webp: {
      //     quality: 75,
      //   },
      //   svgo: {
      //     plugins: [
      //       { removeTitle: true },
      //       { convertShapeToPath: true },
      //       { removeEmptyAttrs: true },
      //       { removeViewBox: false },
      //     ],
      //   },
      // }),
      // {
      //   name: "treat-js-files-as-jsx",
      //   async transform(code, id) {
      //     if (!id.match(/src\/.*\.js$/)) return null;
      //     const { transformWithEsbuild } = await import("vite");
      //     return transformWithEsbuild(code, id, {
      //       loader: "jsx",
      //       jsx: "automatic",
      //     });
      //   },
      // },
      {
        name: "treat-js-files-as-jsx",
        async transform(code, id) {
          if (!id.match(/app\/.*\.js$/)) return null;

          // Use the exposed transform from vite, instead of directly
          // transforming with esbuild
          return transformWithEsbuild(code, id, {
            loader: "jsx",
            jsx: "automatic",
          });
        },
      },
      ...options.plugins,
    ],
    base: "/theo-doi-ho-so/",
    envDir: "./internals/env",
    resolve: {
      alias: [
        ...Object.entries(
          viteHelper.createAliases(
            fileURLToPath(new URL("./app", import.meta.url))
          )
        ).map(([find, replacement]) => ({
          find,
          replacement,
        })),
      ],
    },
    server: {
      port: 5504,
    },
    optimizeDeps: {
      include: [
        "moment",
        "@mui/material",
        "@mui/icons-material",
        "@mui/system",
        "@mui/lab",
        "@mui/base",
      ],
      esbuildOptions: {
        loader: {
          ".js": "jsx",
        },
      },
    },
    build: {
      outDir: "build/theo-doi-ho-so",
      minify: "esbuild",
      ...options.build,
      rollupOptions: {
        output: {
          manualChunks: {
            vendor: ["react", "react-dom"],
            ui: [
              "@mui/material",
              "@mui/icons-material",
              "@mui/system",
              "@mui/lab",
              "@mui/base",
            ],
          },
          entryFileNames: ({ name }) => {
            const nameNew = name.replaceAll(/[^a-zA-Z0-9_]/g, "_");
            const hash = viteHelper.getHash().replaceAll(/[^a-zA-Z0-9_]/g, "_");
            const ver = String(packageJson.version || "").replaceAll(
              /[^a-zA-Z0-9_]/g,
              "_"
            );

            return `js/js${nameNew}.${hash}.${ver}.js`;
          },
          chunkFileNames: ({ name }) => {
            const nameNew = name.replaceAll(/[^a-zA-Z0-9_]/g, "_");
            const hash = viteHelper.getHash().replaceAll(/[^a-zA-Z0-9_]/g, "_");
            const ver = String(packageJson.version || "").replaceAll(
              /[^a-zA-Z0-9_]/g,
              "_"
            );

            return `js/js${nameNew}.${hash}.${ver}.js`;
          },
          assetFileNames: ({ name }) => {
            const nameNew = name.replaceAll(/[^a-zA-Z0-9_]/g, "_");
            const hash = viteHelper.getHash().replaceAll(/[^a-zA-Z0-9_]/g, "_");

            return `assets/ass${nameNew}.${hash}.[ext]`;
          },
        },
        ...options.build.rollupOptions,
      },
    },
  });
};
