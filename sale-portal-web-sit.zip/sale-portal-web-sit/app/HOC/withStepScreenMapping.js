import NewFeature from '@components/NewFeature';
import PropTypes from 'prop-types';
import { useMemo } from 'react';

/**
 * HOC ánh xạ productType và screen sang component tương ứng từ MAPPING_SCREEN
 * @param {Object} MAPPING_SCREEN - Cấu trúc ánh xạ màn hình theo sản phẩm và bước
 * @returns {React.Component} - Component được ánh xạ hoặc fallback nếu không tìm thấy
 */
const withStepScreenMapping = (MAPPING_SCREEN, pageName) => {
  function StepScreen({ productType = 'CC', screen, ...props }) {
    const ResolvedComponent = useMemo(() => {
      if (!screen) return MAPPING_SCREEN.LOADING;

      const productMapping = MAPPING_SCREEN[productType];
      const ComponentByProduct = productMapping?.[screen];
      const ComponentGlobal = MAPPING_SCREEN[screen];

      const FinalComponent = ComponentByProduct || ComponentGlobal;

      if (!FinalComponent) {
        return () => (
          <NewFeature
            title="Không tìm thấy bước phù hợp"
            dest={`Bước ${screen} tại màn hình ${pageName} không tồn tại cho sản phẩm ${productType}`}
          />
        );
      }

      return FinalComponent;
    }, [screen, productType]);

    return <ResolvedComponent {...props} />;
  }

  StepScreen.propTypes = {
    productType: PropTypes.string,
    screen: PropTypes.string,
  };

  return StepScreen;
};

export default withStepScreenMapping;
