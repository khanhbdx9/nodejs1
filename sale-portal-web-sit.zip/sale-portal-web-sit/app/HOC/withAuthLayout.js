// import MainLayout from '@layouts/MainLayout';
// import ROUTE from '@routers/constants';
// import authService from '@utils/services/authService';
// import { Navigate } from 'react-router-dom';

// /**
//  * Higher-Order Function dùng để kiểm tra đăng nhập
//  * Nếu đã đăng nhập → bọc component trong MainLayout
//  * Nếu chưa đăng nhập → chuyển hướng về trang Login
//  *
//  * @param {React.ComponentType} Component - Component cần bảo vệ
//  * @returns {JSX.Element} - JSX đã xử lý xác thực và layout
//  */
// const withAuthLayout = (Component) => {
//   const isUserAuthenticated = authService.isAuthenticated();

//   if (isUserAuthenticated) {
//     return (
//       <MainLayout>
//         <Component />
//       </MainLayout>
//     );
//   }

//   return <Navigate to={ROUTE.common.Login} replace />;
// };

// export default withAuthLayout;
