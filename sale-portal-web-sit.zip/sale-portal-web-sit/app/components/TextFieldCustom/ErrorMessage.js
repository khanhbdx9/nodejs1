import PropTypes from "prop-types";

import { ErrorMessageStyle } from "./styled";

const ErrorMessage = ({ errorMessage, errorStyle }) =>
  errorMessage ? (
    <ErrorMessageStyle style={errorStyle}>{errorMessage}</ErrorMessageStyle>
  ) : null;

ErrorMessage.propTypes = {
  errorStyle: PropTypes.object,
  errorMessage: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.bool
  ]),
};

export default ErrorMessage;
