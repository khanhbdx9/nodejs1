import styled from "styled-components";

const Wrapper = styled.div`
  display: ${({ $isHiddenInput }) => ($isHiddenInput ? "none" : "block")};

  .MuiInputBase-root {
    border-radius: 8px;

    &:hover {
      .MuiOutlinedInput-notchedOutline {
        border-color: ${(p) => p.theme.colors.lightGreen};
      }
    }

    &.Mui-focused {
      .MuiOutlinedInput-notchedOutline {
        border: 1px solid ${(p) => p.theme.colors.lightGreen};
      }
    }

    .MuiOutlinedInput-notchedOutline {
      border: 1px solid
        ${({ $error, theme }) => ($error ? theme.colors.red : theme.colors.shade0)};
    }

    input {
      padding: 15px 14px;
      font-weight: 500;
      color: ${({theme}) => theme.colors.darkBlue};
      font-size: 16px;
    }
  }

  .rootInput {
    width: 100%;
    height: 48px;
    .MuiOutlinedInput-root {
      &:hover {
        .MuiOutlinedInput-notchedOutline {
          border-color: #00b74f;
        }
      }
      &.Mui-focused {
        .MuiOutlinedInput-notchedOutline {
          border: 1px solid ${(p) => p.theme.colors.lightGreen};
        }
      }

      .MuiOutlinedInput-notchedOutline {
        border: 1px solid #f2f4f8;
      }

      .MuiOutlinedInput-input {
        color: #092f51;
        padding: 13px 12px;
        font-size: 16px;
        font-weight: 600;
        line-height: 22px;
      }
    }

    .Mui-error {
      &.MuiFormHelperText-contained {
        color: ${({theme}) => theme.colors.red};
        font-size: 11px;
        margin-left: 11px;
        margin-right: 11px;
        font-family: "SVN-Gilroy";
      }

      .MuiOutlinedInput-notchedOutline {
        border-color: #f50700cf !important;
      }
    }
  }
`;

export const ErrorMessageStyle = styled.span`
  font-weight: 300;
  line-height: 1.2;
  font-size: 12px;
  padding: 0 12px;
  color: ${(p) => p.theme.colors.red};
`;

export default Wrapper;
