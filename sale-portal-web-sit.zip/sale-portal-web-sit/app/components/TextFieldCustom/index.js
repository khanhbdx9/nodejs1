import { Text } from '@components/Styled/Title';
import TextField from "@mui/material/TextField";
import VPB_COLOR from '@ThemeProvider/colors'
import PropTypes from "prop-types";
import { forwardRef } from "react";

import ErrorMessage from "./ErrorMessage";
import WrapperTextFieldCustom from "./styled";


const TextFieldCustom = forwardRef(function MyInput(
  {
    label,
    key,
    placeholder,
    defaultValue,
    classNameWrap,
    disabled = false,
    isHiddenInput = false,
    errorMessage,
    errorStyle = {},
    ...props
  },
  ref
) {
  return (
    <WrapperTextFieldCustom
      $isHiddenInput={isHiddenInput}
      $error={errorMessage}
      className={classNameWrap}
    >
      {label && (
        <Text className="txtLabel" $size={14} $color={errorMessage ? VPB_COLOR.red : VPB_COLOR.neutral}>{label}</Text>
      )}
      <TextField
        inputRef={ref}
        className="rootInput"
        placeholder={placeholder || label}
        defaultValue={defaultValue}
        disabled={disabled}
        key={key || "ILD"}
        variant="outlined"
        {...props}
      />
      <ErrorMessage errorMessage={errorMessage} errorStyle={errorStyle} />
    </WrapperTextFieldCustom>
  );
});

TextFieldCustom.propTypes = {
  removeIcon: PropTypes.any,
  text: PropTypes.string,
  label: PropTypes.string,
  placeholder: PropTypes.string,
  classNameWrap: PropTypes.string,
  defaultValue: PropTypes.string,
  key: PropTypes.string,
  onChange: PropTypes.func,
  disabled: PropTypes.any,
  errorStyle: PropTypes.object,
  isHiddenInput: PropTypes.bool,
  errorMessage: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.bool
  ]),
};

export default TextFieldCustom;
