import styled from 'styled-components';

const SalesSupportCardContainer = styled.div`
  display: grid;
  gap: 16px;
  min-width: 320px;
  text-align: center;
  @media ${({theme})=>theme.breakpoints.tablet} {
    gap: 16px;
  }

  .MuiListItemText-primary {
    text-align: left;
  }
`;

export { SalesSupportCardContainer }
