import AppButton from "@components/AppButton";
import AppImage from '@components/AppImage';
import { ListItemDetail, GroupBox } from "@components/Detail";
import { Title, Text } from "@components/Styled/Title";
import VPB_COLOR from '@ThemeProvider/colors';
import { redirectListApplication } from '@utils/redirect'
import PropTypes from 'prop-types';

import { SalesSupportCardContainer } from './Styled'

const SalesSupportCard = ({ 
  image,
  title, 
  desc,
  saleFullName, 
  salePhoneNumber, 
  titleSaleBox,
  isBtnBottom = true,
  content,
}) => {

  return (
    <SalesSupportCardContainer className='__cardContainer'>
      <AppImage src={image} height={160} width={160} styleWrap={{ margin: 'auto' }}/>
      
      <Title $align='center' $size={24}> {title} </Title>

      <Text $align='center' color={VPB_COLOR.neutral}> {desc} </Text>

      <GroupBox
        title={titleSaleBox}
        contentPadding="0px 16px 0px"
      >
        {Array.isArray(content) ? 
          content.map(_c => (
            <ListItemDetail key={`${_c?.name}-${_c?.field}`} {..._c}/>
          )) 
          :
          (
            <>
              <ListItemDetail primary="Họ & tên nhân viên" secondary={saleFullName} hideBorder style={{ textAlign: 'left' }}/>
              <ListItemDetail
                isIconTel
                enableCopy
                primary="Số điện thoại"
                secondary={salePhoneNumber}
              />
            </>
          )
        }
        
      </GroupBox>

      <Text 
        $align='center' 
        $color={VPB_COLOR.neutral} 
        className="__cardContainer___respectfully" 
      > 
        Trân trọng! 
      </Text>

      {
        isBtnBottom && (
          <AppButton 
            label='Danh sách hồ sơ' 
            variant='outlined'
            onClick={redirectListApplication}
          />
        )
      }
      
    </SalesSupportCardContainer>
  )
}

SalesSupportCard.propTypes = {
  image: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  desc: PropTypes.string,
  saleFullName: PropTypes.string,
  salePhoneNumber: PropTypes.string,
  titleSaleBox: PropTypes.string,
  isBtnBottom: PropTypes.bool,
  content: PropTypes.array,
};

export default SalesSupportCard;