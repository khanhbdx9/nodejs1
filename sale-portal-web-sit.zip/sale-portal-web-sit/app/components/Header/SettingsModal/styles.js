import styled from "styled-components";
import { HEADER_HEIGHT, HEADER_HEIGHT_MOBILE } from "../constants";

export const SettingsModalContainer = styled.div`
  position: absolute;
  width: 393px;
  padding: 16px 0px;
  background-color: white;
  box-shadow: 0px 4px 16px 0px #00000029;
  top: ${HEADER_HEIGHT}px;
  left: 0px;
  display: flex;
  flex-direction: column;
  gap: 16px;
  @media ${(p) => p.theme.breakpoints.mobile} {
    top: ${HEADER_HEIGHT_MOBILE}px;
    height: calc(100vh - ${HEADER_HEIGHT_MOBILE}px);
    box-shadow: unset;
  }

  .userInformation {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;

    .avatar {
      width: 71px;
      height: 71px;
      background-color: #cad3da;
      border-radius: 100px;
      border: 5px solid #e9edf1;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .faceAuthentication {
      display: flex;
      align-items: center;
      gap: 2px;
      border-radius: 4px;
      padding: 6px;
      background: #d7eaff;
      color: ${(p) => p.theme.colors.neutral};

      span {
        font-weight: 500;
        font-size: 12px;
        line-height: 100%;
        letter-spacing: 0%;
      }
    }
  }

  .menu {
    padding: 16px;
    display: flex;
    flex-direction: column;
    gap: 8px;

    .item {
      height: 56px;
      padding: 16px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border: 1px solid #f2f4f8;
      border-radius: 6px;
      cursor: pointer;

      .itemName {
        gap: 8px;
        display: flex;
        align-items: center;
      }
    }
  }
`;
