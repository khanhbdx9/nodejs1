import React from "react";
import {
  IcShield,
  IcFolder,
  IcPercentage,
  IcLogout,
  IcArrowRight,
} from "@assets/icons";
import { SettingsModalContainer } from "./styles";
import ROUTE from "@routers/constants";
import history from "@utils/history";
import PropTypes from "prop-types";
import get from "lodash/get";
import { getCustomerInitials } from "@utils/helpers";

const MENU_OPTIONS = [
  // {
  //   name: "Quản lý hồ sơ",
  //   icon: IcFolder,
  //   url: "",
  // },
  // {
  //   name: "Công cụ tính lãi",
  //   icon: IcPercentage,
  //   url: "",
  // },
  {
    name: "Đăng xuất",
    icon: IcLogout,
    url: ROUTE.common.Login,
  },
];

export default function SettingsModal({ open, userInfo }) {
  return (
    <SettingsModalContainer style={{ display: open ? "block" : "none" }}>
      <div className="userInformation">
        <div className="avatar">
          <span>{getCustomerInitials(get(userInfo, "mainUsername", "mainUsername"))}</span>
        </div>
        <span className="name">{get(userInfo, "mainUsername", "mainUsername")}</span>
        <div className="faceAuthentication">
          <img src={IcShield} />
          <span>Đã xác thực sinh trắc học</span>
        </div>
      </div>
      <div className="menu">
        {MENU_OPTIONS.map((item) => {
          return (
            <div
              className="item"
              key={item.name}
              onClick={() => {
                history.push(item.url);
              }}
            >
              <div className="itemName">
                <img src={item.icon} />
                <span>{item.name}</span>
              </div>
              <img src={IcArrowRight} />
            </div>
          );
        })}
      </div>
    </SettingsModalContainer>
  );
}

SettingsModal.propTypes = {
  open: PropTypes.bool,
  userInfo: PropTypes.object,
};
