import styled from "styled-components";
import { HEADER_HEIGHT, HEADER_HEIGHT_MOBILE } from "./constants";

export const HeaderWrapper = styled.div`
  width: 100%;
  top: 0;
  text-decoration: none;
  display: flex;
  justify-content: center;
  position: sticky;
  z-index: 10;

  @media ${(p) => p.theme.breakpoints.tablet} {
    margin-top: 0px;
    position: sticky;
    z-index: 999;
  }

  .header {
    position: relative;
    flex: 1;
    height: ${HEADER_HEIGHT}px;
    background: white;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 24px;
    @media ${(p) => p.theme.breakpoints.tablet} {
      padding: 16px;
      height: ${HEADER_HEIGHT_MOBILE}px;
    }

    .name {
      font-weight: 600 !important;
      font-size: 16px !important;
      color: ${(p) => p.theme.colors.darkBlue} !important;
    }

    .logo {
      width: 130px;
      height: 30px;
      @media ${(p) => p.theme.breakpoints.tablet} {
        display: none;
      }
    }

    .userInfo {
      display: flex;
      align-items: center;
      gap: 16px;

      .avatar {
        cursor: pointer;
        width: 54px;
        height: 54px;
        background-color: #cad3da;
        border-radius: 100px;
        border: 5px solid #e9edf1;
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .userName {
        display: flex;
        flex-direction: column;
        // @media ${(p) => p.theme.breakpoints.tablet} {
        //   display: none;
        // }

        .greet {
          font-weight: 500;
          font-size: 13px;
          line-height: 130%;
          letter-spacing: 0%;
          text-align: left;
          color: ${(p) => p.theme.colors.neutral};
        }
      }
    }
  }
`;

HeaderWrapper.shouldForwardProp = (prop) => !["modalOpen"].includes(prop);
