import { IMGLogoVPB } from "@assets/images";
import AppImage from "@components/AppImage";
import Box from "@mui/material/Box";
import ClickAwayListener from "@mui/material/ClickAwayListener";
import Typography from "@mui/material/Typography";
import { TOKEN_KEY } from "@utils/constants";
import { getCustomerInitials } from "@utils/helpers";
import { useOneState } from '@utils/hooks/useRedux'
import KEY from '@utils/injectKey';
import SessionStorageService from "@utils/storage/session";
import { useState } from "react";

import SettingsModal from "./SettingsModal";
import { HeaderWrapper } from "./style";

export default function Header() {
  const userInfo = useOneState(KEY.GLOBAL,'userInfo');
  const [modalOpen, setOpenModal] = useState(false);

  // const userInfo = SessionStorageService.getItem(USER_INFO);
  const isShowProfile = userInfo?.mainUsername && SessionStorageService.getItem(TOKEN_KEY);

  return (
    <HeaderWrapper modalOpen={modalOpen}>
      <Box className="header">
        {isShowProfile && (
          <ClickAwayListener onClickAway={() => setOpenModal(false)}>
            <Box className="userInfo">
              <SettingsModal open={modalOpen} userInfo={userInfo} />
              <Box
                className="avatar"
                onClick={() => setOpenModal((prev) => !prev)}
              >
                <span>{getCustomerInitials(userInfo?.mainUsername)}</span>
              </Box>
              <Box className="userName">
                <Typography className="greet">Xin chào!</Typography>
                <Typography className="greet name">
                  {userInfo?.mainUsername || ''}
                </Typography>
              </Box>
            </Box>
          </ClickAwayListener>
        )}
        <Box className="logo">
          <AppImage
            src={IMGLogoVPB}
            height={30}
            width={130}
            className="vpBankLogo"
          />
        </Box>
      </Box>
    </HeaderWrapper>
  );
}
