export const HEADER_HEIGHT = 76;
export const HEADER_HEIGHT_MOBILE = 70;
