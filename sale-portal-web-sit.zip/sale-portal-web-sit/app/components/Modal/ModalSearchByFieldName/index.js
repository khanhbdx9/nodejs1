import EmptyFilter from "@components/EmptyFilter";
import ModalContainer from "@components/Modal/ModalContainer";
import Title from "@components/Styled/Title";
import SearchIcon from "@mui/icons-material/Search";
import InputAdornment from "@mui/material/InputAdornment";
import ListItem from "@mui/material/ListItem";
import VPB_COLOR from "@ThemeProvider/colors";
import { isMobile, nonAccentVietnamese } from "@utils/helpers";
import { debounce } from "lodash"; // Import lodash debounce
import PropTypes from "prop-types";
import { useState, useMemo } from "react";
import DoneOutlinedIcon from '@mui/icons-material/DoneOutlined';

import { InputSearchField, ModalSearchByFieldNameContainer, ListContainer } from "./Styled";

const ModalSearchByFieldName = ({ 
  title = '', 
  field = 'id', 
  fieldName = 'name',
  itemActive = {},
  items = [], 
  desEmpty = '',
  handleClose = () => {},
  handleChange = () => {},
  ...props 
}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [textSearch, setTextSearch] = useState("");

  // Debounce the search term updates
  const handleSearchChange = debounce((term) => {
    setTextSearch(term);
  }, 300);

  const handleInputChange = (e) => {
    const value = e.target.value;
    setSearchTerm(value);
    handleSearchChange(value);
  };

  // Memoize the filtered items for better performance
  const filteredItems = useMemo(() => {
    if (!textSearch) return items;
    return items.filter((item) =>
      nonAccentVietnamese(item[fieldName])?.toLowerCase().includes(nonAccentVietnamese(textSearch).toLowerCase())
    );
  }, [textSearch, items, fieldName]);

  const handleChangeItem = (event) => {
    const itemEl = event.target.closest("li[data-index]");

    if (itemEl) {
      const itemIndex = itemEl.getAttribute("data-index");
      const selectedItem = filteredItems[itemIndex];

      handleChange(selectedItem)
    }
  }

  return (
    <ModalContainer
      paddingContent={0}
      handleClose={handleClose}
      position={isMobile() ? "bottom" : "center"}
      {...props}
    >
      <ModalSearchByFieldNameContainer>
        <Title $size={16} style={{ padding: 16, paddingBottom: 0 }}>{title}</Title>

        <InputSearchField 
          placeholder="Tìm Kiếm"
          value={searchTerm}
          onChange={handleInputChange}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon style={{ color: VPB_COLOR.darkGray }} />
              </InputAdornment>
            ),
          }}
        />

        <ListContainer onClick={handleChangeItem}>
          {filteredItems.length > 0 ? (
            filteredItems.map((item, index) => {
              const isActive = item[field] === itemActive[field];
            
              return (
                <ListItem 
                  key={`${item[field]}_${index}`} 
                  className="pointer justify-between"
                  data-id={item[field]}
                  data-index={index}
                >
                  {item[fieldName] || ''}
                  {isActive && (
                    <DoneOutlinedIcon style={{ color: VPB_COLOR.lightGreen }} />
                  )}
                </ListItem>
              );
            })
          ) : (
            <EmptyFilter mt={0} description={desEmpty}/>
          )}
        </ListContainer>
      </ModalSearchByFieldNameContainer>
    </ModalContainer>
  );
};

ModalSearchByFieldName.propTypes = {
  title: PropTypes.string,
  field: PropTypes.string,
  fieldName: PropTypes.string,
  desEmpty: PropTypes.string,
  items: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
      name: PropTypes.string,
    })
  ),
  handleClose: PropTypes.func,
  handleChange: PropTypes.func,
};

export default ModalSearchByFieldName;
