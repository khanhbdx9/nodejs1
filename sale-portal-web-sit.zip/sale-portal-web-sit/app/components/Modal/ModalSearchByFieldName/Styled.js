import TextFieldCustom from "@components/TextFieldCustom";
import List from '@mui/material/List';
import styled from 'styled-components';

const height = window.innerHeight;

export const ModalSearchByFieldNameContainer = styled.div`
  display: flex;
  gap: 16px;
  min-width: 360px;
  min-height: 300px;
  flex-direction: column;
`;

export const InputSearchField = styled(TextFieldCustom)`
  width: 100%;
  padding: 0 16px !important;

  .MuiInputBase-root {
    background: ${({ theme }) => theme.colors.grayishTone};
    border-radius: 10px;
    padding-left: 8px;

    .MuiInputAdornment-root {
      margin: 0;
    }

    input {
      padding:  10px 8px;
      font-size: 16px;
      font-weight: 500;
      line-height: 140%;
      color: ${({ theme }) => theme.colors.darkGray};
    }
  }
`;

export const ListContainer = styled(List)`
  padding: 0 16px !important;
  overflow-y: auto;
  height: ${height - 200}px;

  .MuiListItem-root{
    padding: 13px 16px;
    border-radius: 10px;
    font-weight: 500;
    font-size: 16px;
    line-height: 140%;
    color: ${({ theme }) => theme.colors.black};
    border-bottom: 1px solid ${({ theme }) => theme.colors.shade0};
  }
`;