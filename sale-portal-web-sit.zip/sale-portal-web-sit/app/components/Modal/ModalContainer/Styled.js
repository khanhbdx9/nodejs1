import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import Box from "@mui/material/Box";
import styled, { keyframes, css } from "styled-components";

const slideInCenter = keyframes`
  0% {
    opacity: 0;
    transform: translate(-50%, -55%);
  }
  100% {
    opacity: 1;
    transform: translate(-50%, -50%);
  }
`;

export const StyledDialog = styled(Dialog)`
  .MuiBackdrop-root {
    background-color: ${({ theme }) => theme.colors.backdrop};
  }

  .MuiPaper-root {
    border-radius: 8px;
    box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
    position: fixed;
    margin: 0;
    max-width: 100vw;
    max-height: 100vw;
    overflow: hidden;
    background: ${({ theme }) => theme.colors.white};

    ${({ $position }) => {
      switch ($position) {
        case "bottom":
          return `
            bottom: 0;
            left: 0;
            right: 0;
            width: 100%;
            max-height: max-content;
            border-radius: 8px 8px 0 0;
          `;
        case "top":
          return "top: 0; left: 0; right: 0; height: auto; width: 100%;";
        case "left":
          return `
            left: 0; 
            top: 0; 
            bottom: 0; 
            max-width: 80vw; 
            height: 100vh; 
            border-radius: 0 8px 8px 0;
          `;
        case "right":
          return `
            right: 0; 
            top: 0; 
            bottom: 0; 
            max-width: 80vw; 
            height: 100vh; 
            border-radius: 8px 0 0 8px;
          `;
        default:
          return css`
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            height: auto;
            max-height: unset;
            animation: ${slideInCenter} 0.4s ease-in-out;
          `;
      }
    }}
  }
`;

export const StyledDialogContent = styled(DialogContent)`
  padding: ${({ $paddingContent = 24 }) => $paddingContent}px !important;
  width: 100%;
  height: auto;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  @media ${({ theme }) => theme.breakpoints.tablet} {
    padding: 16px !important;
  }
`;

export const CloseButton = styled.button`
  position: absolute;
  top: 12px;
  right: 12px;
  width: 28px;
  height: 28px;
  background: transparent;
  border: none;
  cursor: pointer;
  display: ${({ $hiddenBtnClose }) => ($hiddenBtnClose ? "none" : "flex")};
  align-items: center;
  justify-content: center;

  &:before,
  &:after {
    content: "";
    position: absolute;
    width: 20px;
    height: 2px;
    background-color: ${({ theme }) => theme.colors.darkBlue};
    transition: 0.3s;
  }

  &:before {
    transform: rotate(45deg);
  }

  &:after {
    transform: rotate(-45deg);
  }

  &:hover:before,
  &:hover:after {
    background-color: ${({ theme }) => theme.colors.red};
  }
`;