import Fade from "@mui/material/Fade";
import Slide from "@mui/material/Slide";
import PropTypes from "prop-types";
import { useEffect, useState, useMemo, forwardRef } from "react";

import { StyledDialog, StyledDialogContent, CloseButton } from "./Styled";

const Transition = forwardRef(({ position, ...props }, ref) => {
  if (position === "center") return <Fade ref={ref} {...props} timeout={300} />;
  return <Slide ref={ref} direction={getSlideDirection(position)} {...props} />;
});

const getSlideDirection = (position) => {
  switch (position) {
    case "top":
      return "down";
    case "bottom":
      return "up";
    case "left":
      return "right";
    case "right":
      return "left";
    default:
      return "down";
  }
};

const ModalContainer = ({ children, open, handleClose, position = "right", paddingContent, hiddenBtnClose, contentClass }) => {
  const [isMounted, setIsMounted] = useState(open);

  useEffect(() => {
    if (open) setIsMounted(true);
    else setIsMounted(false);
    // else setTimeout(() => setIsMounted(false), 200); // Chờ hiệu ứng xong rồi remove khỏi DOM
  }, [open]);

  const MemoizedTransition = useMemo(() => {
    return forwardRef((props, ref) => (
      <Transition position={position} {...props} ref={ref} />
    ));
  }, [position]);

  if (!isMounted) return null; // Không render nếu không cần thiết

  return (
    <StyledDialog
      open={open}
      keepMounted={false}
      TransitionComponent={MemoizedTransition}
      TransitionProps={{ direction: getSlideDirection(position) }}
      onClose={(event, reason) => {
        if (reason !== "backdropClick") {
          handleClose(event, reason);
        }
      }}
      disableEscapeKeyDown
      $position={position}
    >
      <CloseButton onClick={handleClose} $hiddenBtnClose={hiddenBtnClose}/>
      <StyledDialogContent $paddingContent={paddingContent} className={contentClass}>{children}</StyledDialogContent>
    </StyledDialog>
  );
};

ModalContainer.propTypes = {
  open: PropTypes.bool,
  children: PropTypes.any,
  handleClose: PropTypes.func,
  paddingContent: PropTypes.number,
  position: PropTypes.oneOf(["center", "top", "bottom", "left", "right"]),
};

export default ModalContainer;
