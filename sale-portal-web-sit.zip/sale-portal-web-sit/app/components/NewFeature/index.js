import { IMGFeature } from "@assets/images";
import AppButton from "@components/AppButton";
import { redirectListApplication } from '@utils/redirect'
import PropTypes from 'prop-types';

import { NewFeatureContainer, Image, Title, Description } from "./Styled";

const NewFeature = ({ 
  minHeight,
  isHiddenBtn,
  externalBottom,
  title = "Tính năng đang phát triển!" , 
  dest = "Chúng tôi rất vui mừng thông báo rằng hệ thống mới của chúng tôi sẽ ra mắt trong thời gian tới. Cảm ơn sự ủng hộ của các bạn!" 
}) => {
  return (
    <NewFeatureContainer $minHeight={minHeight}>
      <Image src={IMGFeature} alt="404 Not Found" />

      <Title $size={24} $weight={600}>{title}</Title>

      <Description> {dest} </Description>

      {!isHiddenBtn && !externalBottom && (
        <AppButton
          label="Đã hiểu"
          variant="outlined"
          onClick={redirectListApplication}
          style={{ width: 250 }}
        />
      )}

      {externalBottom}
    </NewFeatureContainer>
  );
};

NewFeature.propTypes = {
  minHeight: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  isHiddenBtn: PropTypes.bool,
  title: PropTypes.string,
  dest: PropTypes.string,
  externalBottom: PropTypes.node,
};

export default NewFeature;
