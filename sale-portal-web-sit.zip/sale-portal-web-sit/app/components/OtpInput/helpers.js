export const COUNT = 180;

export const OTP_FORMAT = ["", "", "", "", "", ""];

export const EVENT_KEY = {
  BACKSPACE: "Backspace",
  LEFT_ARROW: "ArrowLeft",
  RIGHT_ARROW: "ArrowRight",
  DELETE: "Delete",
  SPACE: "Spacebar",
};

export const formatTime = (time) => {
  const minutes = Math.floor(time / 60);
  const seconds = time % 60;
  return `${minutes.toString().padStart(2, "0")}:${seconds
    .toString()
    .padStart(2, "0")}`;
};
