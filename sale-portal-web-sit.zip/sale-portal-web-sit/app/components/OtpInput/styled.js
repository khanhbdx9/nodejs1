import styled from "styled-components";

export const OtpContainer = styled.div`
  padding: 48px;
  display: flex;
  align-items: center;
  flex-direction: column;

  @media ${(p) => p.theme.breakpoints.tablet} {
    padding: 24px;
  }

  .title {
    font-weight: 500;
    font-size: 16px;
    line-height: 20px;
    letter-spacing: 0%;
    text-align: center;
    vertical-align: middle;
    color: ${(p) => p.theme.colors.darkBlue};
    @media ${(p) => p.theme.breakpoints.tablet} {
      font-size: 14px;
      line-height: 18px;
    }
  }

  .lightGreen {
    color: ${(p) => p.theme.colors.lightGreen};
  }

  .otpInputList {
    display: flex;
    gap: 10px;
    align-items: center;
    margin-top: 28px;

    .otpInput {
      height: 56px;
      width: 48px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 9px;
      background: ${(p) => p.theme.colors.shade0};
      .MuiInputBase-root {
        height: 100%;
        width: 100%;
      }
      input {
        text-align: center;
        padding: 0px;
        display: flex;
        align-items: center;
        justify-content: center;
      }
    }
  }

  .phoneNumber {
    margin-top: 8px;
    font-weight: 600;
    font-size: 20px;
    line-height: 32px;
    letter-spacing: 0%;
    text-align: center;
    vertical-align: middle;
  }

  .otpResend {
    display: flex;
    gap: 4px;
    margin-top: 24px;

    .resend {
      cursor: pointer;
    }
  }

  .otpError {
    margin-top: 28px;
    display: flex;
    align-items: center;
    gap: 8px;
    background-color: #ffedeb;
    padding: 12px 16px;
    border-radius: 6px;
    span {
      font-weight: 500;
      font-size: 14px;
      line-height: 20px;
      letter-spacing: 0%;
      text-align: center;
      vertical-align: middle;
      color: ${(p) => p.theme.colors.red};
    }
  }
`;
