import { useEffect, useState, memo } from "react";
import { formatTime } from "../helpers";
import PropTypes from "prop-types";

function ResendOTP({ onResendOtp, expireTime }) {
  const [timer, setTimer] = useState(expireTime);
  const [resend, setResend] = useState(false);

  useEffect(() => {
    if (timer > 0) {
      const interval = setInterval(() => {
        setTimer((prevTimer) => prevTimer - 1);
      }, 1000);
      return () => clearInterval(interval);
    } else {
      setResend(true);
    }
  }, [timer]);

  const onHandleResendOTP = () => {
    onResendOtp();
    setTimer(expireTime);
    setResend(false);
  };

  return (
    <div className="otpResend">
      {resend ? (
        <>
          <span className="title">Không nhận được mã OTP?</span>
          <span className="title lightGreen resend" onClick={onHandleResendOTP}>
            Gửi lại mã
          </span>
        </>
      ) : (
        <>
          <span className="title">Mã có hiệu lực trong</span>
          <span className="title lightGreen">{formatTime(timer)}</span>
        </>
      )}
    </div>
  );
}

ResendOTP.propTypes = {
  otpRequest: PropTypes.object,
};

export default memo(ResendOTP);
