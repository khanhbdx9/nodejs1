import React, { memo } from "react";
import { IcError } from "@assets/icons";
import { MESSAGE_SYSTEM } from "@utils/message";
import PropTypes from "prop-types";

function ErrorMessage({ msgError }) {
  return (
    <React.Fragment>
      {msgError && (
        <div className="otpError">
          <img src={IcError} />
          <span>{msgError || MESSAGE_SYSTEM.error_01}</span>
        </div>
      )}
    </React.Fragment>
  );
}

ErrorMessage.propTypes = {
  msgError: PropTypes.string,
};

export default memo(ErrorMessage);
