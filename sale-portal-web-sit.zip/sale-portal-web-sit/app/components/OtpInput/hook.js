import { useRef, useEffect } from "react";
import { useFormik } from "formik";
import { OTP_FORMAT, EVENT_KEY } from "./helpers";

export default function useHook({ onSubmit, isClearOtp }) {
  const inputRefs = useRef([]);

  const formik = useFormik({
    initialValues: {
      otpCode: OTP_FORMAT,
    },
    onSubmit: async ({ otpCode }) => {
      if (otpCode.every((item) => item) && onSubmit) {
        onSubmit(otpCode.join(""));
      }
    },
  });

  useEffect(() => {
    if (isClearOtp) {
      formik.resetForm();
    }
  }, [isClearOtp]);

  useEffect(() => {
    if (inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  }, []);

  useEffect(() => {
    if (formik.values.otpCode.every((item) => item)) {
      formik.handleSubmit();
    }
  }, [formik.values]);

  // paste event
  const handlePaste = (e) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData("text");
    const numericData = pastedData.replace(/[^0-9]/g, "");
    const pasteValues = numericData.split("").slice(0, OTP_FORMAT.length);
    formik.setFieldValue("otpCode", pasteValues);
    inputRefs.current[OTP_FORMAT.length - 1].focus();
  };

  const onHandleInput = (e, index) => {
    e.target.value = e.target.value.replace(/[^0-9]/g, "");
    if (e.target.value && index < OTP_FORMAT.length - 1) {
      inputRefs.current[index + 1].focus();
    }
  };

  const onHandleChange = (e, index) => {
    e.target.value = e.target.value.replace(/[^0-9]/g, "");
    // Tìm ô nhập trống đầu tiên
    let emptyIndex = -1;
    for (let i = 0; i < index; i++) {
      if (!formik.values.otpCode[i]) {
        emptyIndex = i;
        break;
      }
    }
    // Nếu tìm thấy ô nhập trống, focus vào ô đó và điền giá trị
    if (emptyIndex !== -1) {
      inputRefs.current[emptyIndex + 1].focus();
      formik.setFieldValue(`otpCode[${emptyIndex}]`, e.target.value);
    } else {
      // Nếu tất cả các ô đều có giá trị, điền giá trị vào ô hiện tại
      formik.setFieldValue(`otpCode[${index}]`, e.target.value);
    }
  };

  // Handle cases of backspace, delete, left arrow, right arrow, space
  const handleOnKeyDown = (e, index) => {
    switch (e.key) {
      case EVENT_KEY.BACKSPACE:
      case EVENT_KEY.DELETE:
        e.preventDefault();
        const newOtpCode = [...formik.values.otpCode];
        newOtpCode[index] = ""; // Xóa giá trị tại index hiện tại
        // Di chuyển các giá trị sau đó về phía trước
        for (let i = index + 1; i < OTP_FORMAT.length; i++) {
          if (newOtpCode[i]) {
            newOtpCode[i - 1] = newOtpCode[i];
            newOtpCode[i] = "";
          }
        }
        formik.setFieldValue("otpCode", newOtpCode);
        if (index > 0) {
          inputRefs.current[index - 1].focus();
        }
        break;
      case EVENT_KEY.LEFT_ARROW:
        e.preventDefault();
        if (index > 0) {
          inputRefs.current[index - 1].focus();
        }
        break;
      case EVENT_KEY.RIGHT_ARROW:
        e.preventDefault();
        if (index < OTP_FORMAT.length - 1) {
          inputRefs.current[index + 1].focus();
        }
        break;
      case " ":
      case EVENT_KEY.SPACE:
      case "Space":
        e.preventDefault();
        break;
      default:
        break;
    }
  };

  return {
    formik,
    inputRefs,
    handlePaste,
    onHandleInput,
    onHandleChange,
    handleOnKeyDown,
  };
}
