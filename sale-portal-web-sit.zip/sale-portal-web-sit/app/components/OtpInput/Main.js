import React from "react";
import TextFieldCustom from "@components/TextFieldCustom";
import PropTypes from "prop-types";
import ErrorMessage from "./components/Error";
import ResendOTP from "./components/Resend";
import { COUNT, OTP_FORMAT } from "./helpers";
import useHook from "./hook";
import { OtpContainer } from "./styled";

function OtpComponent({
  phoneNumber,
  errorText = "",
  onSubmit,
  onResendOtp,
  expireTime = COUNT,
  isClearOtp = false,
}) {
  const {
    formik,
    inputRefs,
    handlePaste,
    onHandleInput,
    onHandleChange,
    handleOnKeyDown,
  } = useHook({
    onSubmit,
    isClearOtp,
  });

  const onHandleResendOtp = () => {
    formik.resetForm();
    onResendOtp();
  };

  return (
    <OtpContainer>
      <div className="title">Mã xác thực OTP đã được gửi tới</div>
      <div className="phoneNumber lightGreen">{phoneNumber}</div>
      <div className="otpInputList">
        {OTP_FORMAT.map((item, index) => {
          return (
            <React.Fragment key={index}>
              <TextFieldCustom
                id={`otp-input-${index}`}
                className="otpInput"
                placeholder="-"
                name={`otpCode[${index}]`}
                ref={(el) => {
                  inputRefs.current[index] = el;
                }}
                inputProps={{
                  maxLength: 1,
                  autoComplete: "one-time-code",
                  inputMode: "numeric",
                }}
                value={formik.values.otpCode[index]}
                onChange={(e) => onHandleChange(e, index)}
                onInput={(e) => onHandleInput(e, index)}
                onKeyDown={(e) => handleOnKeyDown(e, index)}
                onPaste={(e) => handlePaste(e, index)}
                onFocus={(e) => {
                  e.target.select();
                }}
                errorMessage={!!errorText}
                aria-label={`Mã OTP ${index + 1}`}
                aria-invalid={!!errorText}
                aria-describedby={errorText}
              />
            </React.Fragment>
          );
        })}
      </div>
      <ResendOTP onResendOtp={onHandleResendOtp} expireTime={expireTime} />
      <ErrorMessage msgError={errorText} />
    </OtpContainer>
  );
}

OtpComponent.propTypes = {
  onSubmit: PropTypes.func.isRequired,
  onResendOtp: PropTypes.func.isRequired,
  errorText: PropTypes.string,
  phoneNumber: PropTypes.string,
  expireTime: PropTypes.number,
};

export default OtpComponent;
