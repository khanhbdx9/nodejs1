import { Button } from '@mui/material';
import PropTypes from 'prop-types';

const AppButton = ({ children, label, ...res }) => {
  return (
    <Button variant="contained" {...res}>
      {label}
      {children}
    </Button>
  );
}

AppButton.propTypes = {
  children: PropTypes.node,
  label: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.node,
  ]),
};

export default AppButton;
