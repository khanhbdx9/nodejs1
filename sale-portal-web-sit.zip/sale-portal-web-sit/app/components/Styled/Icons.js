import styled from "styled-components";

export const ArrowRightIcon = styled.span`
  font-size: 20px;
  font-weight: bold;
  color: black;
`;