import Box from "@mui/material/Box";
import styled from "styled-components";

export const ActionContainer = styled(Box)`
  display: flex;
  justify-content: ${({ $position }) => $position};
  gap: 16px;
  button {
    min-width: ${({ $minWidth = 131 }) => $minWidth}px;
    flex:  ${({ $full }) => $full ? '1px' : 'unset'};
    @media ${(p) => p.theme.breakpoints.tablet} {
      flex: 1;
    }
  }
`;