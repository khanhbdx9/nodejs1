import styled from "styled-components";

const Title = styled.h3`
  margin: 0;
  padding: 0;
  font-size: ${({ $size = 18}) => $size}px;
  text-align: ${({ $align = 'left'}) => $align};
  font-weight: ${({ $weight = 600}) => $weight};
  line-height: ${({ $lineHeight = '140%'}) => $lineHeight};
  color: ${({ theme, $color }) => $color || theme.colors.darkBlue};
`;

const Text = styled.span`
  margin: 0;
  padding: 0;
  font-size: ${({ $size = 16}) => $size}px;
  text-align: ${({ $align = 'left'}) => $align};
  font-weight: ${({ $weight = 500}) => $weight};
  line-height: ${({ $line = '140%'}) => $line};
  color: ${({ theme, $color }) => $color ? theme.colors[$color] ? theme.colors[$color]: $color : theme.colors.darkBlue};
`;

const ErrorMessage = styled(Text)`
  display: ${({ $error }) => $error ? 'block' : 'none'};
  font-size: ${({ $size = 12}) => $size}px;
  font-weight: ${({ $weight = 400}) => $weight};
  color: ${({ theme }) => theme.colors.red};
`

const Link = styled(Text)`
  text-decoration: underline;
  cursor: pointer;
`

export default Title;
export { Text, Title, Link, ErrorMessage }
