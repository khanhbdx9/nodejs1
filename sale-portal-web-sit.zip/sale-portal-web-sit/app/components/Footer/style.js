import styled from "styled-components";

export const FooterWrapper = styled.div`
  background: #ffffff;
  width: 100%;
  display: flex;
  @media ${(p) => p.theme.breakpoints.mobile} {
    display: none;
  }

  .footerContent {
    width: 100%;
    height: 66px;
    display: flex;
    padding: 24px;
    justify-content: space-between;
    align-items: center;
    background: linear-gradient(270deg, #00b74f 0%, #0058b7 100%);
    @media ${(p) => p.theme.breakpoints.mobile} {
      display: none;
    }

    .col {
      &.security {
        display: flex;
        gap: 10px;
      }
    }

    .text {
      font-size: 12px;
      line-height: 150%;
      letter-spacing: 0%;
      text-decoration: none;
      color: white;
    }
  }
`;
