import React from "react";
import Box from "@mui/material/Box";
import Link from "@mui/material/Link";
import Typography from "@mui/material/Typography";
import { FooterWrapper } from "./style";

export const Footer = () => (
  <FooterWrapper>
    <Box className="footerContent">
      <Typography className="col text">
        © 2022 VPBank – Bản quyền đã được bảo hộ
      </Typography>
      <Box className="col security">
        <Link
          href="https://www.vpbank.com.vn/quy-dinh-bao-mat"
          target="_blank"
          className="text"
        >
          Chính sách bảo mật
        </Link>
        <span className="text">|</span>
        <Link
          href="https://www.vpbank.com.vn/sitemap"
          target="_blank"
          className="text"
        >
          Sitemap
        </Link>
      </Box>
    </Box>
  </FooterWrapper>
);

export default Footer;
