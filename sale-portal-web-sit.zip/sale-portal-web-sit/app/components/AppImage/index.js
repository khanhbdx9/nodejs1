import Skeleton from "@mui/material/Skeleton";
import PropTypes from "prop-types";
import { useEffect, useRef, useState } from "react";
import styled from "styled-components";

const StyledImg = styled.img`
  width: ${({ width }) => (typeof width === "number" ? `${width}px` : width)};
  height: ${({ height }) => (typeof height === "number" ? `${height}px` : height)};
  // object-fit: cover;
  border-radius: 8px;
  display: block;
  transition: opacity 0.3s ease;
  opacity: ${({ $loaded }) => ($loaded ? 1 : 0)};
  object-fit: ${({$isOrientation}) => $isOrientation ? 'contain' : ''};
`;

const LazyLoadImage = ({
  src,
  width = 100,
  height = 100,
  minWidth = null,
  alt = "",
  fallbackSrc,
  styleWrap = {},
  isOrientation = false,
  ...rest
}) => {
  const containerRef = useRef(null);
  const [isVisible, setIsVisible] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);
  const [dimensions, setDimensions] = useState({ width, height });

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (isOrientation && src) {
      const img = new Image();
      img.src = src;
      img.onload = () => {
        const orientation =
          img.width > img.height
            ? "landscape"
            : img.width < img.height
            ? "portrait"
            : "square";

        // Đổi kích thước nếu là ảnh dọc
        if (orientation === "portrait") {
          if(minWidth){
            setDimensions({ width: minWidth, height });
          } else {
            setDimensions({ width: height, height: width });
          }
        } else {
          setDimensions({ width, height });
        }
      };
    }
  }, [isOrientation, src, width, height]);

  const handleError = () => {
    if (fallbackSrc) {
      setError(true);
    }
    setLoaded(true);
  };

  return (
    <div
      ref={containerRef}
      className='imgWrap'
      style={{ width: dimensions.width, height: dimensions.height, position: "relative", ...styleWrap}}
    >
      {!loaded && (
        <Skeleton
          variant="rectangular"
          width={dimensions.width}
          height={dimensions.height}
          sx={{ borderRadius: "8px", position: "absolute", top: 0, left: 0 }}
        />
      )}

      {isVisible && (
        <StyledImg
          src={error ? fallbackSrc : src}
          alt={alt}
          width={dimensions.width}
          height={dimensions.height}
          loading="lazy"
          $loaded={loaded}
          $isOrientation={isOrientation}
          onLoad={() => setLoaded(true)}
          onError={handleError}
          {...rest}
        />
      )}
    </div>
  );
};

LazyLoadImage.propTypes = {
  src: PropTypes.string.isRequired,
  fallbackSrc: PropTypes.string,
  alt: PropTypes.string,
  width: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  height: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  minWidth: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  styleWrap: PropTypes.object,
  isOrientation: PropTypes.bool,
};

export default LazyLoadImage;
