import { Box, Tabs, Tab, Fade } from '@mui/material';
import PropTypes from 'prop-types';
import { useState, useEffect, useCallback, useMemo } from 'react';

const TabsWithTransition = ({
  tabs,
  className = '',
  activeTab,
  onTabChange,
  hiddenTabHeader,
  ...restProps
}) => {
  const [tabIndex, setTabIndex] = useState(activeTab ?? 0);
  const [fadeIn, setFadeIn] = useState(true);

  // Đồng bộ tab từ props activeTab bên ngoài
  useEffect(() => {
    if (typeof activeTab === 'number' && activeTab !== tabIndex) {
      setFadeIn(false);
      setTimeout(() => {
        setTabIndex(activeTab);
        setFadeIn(true);
      }, 200);
    }
  }, [activeTab, tabIndex]);

  // Xử lý khi người dùng đổi tab
  const handleTabChange = useCallback((_, newIndex) => {
    setFadeIn(false);
    setTimeout(() => {
      setTabIndex(newIndex);
      setFadeIn(true);
      onTabChange?.(newIndex);
    }, 200);
  }, [onTabChange]);

  const currentTab = useMemo(() => tabs[tabIndex], [tabs, tabIndex]);

  return (
    <Box {...restProps} className={className}>
      {!hiddenTabHeader && (
        <Tabs value={tabIndex} onChange={handleTabChange} variant="fullWidth" TabIndicatorProps={{ style: { display: 'none' } }}>
          {tabs.map((tab, index) => (
            <Tab
              key={index}
              label={tab.label}
              {...(tab.tabProps || {})}
            />
          ))}
        </Tabs>
      )}

      <Box sx={{ minHeight: 120, height: 'inherit' }}>
        <Fade in={fadeIn} timeout={{ enter: 300, exit: 150 }}>
          <Box className={`${className}__content`} sx={{ height: 'inherit' }}>
            {typeof currentTab?.content === 'function' ? currentTab.content(currentTab.props) : currentTab?.content}
          </Box>
        </Fade>
      </Box>
    </Box>
  );
};

TabsWithTransition.propTypes = {
  tabs: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.oneOfType([PropTypes.string, PropTypes.node, PropTypes.func]).isRequired,
      content: PropTypes.oneOfType([PropTypes.node, PropTypes.func]).isRequired,
      tabProps: PropTypes.object,
    })
  ).isRequired,
  className: PropTypes.string,
  hiddenTabHeader: PropTypes.bool,
  activeTab: PropTypes.number,
  onTabChange: PropTypes.func,
};

export default TabsWithTransition;
