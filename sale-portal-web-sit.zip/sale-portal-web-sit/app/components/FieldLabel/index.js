import React from 'react';
import PropTypes from 'prop-types';

import WrapperFieldLabel from './styled';

export default function FieldLabel({ label, errors, children, ...props }) {
  return (
    <WrapperFieldLabel {...props} errors={errors}>
      <div className="txtlable">{label}</div>
      {children}
    </WrapperFieldLabel>
  );
}

FieldLabel.propTypes = {
  label: PropTypes.string,
  errors: PropTypes.any,
  children: PropTypes.any,
};
