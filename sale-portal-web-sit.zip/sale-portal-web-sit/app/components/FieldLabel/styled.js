import styled from 'styled-components';

const WrapperFieldLabel = styled.div`
  margin-bottom: ${props => (props.errors ? 12 : 0)}px;

  .txtlable {
    font-size: 12px;
    font-weight: 600;
    line-height: 18px;
    letter-spacing: 0em;
    margin-bottom: 4px;
    color: #${props => (props.errors ? 'f50700cf' : '104370')};
  }
`;

export default WrapperFieldLabel;
