// import useShallowEqualSelector from '@utils/hooks/useShallowEqualSelector'
import { useOneState } from '@utils/hooks/useRedux'
import KEY from '@utils/injectKey';
import { useEffect } from "react";
import styled, { keyframes } from "styled-components";
import { IcLoading } from '@assets/icons';
import { Text } from '@components/Styled/Title'

// const spin = keyframes`
//   0% { transform: rotate(0deg); }
//   100% { transform: rotate(360deg); }
// `;

// const glow = keyframes`
//   0% { box-shadow: 0 0 10px rgba(0, 255, 133, 0.2); }
//   50% { box-shadow: 0 0 20px rgba(0, 255, 133, 0.8); }
//   100% { box-shadow: 0 0 10px rgba(0, 255, 133, 0.2); }
// `;

const fadeIn = keyframes`
  0% { opacity: 0; }
  100% { opacity: 1; }
`;

const fadeOut = keyframes`
  0% { opacity: 1; }
  100% { opacity: 0; }
`;

const LoadingOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100vh;
  background: ${({ theme }) => theme.colors.backdrop};
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
  animation: ${fadeIn} 0.3s ease-in-out;

  &.hidden {
    animation: ${fadeOut} 0.3s ease-in-out forwards;
  }
`;

// const Spinner = styled.div`
//   width: 64px;
//   height: 64px;
//   border-radius: 50%;
//   border: 6px solid transparent;
//   border-top: 6px solid ${({ theme }) => theme.colors.lightGreen};
//   border-right: 6px solid #00C267;
//   border-bottom: 6px solid #00FF85;
//   animation: ${spin} 1.2s linear infinite, ${glow} 1.5s ease-in-out infinite;
// `;

// Animation
const spin = keyframes`
  0% { transform: rotate(180deg); }
  100% { transform: rotate(0deg); }
`;

// Container
export const LoadingBox = styled.div`
  width: 132px;
  height: 132px;
  background: white;
  border-radius: 14px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  font-family: sans-serif;
  gap: 18px;
`;

// Loader (vòng xoay)
export const Loader = styled.img`
 width: 32px;
  height: 32px;
  animation: ${spin} 1s linear infinite;
`;

// Text
export const LoadingText = styled.p`
  font-size: 16px;
  color: #2ecc71;
  font-weight: 500;
`;

const PageLoading = () => {
  const isLoading = useOneState(KEY.GLOBAL,'isLoading');
  
  useEffect(() => {
    document.body.style.overflow = isLoading ? "hidden" : "auto"; // Chặn cuộn khi loading
  }, [isLoading]);

  if (!isLoading) return null;

  return (
    <LoadingOverlay className={!isLoading ? "hidden" : ""}>
      {/* <Spinner />
       */}

       <LoadingBox>
        <Loader src={IcLoading}/>
        <Text $color="neutral">Đang xử lý...</Text>
      </LoadingBox>
    </LoadingOverlay>
  );
};

export default PageLoading;
