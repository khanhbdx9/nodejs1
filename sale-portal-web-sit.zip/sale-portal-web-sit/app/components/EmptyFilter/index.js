import { IcEmpty } from '@assets/icons'
import AppImage from '@components/AppImage';
import { Text } from '@components/Styled/Title';
import Box from '@mui/material/Box'
import VPB_COLOR from '@ThemeProvider/colors';

const EmptyFilter = ({ mt = 3, description = 'Không tìm thấy hồ sơ nào!' }) => {
  return (
    <Box display='grid' alignItems='center' justifyContent='center' mt={mt}>
      <AppImage width={160} height={160} src={IcEmpty} styleWrap={{ margin: 'auto' }}/>
      <Text $size={16} $weight={500} $color={VPB_COLOR.neutral}>{description}</Text>
    </Box>
  )
}

export default EmptyFilter