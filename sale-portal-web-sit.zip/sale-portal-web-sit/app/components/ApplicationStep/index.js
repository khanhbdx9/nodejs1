import {
  IcClock,
  IcSignature,
  IcBalance,
  IcFolder,
  IcExpressDelivery,
} from "@assets/icons";
import Box from "@mui/material/Box";
import PropTypes from "prop-types";
import { memo } from "react";
import { STEPS_APPLICATION } from '@utils/constants'

import { StepperContainer, StepWrapper, StepLabel, StepIcon } from "./Styled";

const ApplicationStep = ({ currentStep, steps }) => {
  return (
    <StepperContainer>
      {(steps || STEPS_APPLICATION.CC).map((step, index) => {
        const indexStep = currentStep - 1;
        const isCompleted = index < indexStep;
        const isActive = index === indexStep;

        return (
          <StepWrapper key={index}>
            <StepIcon $active={isActive} $completed={isCompleted}>
              <Box className="wrapRound">
                <Box className="wrapRound__round" />
              </Box>
            </StepIcon>

            <StepLabel $active={isActive} $completed={isCompleted}>
              {step.label}
            </StepLabel>
          </StepWrapper>
        );
      })}
    </StepperContainer>
  );
};

ApplicationStep.propTypes = {
  steps: PropTypes.array,
  currentStep: PropTypes.number.isRequired,
};

export default memo(ApplicationStep);
