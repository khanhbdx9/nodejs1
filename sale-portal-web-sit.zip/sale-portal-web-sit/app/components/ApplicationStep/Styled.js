import styled from "styled-components";

const StepIcon = styled.div`
  &::after {
    content: "";
    position: absolute;
    width: calc(100% - 34px);
    background: ${({ theme }) => theme.colors.neutra1};
    height: 2.5px;
    top: calc(32px / 2);
    left: calc(50% + 34px / 2);
    transition: background-color 0.4s ease-in-out, width 0.6s ease-in-out;
    @media ${({ theme }) => theme.breakpoints.mobile} {
      top: calc(24px / 2);
      left: calc(50% + 25px / 2);
      width: calc(100% - 25px);
    }
  }

  .wrapRound {
    border: 8px solid ${({ theme }) => theme.colors.white};
    width: max-content;
    height: max-content;
    border-radius: 100%;
    margin: auto;
    transition: background-color 0.4s ease-in-out, width 0.6s ease-in-out;

    .wrapRound__round {
      width: 18px;
      height: 18px;
      border-radius: 100%;
      background: ${({ theme }) => theme.colors.neutra1};
      transition: background-color 0.4s ease-in-out, width 0.6s ease-in-out;
      @media ${({ theme }) => theme.breakpoints.mobile} {
        width: 12px;
        height: 12px;
      }
    }
  }

  // check active
  ${({ $completed, $active, theme }) =>{
    let attrb = '';

    if($completed){
      attrb += `
        &::after{
          background: ${theme.colors.lightGreen};
        }
      `
    }

    if($completed || $active){
      attrb += `
        .wrapRound {
          border-color: ${$active ? theme.colors.jadeGreen : 'transparent'};

          .wrapRound__round {
            background: ${theme.colors.lightGreen};
          }
        }
      `
    }

    return attrb;
  }}
`;

const StepLabel = styled.span`
  font-size: 13px;
  font-weight: 500;
  color: ${({ theme }) => theme.colors.neutra1};
  text-align: center;
  max-width: 66px;
  @media ${({ theme }) => theme.breakpoints.mobile} {
    display: none;
  }

  ${({ $completed, $active, theme }) =>
    ($completed || $active) &&
    `
      color: ${theme.colors.darkBlue};
      @media ${theme.breakpoints.mobile} {
        display: ${$active ? 'block' : 'none'};
      }
  `}
`;

const StepperContainer = styled.div`
  margin-bottom: 16px;
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  width: 100vw; /* Full màn hình */
  max-width: 100%;
  position: relative;
`;

const StepWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  position: relative;
  width: 100%;

  &:last-child {
    ${StepIcon} {
      &::after {
        display: none;
      }
    }
    
  }
`;


export { StepIcon, StepLabel, StepWrapper, StepperContainer };