import { IcCopy } from "@assets/icons";
import AppImage from "@components/AppImage";
import PhoneIcon from "@mui/icons-material/Phone";
import IconButton from "@mui/material/IconButton";
import Link from "@mui/material/Link";
import Typography from "@mui/material/Typography";
import { copyToClipboard } from "@utils/helpers";
import PropTypes from "prop-types";
import { Fragment } from "react";

import ListItemTextStyled from "./styles";

function ListItemDetail({ primary, secondary, enableCopy, hideBorder, isIconTel, ...rest }) {
  const handleCopyToClipboard = () => {
    if (secondary) {
      copyToClipboard(secondary);
    }
  };

  return (
    <ListItemTextStyled
      {...rest}
      $hideBorder={hideBorder}
      primary={primary}
      slot={{ secondary: () => <></> }}
      secondary={
        <Fragment>
          <Typography variant="body2" color="textSecondary" component="span">
            {secondary}
          </Typography>

          {secondary && (
            <>
              {isIconTel && (
                <IconButton
                  size="small"
                  sx={{ ml: 1, p: 0 }}
                  component={Link}
                  href={`tel:${secondary}`}
                  aria-label="call"
                  className="isIconTel"
                >
                  <PhoneIcon fontSize="small" />
                </IconButton>
              )}

              {enableCopy && (
                <IconButton
                  size="small"
                  sx={{ ml: 1, p: 0 }}
                  onClick={handleCopyToClipboard}
                  aria-label="copy"
                >
                  <AppImage src={IcCopy} height={18} width={18} />
                </IconButton>
              )}
            </>
          )}
        </Fragment>
      }
    />
  );
}

ListItemDetail.propTypes = {
  primary: PropTypes.string,
  secondary: PropTypes.any,
  enableCopy: PropTypes.bool,
  hideBorder: PropTypes.bool,
  isIconTel: PropTypes.bool,
};

export default ListItemDetail;
