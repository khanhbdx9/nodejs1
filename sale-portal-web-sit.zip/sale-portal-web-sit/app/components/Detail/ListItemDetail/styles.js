import ListItemText from "@mui/material/ListItemText";
import styled from "styled-components";

const ListItemTextStyled = styled(ListItemText)`
  margin: 0 !important;
  padding: 16px 0;
  flex-direction: row;
  display: flex;
  gap: 8px;
  align-items: center;
  justify-content: space-between;
  border-top: ${({ $hideBorder }) => ($hideBorder ? "0px" : "1px solid")};
  border-top-color: ${({ theme }) => theme.colors.paleBlueGray};

  .MuiTypography-root {
    line-height: 120%;
    font-size: 16px;
    font-weight: 500;
    color: ${({ theme }) => theme.colors.neutral};

    &.MuiTypography-body1 {
      min-width: 145px;
    }
    &.MuiTypography-body2 {
      font-weight: 600;
      text-align: right;
      display: flex;
      align-Items: center;
      color: ${({ theme }) => theme.colors.darkBlue};
    }
  }

  .isIconTel {
    display: none;
    @media ${({theme})=>theme.breakpoints.tablet} {
      display: block;
    }
  }
`;

export default ListItemTextStyled;
