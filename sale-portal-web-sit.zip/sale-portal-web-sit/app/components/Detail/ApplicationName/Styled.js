import Box from "@mui/material/Box";
import styled from "styled-components";

const ApplicationNameContainer = styled(Box)`
  width: 100%;
  height: 45px;
  padding: 0px 16px;
  display: flex;
  align-items: center;
  background: ${({ theme }) => theme.colors.shade0};

  .btnBack {
    padding: 8px;
    min-height: auto;
    height: auto;
    min-width: max-content;
    &:hover {
      text-decoration: unset;
      background: ${({ theme }) => theme.colors.neutra1001};
    }
    @media ${(p) => p.theme.breakpoints.mobile} {
      padding: 0;
    }
  }
`;

export default ApplicationNameContainer;
