import { IcHome } from '@assets/icons';
import AppButton from '@components/AppButton';
import AppImage from '@components/AppImage';
import { Title, Text } from "@components/Styled/Title";
import { redirectListApplication } from '@utils/redirect'
import PropTypes from "prop-types";

import ApplicationNameContainer from "./Styled";

function ApplicationName({ name }) {
  return (
    <ApplicationNameContainer className="justify-between">
      <Title $weight={600} $size={18}>
        {name}
      </Title>

      <AppButton 
        variant="text" 
        className="btnBack dflex align-center gap-8" 
        onClick={redirectListApplication}
      >
        <AppImage height={20} width={20} src={IcHome} />
        <Text $size={14} className="isDesktop"> Trở lại Danh sách </Text>
      </AppButton>
    </ApplicationNameContainer>
  );
}

ApplicationName.propTypes = {
  name: PropTypes.string,
};

export default ApplicationName;
