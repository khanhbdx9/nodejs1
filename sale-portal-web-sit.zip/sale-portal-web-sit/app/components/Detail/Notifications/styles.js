import styled from "styled-components";
const width = window.innerWidth;

const NotificationContainer = styled.div`
  border: 1px solid
    ${({ theme, $type }) => {
      switch ($type) {
        case "error":
          return theme.colors.red;
        case "warning":
          return theme.colors.pastelSand;
        default:
          return theme.colors.paleAqua;
      }
    }};
  background: ${({ theme, $type }) => {
    switch ($type) {
      case "error":
        return theme.colors.lightRed;
      case "warning":
        return theme.colors.warmIvory;
      default:
        return theme.colors.lightAqua;
    }
  }};

  display: flex;
  // align-items: center;
  padding: 16px;
  border-radius: 8px;
  gap: 8px;

  .content {
    max-width: calc(852px - 38px - 32px);
    @media ${({ theme }) => theme.breakpoints.tablet} {
      max-width: calc(${width}px - 110px);
    }

    .title {
      color: ${({ theme, $type }) => {
        switch ($type) {
          case "error":
            return theme.colors.red;
          default:
            return theme.colors.darkBlue;
        }
      }};
    }

    .subTitle {
      font-size: 14px;
      color: ${({ theme }) => theme.colors.neutral};
    }
  }
`;
export default NotificationContainer;
