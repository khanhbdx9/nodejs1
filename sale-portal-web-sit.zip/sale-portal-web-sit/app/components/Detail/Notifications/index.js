import { IcAnnouncement, IcCancelBgRed } from "@assets/icons";
import AppImage from "@components/AppImage";
import Title from "@components/Styled/Title";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import PropTypes from "prop-types";
import NotificationContainer from "./styles";

// type: alert, warning, error
const mapImageByType = {
  alert: IcAnnouncement,
  error: IcCancelBgRed,
  warning: IcAnnouncement,
};
const Notification = ({ type, title, subTitle }) => {

  return (
    <NotificationContainer $type={type}>
      {mapImageByType[type] && <AppImage src={mapImageByType[type]} height={30} width={30} />}
      <Box className="content">
        <Title $weight={600} $size={16} className="title">
          {title}
        </Title>
        {subTitle && (
          <Typography className="subTitle" variant="body2">
            {subTitle}
          </Typography>
        )}
      </Box>
    </NotificationContainer>
  );
};

Notification.propTypes = {
  type: PropTypes.string,
  title: PropTypes.string,
  subTitle: PropTypes.string,
};

export default Notification;
