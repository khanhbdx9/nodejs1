import styled from "styled-components";
import Box from "@mui/material/Box";

const AppButtonFixedStyled = styled(Box)`
  display: none;
  &.is-sticky {
    display: block;
    position: fixed;
    bottom: 0px;
    width: 100%;
    max-width: calc(900px - 48px);
    background-color: white;
    padding: 16px 0px;
    @media ${({ theme }) => theme.breakpoints.tablet} {
      max-width: calc(100% - 32px);
    }
  }
`;

export default AppButtonFixedStyled;
