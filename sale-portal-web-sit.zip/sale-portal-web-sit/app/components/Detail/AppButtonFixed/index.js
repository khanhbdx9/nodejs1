import throttle from "lodash/throttle";
import PropTypes from "prop-types";
import { useEffect } from "react";

import AppButtonFixedStyled from "./styles";

const FOOTER_HEIGHT = 100;

function AppButtonFixed({ children }) {
  const mainDiv = document.getElementById("mainPage");

  const handleScroll = () => {
    const myButton = document.getElementById("btnFixed");

    const currentScrollTop = mainDiv.scrollTop;
    const maxScrollTop = mainDiv.scrollHeight - mainDiv.clientHeight;
    const isSticky = maxScrollTop - currentScrollTop > FOOTER_HEIGHT;

    if (isSticky) {
      myButton.classList.add("is-sticky");
    } else {
      myButton.classList.remove("is-sticky");
    }
  };
  
  useEffect(() => {
    if (mainDiv) {
      handleScroll();
      
      mainDiv.addEventListener("scroll", throttle(handleScroll, 100));
    }

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <>
      {children}
      <AppButtonFixedStyled id="btnFixed" className="is-sticky">
        {children}
      </AppButtonFixedStyled>
    </>
  );
}

AppButtonFixed.prototype = {
  children: PropTypes.ReactNode,
};

export default AppButtonFixed;
