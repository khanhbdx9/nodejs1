import styled from "styled-components";

const AppCollapseContainer = styled.div`
  background-color: ${({ theme, $background }) => theme.colors[$background]};
  padding: 16px;
  border-radius: 8px;
  padding-bottom: ${({ $isCollapse }) => ($isCollapse ? "16px" : "0px")};
  transition: padding-bottom 0.3s ease-in-out;

  .header {
    display: flex;
    cursor: pointer;
    justify-content: space-between;
    align-items: center;

    p {
      font-weight: 600;
      font-size: 18px;
      line-height: 150%;
      color: ${(p) => p.theme.colors.darkBlue};
    }
    img {
      transform: ${({ $isCollapse }) =>
        $isCollapse ? "rotate(0deg)" : "rotate(90deg)"};
      transition: transform 0.3s ease-in-out;
    }
  }

  .divider {
    width: ${({ $isCollapse }) => ($isCollapse ? "0px" : "100%")};
    height: ${({ $isCollapse }) => ($isCollapse ? "0px" : "1px")};
    margin-top: ${({ $isCollapse }) => ($isCollapse ? "0px" : "8px")};
    background-color: ${(p) => p.theme.colors.neutra1};
    transition: margin-top 0.3s ease-in-out;
  }

  .body {
    overflow: hidden;
    max-height: ${({ $isCollapse }) => ($isCollapse ? "0px" : "none")};
    transition: max-height 1s ease-in-out;
  }
`;

export { AppCollapseContainer };
