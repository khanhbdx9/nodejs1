import { memo, useState } from "react";
import Box from "@mui/material/Box";
import AppImage from "@components/AppImage";
import Title from "@components/Styled/Title";
import PropTypes from "prop-types";
import { IcArrowRight } from "@assets/icons";
import { AppCollapseContainer } from "./styles";

function CollapseBox({
  title,
  children,
  contentClass = "",
  topContent,
  disableCollapse,
  hideDivider = false,
  background = "shade0",
}) {
  const [isCollapse, setCollapse] = useState(false);

  return (
    <AppCollapseContainer $isCollapse={isCollapse} $background={background}>
      {title && (
        <>
          {!disableCollapse ? (
            <Box
              className="header"
              onClick={() => {
                setCollapse((prev) => !prev);
              }}
            >
              <Title>{title}</Title>
              <AppImage
                src={IcArrowRight}
                height={18}
                width={18}
                className="arrow_down"
              />
            </Box>
          ) : (
            <Box className="header">
              <Title>{title}</Title>
            </Box>
          )}
        </>
      )}
      {title && !disableCollapse && !hideDivider ? (
        <Box className="divider" />
      ) : (
        <></>
      )}
      {topContent && <Box>{topContent}</Box>}
      <Box className={`body ${contentClass}`}>{children}</Box>
    </AppCollapseContainer>
  );
}

CollapseBox.propTypes = {
  title: PropTypes.any,
  children: PropTypes.node,
  topContent: PropTypes.node,
  contentClass: PropTypes.string,
  disableCollapse: PropTypes.bool,
};

export default memo(CollapseBox);
