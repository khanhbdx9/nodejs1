import styled from "styled-components";

export const YellowBoxContainer = styled.div`
  border: 1px solid
    ${({ theme, $color }) =>
      $color
        ? theme.colors[$color.border]
          ? theme.colors[$color.border]
          : $color.border
        : theme.colors.pastelSand};
  background: ${({ theme, $color }) =>
    $color
      ? theme.colors[$color.background]
        ? theme.colors[$color.background]
        : $color.background
      : theme.colors.warmIvory};
  border-radius: 8px;

  .header {
    padding: 16px;
    padding-bottom: 0px;
  }

  .body {
    padding: 0px 16px;
  }

  .timeInit {
    height: 32px;
    display: flex;
    font-size: 12px;
    font-weight: 500;
    align-items: center;
    justify-content: center;
    border-bottom-left-radius: 8px;
    border-bottom-right-radius: 8px;
    color: ${({ theme }) => theme.colors.brown};
    background: ${({ theme }) => theme.colors.softPeach};
  }
`;
