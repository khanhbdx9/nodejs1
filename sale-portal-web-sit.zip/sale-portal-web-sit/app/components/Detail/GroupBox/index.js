import { memo } from "react";
import Box from "@mui/material/Box";
import Title from "@components/Styled/Title";
import PropTypes from "prop-types";
import { YellowBoxContainer } from "./styles";

function GroupBox({
  title,
  children,
  timeInit,
  timeInitLabel = "Thời gian khởi tạo",
  contentClass = "",
  contentPadding = "",
  color = {
    background: "warmIvory",
    border: "pastelSand",
  },
}) {
  return (
    <YellowBoxContainer className="GroupBox" $color={color}>
      {title && (
        <Box className="header">
          <Title $weight={600} $size={18} $lineHeight="150%">
            {title}
          </Title>
        </Box>
      )}
      <Box
        className={`body ${contentClass}`}
        sx={contentPadding ? { padding: `${contentPadding} !important` } : {}}
      >
        {children}
      </Box>
      {!!timeInit && (
        <Box className="timeInit">{`${timeInitLabel}: ${timeInit}`}</Box>
      )}
    </YellowBoxContainer>
  );
}

GroupBox.propTypes = {
  title: PropTypes.string,
  timeInit: PropTypes.string,
  timeInitLabel: PropTypes.string,
  children: PropTypes.node,
  contentClass: PropTypes.string,
};

export default memo(GroupBox);
