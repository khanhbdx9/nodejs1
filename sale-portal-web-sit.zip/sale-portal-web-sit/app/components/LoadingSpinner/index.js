import React from 'react';
import PropTypes from 'prop-types';

import LoadingSpinnerContainer from './Styled';

function LoadingSpinner({ loading }) {
  return (
    <>
      {loading && (
        <LoadingSpinnerContainer>
          <div />
          <div />
          <div />
          <div />
          <div />
          <div />
          <div />
          <div />
        </LoadingSpinnerContainer>
      )}
    </>
  );
}

LoadingSpinner.propTypes = {
  loading: PropTypes.bool,
};

export default LoadingSpinner;
