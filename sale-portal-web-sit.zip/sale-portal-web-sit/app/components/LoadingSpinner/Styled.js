import styled, { keyframes } from 'styled-components';

const ldsSpinner = keyframes`
0% {
  opacity: 1;
}
100% {
  opacity: 0;
}
`;

const LoadingSpinnerContainer = styled.div`
  color: #ccc;
  display: inline-block;
  position: relative;
  width: 60px;
  height: 60px;
  margin: auto;
  div {
    transform-origin: 40px 40px;
    animation: ${ldsSpinner} 1.2s linear infinite;
    &:after {
      content: ' ';
      display: block;
      position: absolute;
      top: 15px;
      left: 37px;
      width: 6px;
      height: 15px;
      border-radius: 300px;
      background: #00b74f;
    }
    &:nth-child(1) {
      transform: rotate(0deg);
      animation-delay: -1.4s;
    }
    &:nth-child(2) {
      transform: rotate(45deg);
      animation-delay: -1.2s;
    }
    &:nth-child(3) {
      transform: rotate(90deg);
      animation-delay: -1s;
    }
    &:nth-child(4) {
      transform: rotate(135deg);
      animation-delay: -0.8s;
    }
    &:nth-child(5) {
      transform: rotate(180deg);
      animation-delay: -0.6s;
    }
    &:nth-child(6) {
      transform: rotate(225deg);
      animation-delay: -0.4s;
    }
    &:nth-child(7) {
      transform: rotate(270deg);
      animation-delay: -0.2s;
    }
    &:nth-child(8) {
      transform: rotate(315deg);
      animation-delay: 0s;
    }
    // &:nth-child(9) {
    //   transform: rotate(240deg);
    //   animation-delay: -0.3s;
    // }
    // &:nth-child(10) {
    //   transform: rotate(270deg);
    //   animation-delay: -0.2s;
    // }
    // &:nth-child(11) {
    //   transform: rotate(300deg);
    //   animation-delay: -0.1s;
    // }
    // &:nth-child(12) {
    //   transform: rotate(330deg);
    //   animation-delay: 0s;
    // }
  }
`;

export default LoadingSpinnerContainer;
