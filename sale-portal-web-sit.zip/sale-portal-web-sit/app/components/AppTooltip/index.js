import React from 'react';
import PropTypes from 'prop-types';

import { IconButton, Tooltip } from '@mui/material';

import { WrapToolTip, tooltipStyled } from './styled';

const width = window.innerWidth;

const TooltipApp = ({ label = '', content, icon, ...res }) => {
  const [open, setOpen] = React.useState(false);

  const getOptTooltip = () => {
    const opts = {};

    if (width <= 780) {
      opts.open = open;
    }

    return { ...opts };
  };

  return (
    <WrapToolTip {...res}>
      <div>{label}</div>
      <Tooltip
        arrow
        {...getOptTooltip()}
        componentsProps={{ tooltip: { sx: tooltipStyled } }}
        title={<div dangerouslySetInnerHTML={{ __html: content }} />}
      >
        <IconButton onClick={() => setOpen(!open)}>
          <img src={icon} alt="icon" />
        </IconButton>
      </Tooltip>
    </WrapToolTip>
  );
};

TooltipApp.propTypes = {
  icon: PropTypes.string,
  label: PropTypes.string,
  content: PropTypes.string,
};

export default TooltipApp;
