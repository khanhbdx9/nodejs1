import styled from 'styled-components';

export const WrapToolTip = styled.div`
  display: flex;
  align-items: center;
  gap: 4px;
  @media (max-width: 580px) {
    font-size: 12px;
  }
`;

export const tooltipStyled = {
  marginBottom: '16px',
  marginRight: '16px',
  marginLeft: '16px',

  minWidth: '328px',
  maxWidth: '800px',
  with: '100%',
  borderRadius: '8px',
  background: ' rgba(0, 0, 0, 0.80)',
  color: '#FFF',

  textAlign: 'justify',
  fontFamily: 'SVN-Gilroy',
  fontSize: '12px !important',
  fontStyle: 'normal',
  fontWeight: '500',
  lineHeight: '20px',
};
