import styled from 'styled-components';

export const Text = styled.li`
  margin: 0;
  cursor: pointer;
  font-size: 16px;
  margin: 0px 12px;
  background: unset !important;
  padding: 8px 0px !important;
  line-height: 22px;
  border-bottom: 1px solid #cdd7e2;
  color: ${({ $active }) => ($active ? '#00b74f' : '#092f51')};
  &:hover {
    background: unset !important;
    color: #00b74f;
  }
  &:last-child {
    border: none;
  }
`;

export const SelectedContainer = styled.div.withConfig({
  shouldForwardProp: (props) => props !== 'wFull'
})`
  width: ${props => (props.wFull ? '100%' : 'unset')};
  .MuiAutocomplete-root {
    width: 100%;
    height: 48px;
    background: #fff;
    border-radius: 4px;
    .MuiInputBase-root {
      padding: 0;
      height: 48px;
      padding: 13px 12px !important;
      padding-right: 42px !important;
      &:hover {
        .MuiOutlinedInput-notchedOutline {
          border-color: #00b74f;
        }
      }
      &.Mui-error {
        .MuiOutlinedInput-notchedOutline {
          border-color: #f50700cf !important;
        }
      }
      &.Mui-focused {
        .MuiOutlinedInput-notchedOutline {
          border-width: 1px;
          border-color: #00b74f;
        }
      }
      .MuiInputBase-input {
        padding: 0 !important;
        font-size: 16px;
        font-weight: 600;
        line-height: 22px;
        color: #092f51;
        &::placeholder {
          color: #9db0c5;
          font-weight: 500;
          opacity: 1; /* Firefox */
        }
        &:-ms-input-placeholder {
          /* Internet Explorer 10-11 */
          font-weight: 500;
          color: #9db0c5;
        }
        &::-ms-input-placeholder {
          /* Microsoft Edge */
          font-weight: 500;
          color: #9db0c5;
        }
      }
      .MuiOutlinedInput-notchedOutline {
        border-color: #fff;
      }
    }
  }
  .MuiAutocomplete-popper {
    border: 0.5px solid #41668c;
    border-radius: 4px;
    .MuiAutocomplete-listbox {
      padding: 0;
    }
  }
`;
