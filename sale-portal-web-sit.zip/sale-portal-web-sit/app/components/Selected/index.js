import { IcAngleDown } from "@assets/icons";
import AppImage from "@components/AppImage";
import FieldLabel from "@components/FieldLabel";
import Autocomplete from "@mui/material/Autocomplete";
import TextField from "@mui/material/TextField";
import get from "lodash/get";
import PropTypes from "prop-types";
import { useMemo } from "react";

import { Text, SelectedContainer } from "./Styled";

const Selected = ({ label, classNameField, classNameContainer, ...res }) => {
  const renderOption = useMemo(() => {
    return (props, option) => {
      const id = get(option, "id");
      const active = id == get(res, "value");

      return (
        <Text {...props} key={id} $active={active}>
          {get(option, "name") || get(option, "label")}
        </Text>
      );
    };
  }, [res.value]);

  const renderInput = useMemo(() => {
    return (params) => (
      <TextField
        {...params}
        error={get(res, "error", false)}
        placeholder={get(res, "placeholder", label)}
        helperText={get(res, "helperText", "")}
      />
    );
  }, [label, get(res, "placeholder"), get(res, "helperText"), get(res, "error")]);

  const value = useMemo(() => {
    if(!res?.value || !Array.isArray(res.options)) return ''
    return res.options.find(_o => _o.id == res.value) || '';
  }, [res.value, res.options]);

  return (
    <SelectedContainer className={classNameContainer}>
      <FieldLabel
        label={label}
        className={classNameField}
      >
        <Autocomplete
          disablePortal
          popupIcon={<AppImage src={IcAngleDown} height={20} width={20}/>}
          renderOption={renderOption} // Using memoized renderOption
          renderInput={renderInput}   // Using memoized renderInput
          {...res} // Spread the remaining props into Autocomplete
          value={value}
        />
      </FieldLabel>
    </SelectedContainer>
  );
};

Selected.displayName = "Selected";

Selected.propTypes = {
  label: PropTypes.string,
  classNameField: PropTypes.string,
  classNameContainer: PropTypes.string,

  error: PropTypes.bool, 
  value: PropTypes.oneOfType(PropTypes.object, PropTypes.string),
  helperText: PropTypes.string,
  placeholder: PropTypes.string,

  onChange: PropTypes.func, 
  options: PropTypes.array, 
  getOptionLabel: PropTypes.func,
  renderInput: PropTypes.func,
  renderOption: PropTypes.func,
};

export default Selected;
