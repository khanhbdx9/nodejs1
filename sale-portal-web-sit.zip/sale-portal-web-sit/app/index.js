import App from '@App';
import AppThemeProvider from '@ThemeProvider';
import { createRoot } from "react-dom/client";
import { Provider } from 'react-redux';
import { BrowserRouter } from "react-router-dom";
import { PATH } from '@utils/constants'

import { store } from './configureStore';
import { translationMessages } from './i18n';

// Load the favicon and the .htaccess file
import 'sanitize.css/sanitize.css';
import 'react-toastify/dist/ReactToastify.css';

// Create redux store with history
const MOUNT_NODE = document.getElementById("app");
const ROOT = createRoot(MOUNT_NODE);

const render = () => {
  ROOT.render(
    <Provider store={store}>
      <BrowserRouter basename={PATH}>
        <AppThemeProvider>
          <App />
        </AppThemeProvider>
      </BrowserRouter>
    </Provider>
  );
};

if (import.meta.hot) {
  import.meta.hot.accept(["./i18n", "@App"], () => {
    render(translationMessages);
  });
}

if (!window.Intl) {
  import("intl")
    .then(() =>
      Promise.all([
        import("intl/locale-data/jsonp/en.js"),
        import("intl/locale-data/jsonp/de.js"),
      ])
    )
    .then(() => render(translationMessages));
} else {
  render(translationMessages);
}