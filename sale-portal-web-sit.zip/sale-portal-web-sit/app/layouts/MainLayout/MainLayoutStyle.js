import styled from "styled-components";

const MainLayoutStyle = styled.div`
  width: 100%;
  height: 100vh;
  position: relative;
  /* overflow: auto; */

  .mainPage {
    z-index: 2;
    position: relative;
    max-width: 900px;
    display: flex;
    flex-direction: column;

    // scroll
    margin: 16px auto;
    overflow: auto;
    height: calc(100vh - 16px);
    /* -ms-overflow-style: none; 
    scrollbar-width: none; 
    ::-webkit-scrollbar {
      display: none; 
    } */

    @media ${(p) => p.theme.breakpoints.tablet} {
      height: 100vh;
      max-width: unset;
      width: 100%;
      padding: 0px;
      margin: 0px;
    }

    .mainContent {
      flex: 1;
      background-color: white;
      // overflow: auto;
    }
  }

  .icon {
    z-index: 1;
    position: fixed;

    @media ${(p) => p.theme.breakpoints.laptop} {
      display: none;
    }
    &.left {
      left: 0px;
      top: 40%;
    }

    &.right {
      right: 0px;
      top: 70px;
    }
  }
`;

export default MainLayoutStyle;
