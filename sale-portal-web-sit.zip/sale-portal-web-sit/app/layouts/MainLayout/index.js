import React from "react";
import { IMGVpBankLeft, IMGVpBankRight } from "@assets/images";
import MainLayoutStyle from "./MainLayoutStyle";
import Footer from "@components/Footer";
import Header from "@components/Header";
import ScrollToTop from "@components/ScrollToTop";

const MainLayout = ({ children }) => (
  <MainLayoutStyle>
    <main className="mainPage" id="mainPage">
      <Header />
      <ScrollToTop />
      <div className="mainContent">{children}</div>
      <Footer />
    </main>
    <img src={IMGVpBankLeft} className="icon left" />
    <img src={IMGVpBankRight} className="icon right" />
  </MainLayoutStyle>
);

export default MainLayout;
