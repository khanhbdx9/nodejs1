import { createGlobalStyle } from "styled-components";

const GlobalStyle = createGlobalStyle`

  .dflex {
    display: flex !important;
  }

  .dgrid {
    display: grid !important;
  }

  .align-start {
    align-items: flex-start !important;
  }

  .align-center {
    align-items: flex-center !important;
  }

  .justify-end {
    justify-content: flex-end;
  }

  .justify-between {
    justify-content: space-between !important;
  }

  .pointer {
    cursor: pointer;
  }

  .gap-4 {
    gap: 4px;
  }

  .gap-8 {
    gap: 8px;
  }

  .fs-8 {
    font-size: 8px !important;
  }

  .fs-14 {
    font-size: 14px !important;
  }

  .fs-16 {
    font-size: 16px !important;
  }

  .fs-24 {
    font-size: 24px !important;
  }

  // scroll
  /* Thanh cuộn cho Firefox */
  // html, body{
  //   scrollbar-width: thin;
  //   scrollbar-color: #dddddd #f4f4f4;
  // }

  /* Thanh cuộn cho WebKit (Chrome, Edge, Safari) */
  ::-webkit-scrollbar {
    width: 6px;
    height: 8px;
  }

  ::-webkit-scrollbar-track {
    background: #f4f4f4;
  }

  ::-webkit-scrollbar-thumb {
    background: #dddddd;
    border-radius: 8px;
  }

  ::-webkit-scrollbar-thumb:hover {
    background: #c1c1c1;
  }
  // END scroll

  html,
  body {
    height: 100%;
    width: 100%;
    line-height: 1.5;
    color: #4a4a4a;
  }

  #app {
    min-height: 100%;
    min-width: 100%;
    display: flex;
    justify-content: space-between;
    flex-direction: column;
    background: linear-gradient(180deg, #26A07A 0%, #0252A8 100%);
    @media ${(p) => p.theme.breakpoints.mobile} {
      background: white;
    }
  }

  .non-touch {
    pointer-events: none;
  }

  a {
    &:hover {
      text-decoration: none;
    }
  }

  a, button {
    &:focus, &:active {
      outline: 0;
    }
  }
  .container{
    @media only screen and (min-width: 961px) {
      width: 780px;
      margin: auto;
      margin-top:40px;
    }
    @media only screen and (max-width: 961px) {
      width: 100%;
      margin: auto;
    }
  }
  img {
    max-width: 100%;
  }

  ul {
    margin: 0;
    padding: 0;
    list-style: none;
  }

  .errorText {
    color: red;
    font-size: 11px;
  }

  .autoSuggestionItem {
    color: #092f51;
    cursor: pointer;
    font-size: 14px;
    padding: 3px 20px;
    font-family: 'SVN_Gilroy';
    &:hover {
      background: #bfbaba1c;
    }
  }

  .Mui-error.MuiFormHelperText-contained {
    color: #f50700cf !important;;
    font-size: 11px;
    margin-left: 11px;
    margin-right: 11px;
    font-family: 'SVN_Gilroy';
  }

  ._codeError {
    right: 0;
    bottom: 0;
    opacity: 0.2;
    color: #092f5173;
    font-size: 10px;
    position: fixed;
    font-weight: 500;
    line-height: 15px;
    z-index: 100000000000;
    font-family: 'SVN_Gilroy';
  }

  .MuiDialogContent-root::-webkit-scrollbar {
    height: 1px;
  }

  .MuiDialogContent-root::-webkit-scrollbar {
    width: 5px;
  }
  .MuiDialogContent-root::-webkit-scrollbar-track {
    background-color: white;
  }
  .MuiDialogContent-root::-webkit-scrollbar-thumb {
    background: var(--navy-100, #cdd7e2);
    border-radius: 10px;
    width: 2px;
  }

  .justify-between{
    justify-content: space-between
  }

  .isDesktop {
    display: block;
    @media ${(p) => p.theme.breakpoints.mobile} {
      display: none;
    }
  }

  .isMobile {
    display: none;
    @media ${(p) => p.theme.breakpoints.mobile} {
      display: block;
    }
  }
`;

export default GlobalStyle;
