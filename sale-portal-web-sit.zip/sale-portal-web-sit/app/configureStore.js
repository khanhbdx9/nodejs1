import { createStore, applyMiddleware, compose } from "redux";
import createSagaMiddleware from "redux-saga";
import { NODE_ENV } from "@utils/constants";
import history from '@utils/history';

import createReducer from "./reducers";

export function configureStore(initialState = {}) {
  let composeEnhancers = compose;
  const reduxSagaMonitorOptions = {};

  if (NODE_ENV !== "production" && typeof window === "object") {
    if (window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__)
      composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({});
  }

  const sagaMiddleware = createSagaMiddleware(reduxSagaMonitorOptions);
  const middlewares = [sagaMiddleware];
  const enhancers = [applyMiddleware(...middlewares)];

  const store = createStore(
    createReducer(),
    initialState,
    composeEnhancers(...enhancers)
  );

  // Extensions for dynamic reducer/saga injection
  store.runSaga = sagaMiddleware.run;
  store.injectedReducers = {};
  store.injectedSagas = {}; 

  // Dynamic reducer injection
  store.injectReducer = (key, reducer) => {
    if (!store.injectedReducers[key]) {
      store.injectedReducers[key] = reducer;
      store.replaceReducer(createReducer(store.injectedReducers));
    }
  };

  // Dynamic saga injection
  store.injectSaga = (key, saga) => {
    if (!store.injectedSagas[key]) {
      const task = store.runSaga(saga);
      store.injectedSagas[key] = task;
    }
  };

  return store;
}


const initialState = {};
export const store = configureStore(initialState, history);
