import { createRoutine } from 'redux-saga-routines';

import * as CONSTANT from './constants';

export function setLoadingAction(payload) {
  return {
    type: CONSTANT.SET_LOADING_ACTION,
    payload,
  };
}

export function setTokenAction(payload) {
  return {
    type: CONSTANT.SET_TOKEN_ACTION,
    payload,
  };
}

export function setUserInfoAction(payload) {
  return {
    type: CONSTANT.SET_USER_INFO_ACTION,
    payload,
  };
}

export function resetDataGlobalAction() {
  return {
    type: CONSTANT.RESET_DATA_GLOBAL_ACTION,
  };
}

export const setFieldValueGlobalAction = (key, value) => ({
  type: CONSTANT.SET_FIELD_VALUE_GLOBAL_ACTION,
  payload: { key, value }
})

export const listProvinceAction = createRoutine(CONSTANT.GET_PROVINCE_ACTION);

export const settingEkycAction = createRoutine(CONSTANT.GET_SETTING_EKYC_ACTION);

export const detailByIdAction = createRoutine(CONSTANT.DETAIL_BY_ID_ACTION);

export const branchByProvinceCodeAction = createRoutine(CONSTANT.BRANCH_BY_PROVINCE_CODE_ACTION);

export const cutOffTimeAction = createRoutine(CONSTANT.CUT_OFF_TIME_ACTION);
