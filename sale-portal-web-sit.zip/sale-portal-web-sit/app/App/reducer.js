import { TOKEN_SESSION, USER_INFO, TOKEN_KEY } from "@utils/constants";
import SessionStorageService from "@utils/storage/session";
import { produce } from "immer";
import getLd from "lodash/get";

import {
  cutOffTimeAction,
  detailByIdAction,
  settingEkycAction,
  listProvinceAction,
  branchByProvinceCodeAction,
} from "./actions";
import {
  SET_TOKEN_ACTION,
  SET_LOADING_ACTION,
  SET_USER_INFO_ACTION,
  RESET_DATA_GLOBAL_ACTION,
  SET_FIELD_VALUE_GLOBAL_ACTION,
} from "./constants";
import { setCookie } from "../utils/cookie";

export const initialState = {
  isLoading: false,
  settingEkyc: null,

  userInfo: SessionStorageService.getItem(USER_INFO) || {},
  token: SessionStorageService.getItem(TOKEN_SESSION) || {},

  detail: {},
  provinceOpt: [],
  branchOpt: [],
  cutOffTime: {}
};

const appReducer = (state = initialState, action) =>
  produce(state, (draft) => {
    switch (action.type) {
      //------------- REDUX -----------------
      case SET_LOADING_ACTION: {
        draft.isLoading = getLd(action, "payload", false);
        break;
      }

      case SET_USER_INFO_ACTION: {
        draft.userInfo = action?.payload;
        break;
      }

      case SET_TOKEN_ACTION: {
        const payload = {
          ...draft.token,
          ...(action?.payload || {}),
        };

        SessionStorageService.setItem(TOKEN_SESSION, payload);
        setCookie(TOKEN_KEY, payload.detail);
        draft.token = payload;
        break;
      }

      case SET_FIELD_VALUE_GLOBAL_ACTION: {
        draft[action.payload.key] = action.payload.value;
        break;
      } 
      
      case RESET_DATA_GLOBAL_ACTION: {
        draft.detail = initialState.detail;
        draft.branchOpt = initialState.branchOpt;
        break;
      }

      //-------------- SAGA -----------------
      case cutOffTimeAction.REQUEST: {
        draft.cutOffTime = {};
        draft.isLoading = true;
        break;
      }
      case cutOffTimeAction.SUCCESS: {
        draft.cutOffTime = getLd(action, "payload", {});
        draft.isLoading = false;
        break;
      }
      case cutOffTimeAction.FAILURE: {
        draft.isLoading = false;
        break;
      }

      case settingEkycAction.REQUEST: {
        draft.settingEkyc = null;
        draft.isLoading = true;
        break;
      }
      case settingEkycAction.SUCCESS: {
        draft.isLoading = false;
        draft.settingEkyc = getLd(action, "payload.setting");
        break;
      }
      case settingEkycAction.FAILURE: {
        draft.isLoading = false;
        break;
      }

      // app detail
      case detailByIdAction.REQUEST: {
        draft.detail = {};
        break;
      }
      case detailByIdAction.SUCCESS: {
        draft.detail = action?.payload?.detail;
        break;
      }
      case detailByIdAction.FAILURE: {
        draft.detail =  action?.payload;
        break;
      }

      // -------------------------OPTION------------------------------------
      // ----------------PROVINCE--------------
      case listProvinceAction.REQUEST: {
        draft.provinceOpt = [];
        draft.isLoading = true;
        break;
      }
      case listProvinceAction.SUCCESS: {
        draft.isLoading = false;
        draft.provinceOpt = action?.payload?.items;
        break;
      }
      case listProvinceAction.FAILURE: {
        draft.isLoading = false;
        break;
      }
      // ----------------BRANCH--------------
      case branchByProvinceCodeAction.REQUEST: {
        draft.branchOpt = [];
        draft.isLoading = true;
        break;
      }
      case branchByProvinceCodeAction.SUCCESS: {
        draft.isLoading = false;
        draft.branchOpt = action?.payload?.items;
        break;
      }
      case branchByProvinceCodeAction.FAILURE: {
        draft.isLoading = false;
        break;
      }

    }
  });
export default appReducer;
