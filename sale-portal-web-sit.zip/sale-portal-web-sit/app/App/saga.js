import { responseCode, PRODUCTS, PAGE_SIZE_ALL } from "@utils/constants";
import { formatNumber, formatDate1, formatDatetime1, getProductName } from '@utils/helpers';
import KEY from '@utils/injectKey';
import { MESSAGE_SYSTEM } from "@utils/message";
import { URL, apiRequest } from "@utils/services/api";
import get from "lodash/get";
import { toast } from "react-toastify";
import { all, call, put, takeLatest, select } from "redux-saga/effects";

import { 
  detailByIdAction, 
  settingEkycAction, 
  listProvinceAction,
  setUserInfoAction,
  branchByProvinceCodeAction,
  cutOffTimeAction,
} from "./actions";

export function* settingEkycSaga() {
  try {
    yield put(settingEkycAction.request());

    const payload = {
      url: URL.gateway.settingEkyc,
    };

    const { data: res = {} } = yield call(apiRequest.get, payload);
    const { data = {}, meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        yield put(settingEkycAction.success({ setting: { data } }));
        break;
      }
      default: {
        toast.error(get(data, "message", MESSAGE_SYSTEM.error_02));
        yield put(settingEkycAction.failure());
        break;
      }
    }

    toast.error(get(data, "message", MESSAGE_SYSTEM.error_02));
  } catch (error) {
    yield put(settingEkycAction.failure());
    toast.error(get(error, "meta.message", MESSAGE_SYSTEM.default));
  }
}

export function* detailByIdSaga(action) {
  try {
    const { id } = action.payload;

    if (!id) {
      toast.error(MESSAGE_SYSTEM.notFindAppId);
      return;
    }

    yield put(setUserInfoAction({}))
    yield put(detailByIdAction.request());

    const payload = {
      url: URL.unsecure.detailByApplicationId(id),
    };

    const { data: res = {} } = yield call(apiRequest.get, payload);
    const { data = {}, meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        if (!data?.id) {
          toast.error(meta?.message || MESSAGE_SYSTEM.error_02);
          return;
        }

        const detail = { ...data };
        const primaryProducts = Array.isArray(data?.primaryProduct) ? data.primaryProduct : [];
        const additionalProducts = Array.isArray(data?.additionalProduct) ? data.additionalProduct : [];

        const hasMultiplePrimary = primaryProducts.length > 1;
        const mainProduct = primaryProducts[0];
        const baseProduct = PRODUCTS[mainProduct] || {};

        const product = {
          name: hasMultiplePrimary ? getProductName(primaryProducts) : (baseProduct?.subName || baseProduct.name || ''),
          icon: data?.urlCardImage || baseProduct.icon || '',
        };

        Object.assign(detail, {
          expiryDateFormat: formatDate1(data?.expiryDate),
          dateOfBirthFormat: formatDate1(data?.dateOfBirth),
          createdAtFormat: formatDatetime1(data?.createdAt),
          primaryProductName: product.name,
          primaryProductIcon: product.icon,
          productType: mainProduct,
          feeInsuranceFormat: formatNumber(`${data?.feeInsurance || '0'}`),
          customerLoanAmountFormat: formatNumber(`${data?.customerLoanAmount || '0'}`),
          finalApprovedLimitFormat: formatNumber(`${data?.finalApprovedLimit || '0'}`),
          additionalProductText: getProductName(additionalProducts),
        });

        // set lại thông tin user để cập nhập trên header
        yield put(setUserInfoAction({
          mainUsername: detail?.fullName || '',
        }));

        yield put(detailByIdAction.success({ detail }));
        break;
      }
      default: {
        toast.error(meta?.message || MESSAGE_SYSTEM.error_02);
        yield put(detailByIdAction.failure({
          step: meta?.message || MESSAGE_SYSTEM.notFound
        }));
        break;
      }
    }
  } catch (error) {
    toast.error(get(error, "meta.message", MESSAGE_SYSTEM.default));
    yield put(detailByIdAction.failure({
      step: JSON.stringify(error)
    }));
  }
}

export function* listProvinceSaga() {
  try {
    const { provinceOpt = [] } = yield select(state => state[KEY.GLOBAL]) || {};
    
    // ------Trong 1 phiên làm việc nếu provinces đã có dữ liệu sẽ cache và không gọi lại
    if(Array.isArray(provinceOpt) && provinceOpt.length) return


    yield put(listProvinceAction.request());

    const payload = {
      url: URL.core.province,
    };

    const { data: res = {} } = yield call(apiRequest.get, payload);
    const { data = [], meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        yield put(listProvinceAction.success({ items: data  }));
        break;
      }
      default: {
        toast.error(get(data, "message", MESSAGE_SYSTEM.provice));
        yield put(listProvinceAction.failure());
        break;
      }
    }
  } catch (error) {
    yield put(listProvinceAction.failure());
    toast.error(get(error, "meta.message", MESSAGE_SYSTEM.default));
  }
}

export function* branchByProvinceCodeSaga({ payload }) {
  try {
    if(!payload?.provinceCode) return;

    yield put(branchByProvinceCodeAction.request());

    const request = {
      url: URL.core.deliveryBranch,
      params: {
        page: 0,
        size: PAGE_SIZE_ALL,
        province_code: payload?.provinceCode
      }
    };

    const { data: res = {} } = yield call(apiRequest.get, request);
    const { data = [], meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        yield put(branchByProvinceCodeAction.success({ items: data  }));
        break;
      }
      default: {
        toast.error(get(data, "message", MESSAGE_SYSTEM.provice));
        yield put(branchByProvinceCodeAction.failure());
        break;
      }
    }
  } catch (error) {
    yield put(branchByProvinceCodeAction.failure());
    toast.error(get(error, "meta.message", MESSAGE_SYSTEM.default));
  }
}

export function* cutOffTimeSaga({ payload }) {
  try {
    yield put(cutOffTimeAction.request());
    const request = {
      url: URL.core.getWorkingTime,
      params: {
        productType: payload
      }
    };

    const { data: res = {} } = yield call(apiRequest.get, request);
    const { data = {}, meta = {} } = res;

    let cutOffTime = yield select(state => get(state, 'global.cutOffTime', {}));

    if (meta?.code === 'IL-200' && data) {
      return yield put(cutOffTimeAction.success({
        ...cutOffTime,
        ...data
      }));
    }

    yield put(cutOffTimeAction.failure());
  } catch (error) {
    yield put(cutOffTimeAction.failure());
    toast.error(get(error, "meta.message", MESSAGE_SYSTEM.default));
  }
}

export default function* watchAll() {
  yield all([
    takeLatest(cutOffTimeAction.TRIGGER, cutOffTimeSaga),
    takeLatest(detailByIdAction.TRIGGER, detailByIdSaga),
    takeLatest(settingEkycAction.TRIGGER, settingEkycSaga),
    takeLatest(listProvinceAction.TRIGGER, listProvinceSaga),
    takeLatest(branchByProvinceCodeAction.TRIGGER, branchByProvinceCodeSaga),
  ]);
}
