import Loading from '@components/Loading'
import AppRouter from "@routers";
import { VERSION } from "@utils/constants";
import { useSearchParams } from '@utils/helpers'
import React from "react";
import { ToastContainer } from "react-toastify";

import GlobalStyle from "../global-styles";

const App = () => {

  return (
    <React.Fragment>
      <GlobalStyle />

      <Loading />

      <AppRouter />

      <ToastContainer delay={3000} style={{ zIndex: 100000 }} />
      
      <span id="codeError" className="_codeError">
        {VERSION}
      </span>
    </React.Fragment>
  );
}

export default App;
