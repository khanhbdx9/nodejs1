import LoadingIndicator from '@components/LoadingIndicator';
import KEY from '@utils/injectKey';
import { useInjectReducer } from '@utils/injectReducer';
import { useInjectSaga } from '@utils/injectSaga';
import loadable from '@utils/loadable';
import PropTypes from 'prop-types';

import reducer from './reducer';
import saga from './saga';

const Provider = ({ children }) => {
  useInjectReducer({ key: KEY.GLOBAL, reducer });
  useInjectSaga({ key: KEY.GLOBAL, saga });

  return <>{children}</>;
};

Provider.propTypes = {
  children: PropTypes.node.isRequired,
};

const App = loadable(() => import('./Main'), {
  fallback: <LoadingIndicator />,
  provider: Provider,
});

export default App;
