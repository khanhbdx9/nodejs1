import React from "react";
import { ThemeProvider as MUIThemeProvider } from "@mui/material/styles";
import { ThemeProvider as StyledThemeProvider } from "styled-components";
import PropTypes from "prop-types";

import { MuiTheme, StyledTheme } from "./theme";

const ThemeProvider = (props) => {
  return (
    <MUIThemeProvider theme={MuiTheme}>
      <StyledThemeProvider theme={StyledTheme}>
        {React.Children.only(props.children)}
      </StyledThemeProvider>
    </MUIThemeProvider>
  );
};

ThemeProvider.propTypes = {
  children: PropTypes.element.isRequired,
};

export default ThemeProvider;
