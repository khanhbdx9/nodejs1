import VPB_COLOR from './colors';

export default {
  MuiButton: {
    styleOverrides: {
      root: {
        textTransform: "none",
        borderRadius: 8,
        fontSize: 16,
        fontWeight: "500",
        height: 44,
        padding: "10px 16px",
        transition: "all 0.3s ease-in-out",
      },

      // ✅ Variant: Contained
      containedPrimary: {
        background: VPB_COLOR.lightGreen,
        color: VPB_COLOR.white,
        boxShadow: `0px 2px 6px rgba(0, 0, 0, 0.05)`,
        transition: "all 0.2s ease",
        "&:hover": {
          background: VPB_COLOR.lightGreen,
          transform: "translateY(-1px)", // Giảm dịch chuyển
          boxShadow: `0px 4px 12px rgba(0, 0, 0, 0.1)`,
        },
        "&:active": {
          transform: "translateY(0px)",
          boxShadow: `0px 2px 6px rgba(0, 0, 0, 0.1)`,
          opacity: 0.9, // Hiệu ứng mờ nhẹ khi bấm
        },
      },

      containedSecondary: {
        background: VPB_COLOR.lightGreen,
        color: VPB_COLOR.white,
        transition: "all 0.2s ease",
        "&:hover": {
          background: VPB_COLOR.lightGreen,
          transform: "translateY(-1px)",
          boxShadow: "0px 3px 10px rgba(76, 175, 80, 0.3)",
        },
        "&:active": {
          transform: "translateY(0px)",
          boxShadow: "0px 2px 6px rgba(76, 175, 80, 0.2)",
          opacity: 0.9,
        },
      },

      // ✅ Variant: Outlined
      outlinedPrimary: {
        border: `1px solid ${VPB_COLOR.lightGreen}`,
        color: VPB_COLOR.lightGreen,
        transition: "all 0.2s ease",
        "&:hover": {
          backgroundColor: `${VPB_COLOR.lightGreen}10`, // Màu nền nhẹ hơn
        },
        "&:active": {
          backgroundColor: `${VPB_COLOR.lightGreen}20`,
          opacity: 0.9,
        },
      },

      outlinedSecondary: {
        border: `1px solid ${VPB_COLOR.neutra1}`,
        color: VPB_COLOR.neutral,
        transition: "all 0.2s ease",
        "&:hover": {
          backgroundColor: `${VPB_COLOR.lightBlue}10`,
        },
        "&:active": {
          backgroundColor: `${VPB_COLOR.lightBlue}20`,
          opacity: 0.9,
        },
      },

      // ✅ Variant: Text
      textPrimary: {
        color: VPB_COLOR.neutral,
        transition: "all 0.2s ease",
        "&:hover": {
          backgroundColor: "transparent",
          textDecoration: "underline",
          opacity: 0.8, // Hiệu ứng mờ nhẹ khi hover
        },
      },

      textSecondary: {
        color: VPB_COLOR.neutral,
        transition: "all 0.2s ease",
        "&:hover": {
          backgroundColor: "transparent",
          textDecoration: "underline",
          opacity: 0.8,
        },
      },

    },
  },
};