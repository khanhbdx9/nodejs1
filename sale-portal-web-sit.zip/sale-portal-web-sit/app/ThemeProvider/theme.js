import { createTheme } from "@mui/material";

import VPB_COLOR from "./colors";
import overrides from "./overrides";

const fontFamily = "'SVN_Gilroy'";
const mobileSize = "600px";

function getBreakPoint(width) {
  return `only screen and (max-width: ${width}px)`;
}

export const breakpoints = {
  mobile: getBreakPoint(600),
  tablet: getBreakPoint(768),
  laptop: getBreakPoint(1080),
  desktop: getBreakPoint(1370),
  desktopXl: getBreakPoint(1660),
};

export const MuiTheme = createTheme({
  typography: {
    fontFamily,
    body1: {
      fontSize: 14,
    },
  },
  palette: {
    primary: {
      fontSize: 14,
      main: VPB_COLOR.lightGreen,
      contrastText: VPB_COLOR.white,
    },
    secondary: {
      main: VPB_COLOR.lightBlue,
    },
  },
  components: overrides,
});

export const StyledTheme = createTheme({
  colors: { ...VPB_COLOR },
  breakpoints,
  width: {
    mobile: mobileSize,
  },
  font: {
    fontFamily,
  },
  fontSize: {},
});
