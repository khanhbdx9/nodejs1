import ApplicationDetail from '@containers/ApplicationDetail';
import * as PagePortal from '@containers/Portal';

import ROUTE from './constants';

const routerPortal = [
  {
    exact: true,
    path: ROUTE.portal.ApplicationDetail,
    component: ApplicationDetail,
  },
  {
    exact: true,
    path: ROUTE.portal.DowngradeCard,
    component: PagePortal.DowngradeCard,
  },
];

export default routerPortal;
