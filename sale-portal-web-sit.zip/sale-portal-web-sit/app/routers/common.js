import * as PageCommon from '@containers/Commons';

import ROUTE from './constants';

const routerCommon = [
  {
    exact: true,
    path: ROUTE.common.ListApplication,
    component: PageCommon.ListApplication,
  },
  {
    exact: true,
    path: ROUTE.common.Otp,
    component: PageCommon.Otp,
  },
  {
    exact: true,
    path: ROUTE.common.OCRInstruction,
    component: PageCommon.OCRInstruction,
  },
  {
    exact: true,
    path: ROUTE.common.OCRCaptureFront,
    component: PageCommon.OCRCaptureFront,
  },
  {
    exact: true,
    path: ROUTE.common.OCRCaptureQR,
    component: PageCommon.OCRCaptureQR,
  },
  {
    exact: true,
    path: ROUTE.common.Liveness,
    component: PageCommon.Liveness,
  },
  {
    exact: true,
    path: ROUTE.common.Reject,
    component: PageCommon.ApplicationReject,
  },
];

export default routerCommon;
