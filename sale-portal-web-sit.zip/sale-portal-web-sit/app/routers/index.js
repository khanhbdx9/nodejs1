import history from "@utils/history";
import RouterInterceptor from '@utils/routerInterceptor';
import { Router, Switch, Route } from "react-router-dom";

import routerCommon from "./common";
import routerPortal from "./portal";
import routerUnLayout from "./unLayout";

const RouteUnLayoutWrapper = (router) => <Route {...router} />;

const AppRouter = () => {
  return (
    <Router history={history}>
      <Switch>
        {/* with layout default */}
        {[...routerCommon, ...routerPortal].map(_r => (
          <RouterInterceptor 
            {..._r} 
            key={`${_r?.component}-${_r?.path}`} 
          />
        ))}

        {/* without layout default page */}
        {routerUnLayout.map(_r => (
          <RouteUnLayoutWrapper 
            {..._r}
            key={`${_r?.component}-${_r?.path}`} 
          />
        ))}
      </Switch>
    </Router>
  );
};

export default AppRouter;
