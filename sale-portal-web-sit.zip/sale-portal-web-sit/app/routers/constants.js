const ROUTE = {
  common: {
    Otp: '/otp',
    Login: '/login',
    ListApplication: '/danh-sach',
    OCRCaptureQR: "/ocr-qr",
    OCRCaptureBack: '/ocr-back',
    OCRCaptureFront: '/ocr-front',
    ChangeDevice: '/change-device',
    OCRInstruction: '/ocr-instruction',
    Liveness: '/liveness',
    Reject: '/reject',
    ViewPdf: '/view-doc',
  },
  portal: {
    Zalo: `/ho-so`,
    ApplicationDetail: `/ho-so/:id`,
    DowngradeCard: `/chon-lai-the`,
  }
}

export default ROUTE;