import NotFound from "@containers/404";
import Login from "@containers/Commons/Login";
import ViewPdf from "@containers/Commons/ViewPdf";
import Zalo from "@containers/Portal/Zalo";

import ROUTE from './constants';

const routerUnLayout = [
  {
    exact: true,
    path: ROUTE.common.Login,
    component: Login,
  },
  {
    exact: true,
    path: ROUTE.portal.Zalo,
    component: Zalo,
  },
  {
    exact: true,
    path: ROUTE.common.ViewPdf,
    component: ViewPdf,
  },
  {
    path: '*',
    component: NotFound,
  },
];

export default routerUnLayout;
