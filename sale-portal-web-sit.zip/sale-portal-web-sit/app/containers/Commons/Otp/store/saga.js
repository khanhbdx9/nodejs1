import { setLoadingAction, setTokenAction, setUserInfoAction } from "@App/actions";
import ROUTE from "@routers/constants";
import { TOKEN_KEY, USER_INFO } from "@utils/constants";
import { responseCode } from "@utils/constants";
import history from "@utils/history";
import KEY from "@utils/injectKey";
import { MESSAGE_SYSTEM } from "@utils/message";
import { URL, apiRequest } from "@utils/services/api";
import SessionStorageService from "@utils/storage/session";
import { jwtDecode } from "jwt-decode";
import get from "lodash/get";
import { toast } from 'react-toastify';
import { all, call, put, takeLatest } from "redux-saga/effects";

import { resendOTPAction, verifyOTPAction } from "./actions";

export function* verifyOTPActionSaga({ payload }) {
  const request = {
    url: URL.unsecure.verifyOtp,
    data: payload,
  };
  yield put(setLoadingAction(true));
  yield put(verifyOTPAction.request());
  try {
    const respond = yield call(apiRequest.post, request);
    const { data, meta } = get(respond, "data") || {};

    if (get(meta, "code") === responseCode["IL-200"] && data) {
      if (get(data, "token")) {
        yield put(verifyOTPAction.success());

        // clear all session data
        SessionStorageService.clear();

        // set new session
        const token = data.token;
        const tokenParse = jwtDecode(token);

        const userInfo = {
          phone: tokenParse?.phone || '',
          nationalId: tokenParse?.nationalId || '',
          mainUsername: tokenParse?.mainUsername || '',
          mainAccountCode: tokenParse?.mainAccountCode || '',
        }

        SessionStorageService.setItem(USER_INFO, userInfo);
        SessionStorageService.setItem(TOKEN_KEY, `Bearer ${token}`);

        yield put(setUserInfoAction(userInfo));
        yield put(setTokenAction({[KEY.LIST_APPLICATION]: token}));
        
        history.push(ROUTE.common.ListApplication);
      } else {
        throw {
          meta: {
            message: data.message,
          },
        };
      }
    } else {
      throw {};
    }
  } catch (error) {
    yield put(
      verifyOTPAction.failure(
        get(error, "meta", { message: MESSAGE_SYSTEM.default })
      )
    );
  } finally {
    yield put(setLoadingAction(false));
  }
}

export function* resendOTPActionSaga() {
  try {
    // check payload before resend
    // if (!get(payload, "nationalId") && !get(payload, "phoneNumber")) {
    //   throw {
    //     meta: {
    //       message: MESSAGE_SYSTEM.notFound,
    //     },
    //   };
    // }
    yield put(setLoadingAction(true));
    yield put(resendOTPAction.request());

    const request = {
      url: URL.unsecure.resendOtp,
      // data: payload,
    };

    const respond = yield call(apiRequest.get, request);
    const { data, meta } = get(respond, "data") || {};

    if (get(meta, "code") === responseCode["IL-200"] && data) {
      if (data.signature) {
        yield put(resendOTPAction.success());
        // Set signature
        SessionStorageService.setItem(TOKEN_KEY, data.signature);
        toast.success(get(data, "message"));
        return;
      }
    }
    throw {
      meta: {
        message: MESSAGE_SYSTEM.notFound,
      },
    };
  } catch (error) {
    yield put(resendOTPAction.failure(get(error, "meta")));
  } finally {
    yield put(setLoadingAction(false));
  }
}

export default function* watchAll() {
  yield all([takeLatest(verifyOTPAction.TRIGGER, verifyOTPActionSaga)]);
  yield all([takeLatest(resendOTPAction.TRIGGER, resendOTPActionSaga)]);
}
