import { produce } from "immer";
import get from "lodash/get";
import { MESSAGE_SYSTEM } from "@utils/message";

import { resendOTPAction, verifyOTPAction } from "./actions";

export const initialState = {
  msgError: "",
  isClearOtp: false,
};

/* eslint-disable default-case, no-param-reassign */
const OtpReducer = (state = initialState, action) =>
  produce(state, (draft) => {
    switch (action.type) {
      case verifyOTPAction.REQUEST: {
        draft.msgError = "";
        break;
      }
      case verifyOTPAction.SUCCESS: {
        draft.msgError = "";
        break;
      }
      case verifyOTPAction.FAILURE: {
        draft.msgError = get(action.payload, "message", MESSAGE_SYSTEM.default);
        break;
      }

      // resend
      case resendOTPAction.REQUEST: {
        draft.isClearOtp = false;
        draft.msgError = "";
        break;
      }
      case resendOTPAction.SUCCESS: {
        draft.isClearOtp = true;
        draft.msgError = "";
        break;
      }
      case resendOTPAction.FAILURE: {
        console.log(action.payload);
        draft.msgError = get(action.payload, "message", MESSAGE_SYSTEM.default);
        // custom 1 vài trường hợp sẽ không clear otp
        draft.isClearOtp = get(action.payload, "isClearOtp", true);
        break;
      }
    }
  });

export default OtpReducer;
