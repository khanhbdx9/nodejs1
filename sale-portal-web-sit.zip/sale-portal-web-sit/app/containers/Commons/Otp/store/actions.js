import { createRoutine } from "redux-saga-routines";
import { VERIFY_OTP_ACTION } from "./constants";
import { RESEND_OTP_ACTION } from "./constants";

export const verifyOTPAction = createRoutine(VERIFY_OTP_ACTION);
export const resendOTPAction = createRoutine(RESEND_OTP_ACTION);
