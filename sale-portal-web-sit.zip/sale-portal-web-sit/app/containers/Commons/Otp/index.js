import React from 'react';
import loadable from '@utils/loadable';

import { useInjectReducer } from '@utils/injectReducer';
import { useInjectSaga } from '@utils/injectSaga';

import LoadingIndicator from '@components/LoadingIndicator';

import saga from './store/saga';
import reducer from './store/reducer';
import KEYS from "@utils/injectKey";

const Provider = ({ children }) => {
  useInjectReducer({ key: KEYS.OTP, reducer });
  useInjectSaga({ key: KEYS.OTP, saga });

  return <>{children}</>;
};

const Otp = loadable(() => import('./Main'), {
  fallback: <LoadingIndicator />,
  provider: Provider,
});

export default Otp;
