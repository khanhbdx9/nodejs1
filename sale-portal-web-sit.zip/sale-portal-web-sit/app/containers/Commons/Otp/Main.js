import OtpInput from "@components/OtpInput";
import { OTP_REQUEST } from "@utils/constants";
import useShallowEqualSelector from "@utils/hooks/useShallowEqualSelector";
import KEYS from "@utils/injectKey";
import SessionStorageService from "@utils/storage/session";
import get from "lodash/get";
import { useDispatch } from "react-redux";

import { resendOTPAction, verifyOTPAction } from "./store/actions";

function OtpComponent() {
  const dispatch = useDispatch();
  const { msgError } = useShallowEqualSelector(KEYS.OTP, ["msgError"]);
  const otpRequest = SessionStorageService.getItem(OTP_REQUEST);

  const onVerifyOtp = (otpCode) => {
    dispatch(
      verifyOTPAction({
        otpCode,
        phoneNumber: get(otpRequest, "phoneNumber"),
      })
    );
  };

  const onResendOtp = () => {
    dispatch(resendOTPAction());
  };

  return (
    <OtpInput
      phoneNumber={get(otpRequest, "phoneNumber")}
      errorText={msgError}
      onSubmit={onVerifyOtp}
      onResendOtp={onResendOtp}
    />
  );
}

export default OtpComponent;
