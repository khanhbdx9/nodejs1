import React, { useEffect, useState } from "react";
import { Backdrop, CircularProgress } from "@mui/material";
// import { makeStyles } from '@mui/material/styles';
import { useParams } from "react-router-dom";
import VPB_COLOR from "@ThemeProvider/colors";
// import * as pdfjs from 'pdfjs-dist';
import queryString from "query-string";
import { ROOT_URI } from "@utils/constants";
// import { toast } from 'react-toast';
import "pdfjs-dist/web/pdf_viewer.css";
import * as pdfjs from "pdfjs-dist/build/pdf.js";
import { toast } from "react-toastify";
import { useDispatchRedux } from "@utils/hooks/useRedux";
import { setLoadingAction } from "@App/actions";
import { URL as ApiUrl } from "@utils/services/api";

console.log(pdfjs.version);
pdfjs.GlobalWorkerOptions.workerSrc =
  "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.worker.js";

const PdfViewer = ({ url, setLoadingApp }) => {
  const [numPages, setNumPages] = useState(0);
  const [canvasRefs, setCanvasRefs] = useState([]);
  const [handlerError, setHandlerError] = useState(false);
  useEffect(() => {
    const loadingTask = pdfjs.getDocument(url);
    // const loadingTask = pdfjs.getDocument({ data: url });
    loadingTask.promise
      .then(async (pdf) => {
        // const thumbPromises = [];
        setHandlerError(false);

        setNumPages(pdf.numPages);

        const canvasArray = Array.from({ length: pdf.numPages }, () =>
          React.createRef()
        );
        setCanvasRefs(canvasArray);

        for (let i = 1; i <= pdf.numPages; i++) {
          await renderPage(i, pdf, canvasArray[i - 1]);
        }
      })
      .catch((err) => {
        console.log(err, "tiss err");
        setHandlerError(true);
      }).finally(() => setLoadingApp(false));;
  }, [url]);

  const renderPage = async (pageNum, pdf, canvasRef) => {
    const page = await pdf.getPage(pageNum);
    const viewport = page.getViewport({ scale: 1 });
    const canvas = canvasRef.current;
    const context = canvas.getContext("2d");
    canvas.height = viewport.height;
    canvas.width = viewport.width;

    await page.render({
      canvasContext: context,
      viewport,
    }).promise;
  };
  return (
    <React.Fragment>
      <div
        style={{
          height: 35,
          background: "#3f3e3e",
          color: "white",
          display: "flex",
          alignItems: "center",
        }}
      >
        Tổng số trang: {numPages}
      </div>

      {/* <div> */}
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          background: "gray",
        }}
      >
        {!handlerError &&
          canvasRefs.map((canvasRef, index) => (
            <canvas key={index} ref={canvasRef} style={{ margin: "10px 0" }} />
          ))}
        {handlerError && (
          <div>
            <h2>Hiện tại không thể mở đc file docs vui lòng thử lại sau</h2>
          </div>
        )}
      </div>
      {/* </div> */}
    </React.Fragment>
  );
};
const BASE64_MARKER = ";base64,";

function convertDataURIToBinary(dataURI) {
  const base64Index = dataURI.indexOf(BASE64_MARKER) + BASE64_MARKER.length;
  const base64 = dataURI.substring(base64Index);
  const raw = window.atob(base64);
  const rawLength = raw.length;
  const array = new Uint8Array(new ArrayBuffer(rawLength));

  for (let i = 0; i < rawLength; i++) {
    array[i] = raw.charCodeAt(i);
  }
  return array;
}
const contextBlock = (e) => {
  e.preventDefault();
};
const clickBlock = (e) => {
  if (
    e.key === "s" &&
    (navigator.userAgent.includes("Mac") ? e.metaKey : e.ctrlKey)
  ) {
    e.preventDefault();
  }
  if (
    e.key === "c" &&
    (navigator.userAgent.includes("Mac") ? e.metaKey : e.ctrlKey)
  ) {
    e.preventDefault();
  }
  if (
    e.key === "p" &&
    (navigator.userAgent.includes("Mac") ? e.metaKey : e.ctrlKey)
  ) {
    e.preventDefault();
  }
  if (
    e.key === "o" &&
    (navigator.userAgent.includes("Mac") ? e.metaKey : e.ctrlKey)
  ) {
    e.preventDefault();
  }
  if (e.key === "PrintScreen") {
    e.preventDefault();
  }
};

const Main = (props) => {
  const { id } = useParams();
  const setLoadingApp = useDispatchRedux(setLoadingAction);
  const params = queryString.parse(props.location.search);

  const [pdfBlob, setPdfBlob] = useState("");
  const [imgBlob, setImgBlob] = useState("");
  const [error, setError] = useState();

  const isPdf = params.fileName.split(".").pop() === "pdf";

  const convertSetPdf = (req) => {
    const blob = new Blob([req], { type: "application/pdf" });
    const reader = new FileReader();
    reader.readAsDataURL(blob);
    reader.onloadend = () => {
      const base64data = reader.result;
      const arrayData = convertDataURIToBinary(base64data);
      setPdfBlob(arrayData);
    };
  };

  const convertSetImg = (req) => {
    const blob = new Blob([req], { type: "application/pdf" });
    const url = URL.createObjectURL(blob);
    setImgBlob(url);
  };

  const downloadPDFFetch = () => {
    setError();
    setLoadingApp(true);
    const myHeaders = new Headers();

    let token = localStorage["IL_ADMIN_TOKEN"];
    let url = ApiUrl.unsecure.downloadDocument

    if(params?.encryp){
      token = `Bearer ${params.encryp}`;
      url = ApiUrl.gateway.getFileHhb;

      delete params.encryp;
    }
    myHeaders.append("authorization", token);
    
    const requestOptions = {
      method: "GET",
      headers: myHeaders,
    };

    fetch(`${ROOT_URI}/${url}?folderName=${params?.folderName || ''}&fileName=${params?.fileName || ''}`, requestOptions)
      .then((data) => {
        if (data.status === 400) {
          return data.json();
        }
        return data.arrayBuffer();
      })
      .then((dataReq) => {
        if (dataReq?.meta?.result_msg) {
          toast.error(dataReq.meta.result_msg || "Có lỗi xảy ra");
          return;
        }

        if (isPdf) {
          convertSetPdf(dataReq);
          return;
        }

        convertSetImg(dataReq);
      })
      .catch((err) => setError(err))
      .finally(() => !isPdf && setLoadingApp(false));
  };
  const blockContextMenu = () => {
    document.addEventListener("contextmenu", contextBlock);
    document.addEventListener("keydown", clickBlock, false);
  };
  const removeBlockEvent = () => {
    document.removeEventListener("contextmenu", contextBlock);
    document.removeEventListener("keydown", clickBlock, false);
  };
  useEffect(() => {
    downloadPDFFetch(id);
    blockContextMenu();
    return () => {
      removeBlockEvent();
    };
  }, []);

  return (
    <div style={{ flex: 1, background: VPB_COLOR.white }}>
      {!isPdf && imgBlob && (
        <div style={{ flex: 1 }} className="dgrid">
          <img src={imgBlob} alt="img" />
        </div>
      )}

      {isPdf && pdfBlob && <PdfViewer url={pdfBlob} setLoadingApp={setLoadingApp} />}
    </div>
  );
};
export default Main;
