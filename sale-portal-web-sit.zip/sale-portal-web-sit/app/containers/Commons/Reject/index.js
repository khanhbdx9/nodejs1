import { IMGCancelApp } from '@assets/images'
import { ApplicationName } from "@components/Detail";
import SalesSupportCard from '@components/SalesSupportCard';

import useLogicApplictionReject from './hooks';
import ApplicationRejectContainer from './Styled'

const ApplicationReject = () => {
  const { detail } = useLogicApplictionReject()

  return (
    <ApplicationRejectContainer>
      <ApplicationName name={`Hồ sơ: ${detail?.appId || ""}`} />

      <SalesSupportCard
        image={IMGCancelApp}
        title="Hồ sơ bị từ chối"
        titleSaleBox="Nhân viên hỗ trợ"
        desc="Rất tiếc thông tin bạn đăng ký đã bị từ chối do chưa đạt đủ điều kiện. Chúng tôi sẽ lưu lại thông tin và liên hệ lại bạn trong thời gian sớm nhất."
        saleFullName={detail?.saleFullName}
        salePhoneNumber={detail?.salePhoneNumber}
      />
    </ApplicationRejectContainer>
  )
}

export default ApplicationReject