import { detailByIdAction } from '@App/actions'
import { useSearchParams } from '@utils/helpers'
import useShallowEqualSelector from "@utils/hooks/useShallowEqualSelector";
import KEY from "@utils/injectKey";
import { useEffect } from 'react'
import { useDispatch } from 'react-redux';

const useLogicApplictionReject = () => {
  const dispatch = useDispatch();

  const { id } = useSearchParams();

  const { detail = {} } = useShallowEqualSelector(KEY.GLOBAL, ['detail'])

  useEffect(()=>{
    if(id) {
      setTimeout(()=>dispatch(detailByIdAction({ id })),150)
    }
  }, [id]);

  return {
    detail,
  }
}

export default useLogicApplictionReject