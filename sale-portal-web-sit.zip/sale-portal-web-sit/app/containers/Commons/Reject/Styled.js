import Box from "@mui/material/Box";
import styled from "styled-components";

const ApplicationRejectContainer = styled(Box)`
  .__cardContainer {
    padding: 24px;
    @media ${(p) => p.theme.breakpoints.tablet} {
      padding: 16px;
    }
  }
`;

export default ApplicationRejectContainer;
