import TabsWithTransition from '@components/TabsWithTransition'
 
import TabCancelledApplicationsList from './components/TabCancelledApplicationsList';
import TabProcessingApplicationsList from './components/TabProcessingApplicationsList';
import useLogicListApplication from './hooks';
import { ListApplicationContainer } from "./Styled";

const Main = () => {
  const { onRedirectDetailByStatus } = useLogicListApplication();

  const tabData = [
    {
      label: 'Hồ sơ đang xử lý',
      content: (
        <TabProcessingApplicationsList 
          onDetailApplication={onRedirectDetailByStatus}
        />
      ),
    },
    {
      label: "Hồ sơ đã huỷ",
      content: (
        <TabCancelledApplicationsList 
          onDetailApplication={onRedirectDetailByStatus}
        />
      ),
    },
  ];

  return (
    <ListApplicationContainer>
      <TabsWithTransition  
        tabs={tabData} 
        className="tabListApplication"
      />
    </ListApplicationContainer>
  );
};

export default Main;
