import { setTokenAction } from "@App/actions";
import ROUTE from "@routers/constants";
import { TOKEN_KEY } from "@utils/constants";
import history from "@utils/history";
import { useDispatchRedux } from "@utils/hooks/useRedux";
import SessionStorageService from "@utils/storage/session";
import { useEffect } from "react";

import { getListApplicationAction, resetDataAction } from './store/actions';
import { CANCELED } from './store/constants';

const useLogicListApplication = () => {
  const setTokenApp = useDispatchRedux(setTokenAction);
  const resetDataListApplication = useDispatchRedux(resetDataAction);
  const rqListApplication = useDispatchRedux(getListApplicationAction);

  useEffect(() => {
    rqListApplication()

    return () => resetDataListApplication();
  }, []);

  const onRedirectDetailByStatus = ({ id, token, step}) => {
    if (!id || !token) return;
  
    const router = step === CANCELED 
      ? `${ROUTE.common.Reject}?id=${id}` 
      : ROUTE.portal.ApplicationDetail.replaceAll(':id', id);
  
    setTokenApp({ detail: token })

    SessionStorageService.setItem(TOKEN_KEY, `Bearer ${token}`);
    history.push(router);
  };

  return {
    onRedirectDetailByStatus,
  };
};

export default useLogicListApplication;
