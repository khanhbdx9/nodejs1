import { PRODUCTS, APPLICATION_STEP } from '@utils/constants';
import PropTypes from 'prop-types';
import { useMemo } from 'react';

import ActionBox from './components/ActionBox';
import ApplicationStatus from './components/ApplicationStatus';
import ProductInfo from './components/ProductInfo';
import { CardApplicationItemContainer } from './Styled';
import { formatInfoApplication } from '../../helpers';

const CardApplicationItem = ({ application = {}, onDetail = () => {} }) => {
  const {
    appId,
    step,
    primaryProduct,
    additionalProduct,
    cardName,
    urlCardImage,
  } = application;

  const { stepInfo, productInfo, additionalRegisteredProductText } = formatInfoApplication({ step, primaryProduct, cardName, urlCardImage, additionalProduct })

  const handleClick = () => onDetail(application);

  return (
    <CardApplicationItemContainer>
      <ProductInfo
        name={productInfo.name} 
        icon={productInfo.icon} 
        isIcon={productInfo.isIcon} 
      />

      <ApplicationStatus
        appId={appId}
        stepInfo={stepInfo}
        additionalProductText={additionalRegisteredProductText}
      />

      <ActionBox stepInfo={stepInfo} onClick={handleClick} />
    </CardApplicationItemContainer>
  );
};

CardApplicationItem.propTypes = {
  application: PropTypes.shape({
    step: PropTypes.string.isRequired,
    urlCardImage: PropTypes.string,
    cardName: PropTypes.string,
    additionalProduct: PropTypes.oneOfType([
      PropTypes.arrayOf(PropTypes.string),
      PropTypes.oneOf([null]),
    ]),
    primaryProduct: PropTypes.oneOfType([
      PropTypes.arrayOf(PropTypes.string),
      PropTypes.oneOf([null]),
    ]),
    appId: PropTypes.oneOfType([
      PropTypes.string,
      PropTypes.oneOf([null]),
    ]),
  }),
  onDetail: PropTypes.func,
};

export default CardApplicationItem;
