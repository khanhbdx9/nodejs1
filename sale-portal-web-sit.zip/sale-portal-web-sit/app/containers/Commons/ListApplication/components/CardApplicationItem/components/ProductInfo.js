import AppImage from '@components/AppImage';
import { Title } from '@components/Styled/Title';
import Box from '@mui/material/Box';
import VPB_COLOR from '@ThemeProvider/colors';
import PropTypes from 'prop-types';

const ProductInfo = ({ name, icon, isIcon }) => (
  <Box className="infoApp__cardImg">
    <Title
      className="infoApp__cardImg-title"
      $size={18}
      $weight={600}
      $color={VPB_COLOR.lightGreen}
      dangerouslySetInnerHTML={{ __html: name }}
    />
    {isIcon && <AppImage width={105} height={71} src={icon} isOrientation /> }
  </Box>
);

ProductInfo.propTypes = {
  name: PropTypes.string,
  icon: PropTypes.string,
  isIcon: PropTypes.bool,
};

export default ProductInfo;
