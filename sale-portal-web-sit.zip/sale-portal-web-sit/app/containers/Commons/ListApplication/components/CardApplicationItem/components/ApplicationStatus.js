import Box from '@mui/material/Box';
import ListItemText from '@mui/material/ListItemText';
import PropTypes from 'prop-types';

import { StatusBadge } from '../Styled';

const ApplicationStatus = ({ appId, stepInfo, additionalProductText }) => (
  <Box className="infoApp__application">
    <ListItemText primary="Mã hồ sơ:" secondary={appId} />
    <ListItemText
      primary="Trạng thái:"
      secondary={
        stepInfo?.name && <StatusBadge
          bg={stepInfo?.statusAttr?.bg}
          text={stepInfo?.statusAttr?.text}
        >
          {stepInfo.name}
        </StatusBadge>
      }
    />

    {/* hiển thị cho step: khởi tạo hồ sơ, từ chối (từ chối khi chưa hình thành appid) */}
    {stepInfo.step === 1 && (
      <ListItemText primary="SP đăng ký thêm:" secondary={additionalProductText} />
    )}
  </Box>
);

ApplicationStatus.propTypes = {
  appId: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.oneOf([null]),
  ]),
  stepInfo: PropTypes.shape({
    name: PropTypes.string,
    step: PropTypes.number,
    statusAttr: PropTypes.shape({
      bg: PropTypes.string,
      text: PropTypes.string,
    }),
  }),
  additionalProductText: PropTypes.string,
};

export default ApplicationStatus;
