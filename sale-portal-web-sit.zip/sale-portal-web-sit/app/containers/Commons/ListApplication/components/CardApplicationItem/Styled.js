import ListItem from '@mui/material/ListItem';
import VPB_COLOR from '@ThemeProvider/colors';
import styled from 'styled-components';

const StatusBadge = styled.span`
  display: inline-block;
  padding: 3px 16px;
  font-size: 14px;
  font-weight: 500;
  border-radius: 50px;
  text-align: center;
  min-height: 23px;
  width: 100%;
  line-height: 140%;
  background-color: ${({ bg = VPB_COLOR.shade0 }) => bg};
  color: ${({ text = VPB_COLOR.neutral }) => text};
`;

const CardApplicationItemContainer = styled(ListItem)`
  gap: 16px;
  border-radius: 8px;
  background: ${({ theme }) => theme.colors.white};
  box-shadow: 0px 1px 4px rgba(0, 0, 0, 0.03);
  transition: box-shadow 0.3s ease-in-out;
  min-height: 132px;
  width: 100%;

  &.MuiListItem-root {
    padding: 16px;
    align-items: flex-start;
  }

  &:hover {
    box-shadow: 0px 2px 6px rgba(0, 0, 0, 0.075);
  }

  @media ${({ theme }) => theme.breakpoints.tablet} {
    flex-direction: column;
  }

  .infoApp__cardImg {
    display: grid;
    gap: 16px;
    width: 200px;

    .infoApp__cardImg-title {
      text-align: center;
      @media ${({ theme }) => theme.breakpoints.tablet} {
        text-align: left;
        width: calc(100% - 124px);
      } 
    }

    .imgWrap {
      margin: auto;
      @media ${({ theme }) => theme.breakpoints.tablet} {
        margin: unset;
      }
      img {
        object-fit: contain;
      }
    }

    @media ${({ theme }) => theme.breakpoints.tablet} {
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
  }

  .infoApp__application {
    width: 380px;
    padding: 0 16px;
    height: 100%;
    border-left: 1px solid ${({ theme }) => theme.colors.shade0};
    border-right: 1px solid ${({ theme }) => theme.colors.shade0};

    @media ${({ theme }) => theme.breakpoints.tablet} {
      width: 100%;
      padding: 16px 0;
      height: max-content;
      border: unset;
      border-top: 1px solid ${({ theme }) => theme.colors.shade0};
    }

    .MuiListItemText-root {
      display: flex;
      gap: 8px;
      margin: 0 0 16px;
      align-items: center;

      &:last-child {
        margin-bottom: 0;
      }

      @media ${({ theme }) => theme.breakpoints.tablet} {
        justify-content: space-between;
      }

      .MuiListItemText-primary {
        font-size: 14px;
        font-weight: 500;
        line-height: 120%;
        color: ${({ theme }) => theme.colors.neutral};
      }

      .MuiListItemText-secondary {
        font-size: 16px;
        font-weight: 600;
        line-height: 140%;
        max-width: 214px;
        color: ${({ theme }) => theme.colors.darkBlue};
      }
    }
  }

  .infoApp__boxAction {
    flex: 1;
    gap: 8px;
    flex-direction: column;
    display: flex;

    // span {
    //   margin-bottom: 8px;
    // }

    @media ${({ theme }) => theme.breakpoints.tablet} {
      margin: auto;
      width: 100%;
    }
  }
`;

export { StatusBadge, CardApplicationItemContainer };
