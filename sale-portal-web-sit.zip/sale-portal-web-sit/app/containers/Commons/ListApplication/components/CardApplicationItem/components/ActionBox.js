import AppButton from '@components/AppButton';
import { Text } from '@components/Styled/Title';
import Box from '@mui/material/Box';
import VPB_COLOR from '@ThemeProvider/colors';
import PropTypes from 'prop-types';

const ActionBox = ({ stepInfo, onClick }) => (
  <Box className="infoApp__boxAction">
    <Text $color={VPB_COLOR.yellow} $align="center" $size={14} $weight={500}>
      {stepInfo?.note}
    </Text>
    <AppButton fullWidth {...stepInfo?.button?.attr} onClick={onClick}>
      {stepInfo?.button?.name}
    </AppButton>
  </Box>
);

ActionBox.propTypes = {
  stepInfo: PropTypes.shape({
    note: PropTypes.string,
    button: PropTypes.shape({
      name: PropTypes.string,
      attr: PropTypes.object,
    }),
  }),
  onClick: PropTypes.func,
};

export default ActionBox;
