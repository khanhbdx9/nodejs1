import EmptyFilter from '@components/EmptyFilter';
import ListAppFallback from '@Fallback/ListApp';
import List from "@mui/material/List";
import { useOneState } from '@utils/hooks/useRedux';
import KEY from '@utils/injectKey';
import PropTypes from 'prop-types';
import { useMemo } from "react";

import CardApplicationItem from '../CardApplicationItem';

const TabProcessingApplicationsList = ({ 
  onDetailApplication = () => {}
}) => {
  const processings = useOneState(KEY.LIST_APPLICATION, 'processings');
  const isQueryData = useOneState(KEY.LIST_APPLICATION, 'isQueryData');

  const isEmpty = useMemo(() => !(Array.isArray(processings) && processings.length), [processings]);

  if (isQueryData) return <ListAppFallback/>;

  if (isEmpty) return <EmptyFilter />;

  return (
    <List>
      {Array.isArray(processings) && 
        processings.map(_a => (
        <CardApplicationItem
          application={_a}
          key={`${_a?.id}-${_a?.appId}`}
          onDetail={onDetailApplication}
        />
      ))}
    </List>
  );
};

TabProcessingApplicationsList.propTypes = {
  onDetailApplication: PropTypes.func,
};

export default TabProcessingApplicationsList;
