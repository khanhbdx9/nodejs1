import { IcSearch } from '@assets/icons';
import AppImage from '@components/AppImage'
import { Text } from '@components/Styled/Title';
import CloseIcon from '@mui/icons-material/Close';
import SearchIcon from '@mui/icons-material/Search';
import { Box, IconButton } from '@mui/material';
import { LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterMoment } from '@mui/x-date-pickers/AdapterMoment';
import VPB_COLOR from '@ThemeProvider/colors';
import { DateFormat1 } from '@utils/constants'
import useShallowEqualSelector from '@utils/hooks/useShallowEqualSelector'
import KEY from '@utils/injectKey';
import { Formik, Form } from 'formik';
import moment from 'moment';
import { Fragment, useState, memo } from 'react';
import { useDispatch } from 'react-redux';

import DateRangeFields from './DateRangeFields'
import Schema from './validation'
import { filterTabCancelByDateAction } from '../../../store/actions'

const Filter = () => {
  const dispatch = useDispatch();
  const { paramsQueryTabCancel } = useShallowEqualSelector(KEY.LIST_APPLICATION, ['paramsQueryTabCancel'])

  const [isFormSearch, setFormSearch] = useState(false);

  const toggleFormSearch = () => {
    setFormSearch(!isFormSearch)
  }

  const { startDate, endDate} = paramsQueryTabCancel;

  return (
    <LocalizationProvider dateAdapter={AdapterMoment}>
      <Fragment>
        <Box display='flex' alignItems='center' justifyContent='space-between'>
          <Text $weight={500} $size={14}>
            {`Hồ sơ đã huỷ từ: ${moment(startDate).format(DateFormat1)} - ${moment(endDate).format(DateFormat1)}`}
          </Text>
          <IconButton  sx={{  width: 30, height: 30, minWidth: 30, padding: 0 }} onClick={toggleFormSearch}>
            {isFormSearch ? <CloseIcon sx={{ fontSize: 24 }}/> : <AppImage src={IcSearch} width={20} height={25}/>}
          </IconButton>
        </Box>

        <Formik
          initialValues={{ startDate,endDate }}
          validationSchema={Schema}
          onSubmit={(values) => {
            dispatch(filterTabCancelByDateAction(values));
          }}
        >
          {({ handleSubmit }) => (
            <Form onSubmit={handleSubmit}>
              <Box display={isFormSearch ? 'flex' : 'none'} gap={1} mt={2}>
                <DateRangeFields />
                
                <IconButton
                  type="submit"
                  variant="contained"
                  sx={{
                    width: 48,
                    height: 48,
                    minWidth: 48,
                    backgroundColor: VPB_COLOR.darkBlue,
                    borderRadius: 2,
                    color: VPB_COLOR.white,
                  }}
                >
                  <SearchIcon style={{ fontSize: 24, margin: 0 }}/>
                </IconButton>
              </Box>
            </Form>
          )}
        </Formik>
      </Fragment>
      
    </LocalizationProvider>
  );
};

export default memo(Filter);
