import PropTypes from 'prop-types';
import { Fragment } from 'react'

import CancelList from './CancelList'
import Filter from './Filter'

const TabCancelledApplicationsList = ({ onDetailApplication }) => {
  return (
    <Fragment>
      <Filter />
      <CancelList onDetailApplication={onDetailApplication}/>
    </Fragment>
    
  );
};

TabCancelledApplicationsList.propTypes = {
  onDetailApplication: PropTypes.func,
};

export default TabCancelledApplicationsList;
