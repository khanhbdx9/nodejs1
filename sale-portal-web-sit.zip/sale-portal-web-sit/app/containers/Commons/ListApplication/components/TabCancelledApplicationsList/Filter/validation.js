import { DateFormat1 } from '@utils/constants'
import moment from 'moment';
import { date, object } from 'yup';

const Schema = object().shape({
  startDate: date()
    .typeError('Ngày không hợp lệ')
    .required('Vui lòng chọn ngày bắt đầu.')
    .test('is-valid-date', 'Ngày không hợp lệ', (value) =>
      moment(value, DateFormat1, true).isValid()
    ),
  endDate: date()
    .typeError('Ngày không hợp lệ')
    .required('Vui lòng chọn ngày kết thúc.')
    .test('is-valid-date', 'Ngày không hợp lệ', (value) =>
      moment(value, DateFormat1, true).isValid()
    ),
});

export default Schema;
