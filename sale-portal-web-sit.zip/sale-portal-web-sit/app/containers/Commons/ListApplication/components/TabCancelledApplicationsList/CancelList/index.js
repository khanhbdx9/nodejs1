import EmptyFilter from '@components/EmptyFilter';
import LoadingIndicator from '@components/LoadingIndicator'
import List from "@mui/material/List";
import { useOneState } from '@utils/hooks/useRedux';
import KEY from '@utils/injectKey';
import PropTypes from 'prop-types';
import { useMemo } from "react";

import CardApplicationItem from '../../CardApplicationItem';

const CancelList = ({ 
  onDetailApplication = () => {}
}) => {
  const isLoading = useOneState(KEY.LIST_APPLICATION, 'isLoading');
  const filterCancelByDate = useOneState(KEY.LIST_APPLICATION, 'filterCancelByDate');

  const isEmpty = useMemo(() => !(Array.isArray(filterCancelByDate) && filterCancelByDate.length), [filterCancelByDate]);

  if (isLoading) return <LoadingIndicator/>;

  if (isEmpty) return <EmptyFilter />;

  return (
    <List>
      {Array.isArray(filterCancelByDate) && 
        filterCancelByDate.map((_a) => (
        <CardApplicationItem
          application={_a}
          key={`${_a?.id}-${_a?.appId}`}
          onDetail={onDetailApplication}
        />
      ))}
    </List>
  );
};

CancelList.propTypes = {
  onDetailApplication: PropTypes.func,
};

export default CancelList;
