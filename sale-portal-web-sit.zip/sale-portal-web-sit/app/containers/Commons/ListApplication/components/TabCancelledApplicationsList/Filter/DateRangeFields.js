import { Box } from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers';
import { DateFormat1 } from '@utils/constants'
import { useFormikContext } from 'formik';
import moment from 'moment';
import PropTypes from 'prop-types';

import { MAX_RANGE_DAYS } from '../../../store/constants'


const DateRangeFields = ({ startField = 'startDate', endField = 'endDate' }) => {
  const { values, setFieldValue, errors, touched } = useFormikContext();

  const startDate = moment(values[startField]);
  const endDate = moment(values[endField]);

  const maxEndDate = startDate.clone().add(MAX_RANGE_DAYS, 'days');

  return (
    <Box display="flex" gap={1} alignItems="flex-start" sx={{ width: 1 }}>
      <DatePicker
        value={startDate}
        format={DateFormat1}
        maxDate={moment().isValid() ? moment() : undefined}
        onChange={(val) => {
          setFieldValue(startField, val)
          setFieldValue(endField, null)
        }}
        slotProps={{
          textField: {
            size: 'small',
            fullWidth: true,
            error: touched[startField] && Boolean(errors[startField]),
            helperText: touched[startField] && errors[startField],
            sx: {
              '& .MuiInputBase-root': {
                height: 48,
                fontSize: 16,
                fontWeight: 500,
                borderRadius: 2,
                backgroundColor: '#fff',
              },
              '& .MuiOutlinedInput-notchedOutline': {
                border: 'none',
              },
            },
          }
        }}
      />

      <DatePicker
        value={endDate}
        format={DateFormat1}
        minDate={startDate.isValid() ? startDate : undefined}
        maxDate={startDate.isValid() ? maxEndDate : undefined}
        onChange={(val) => setFieldValue(endField, val)}
        slotProps={{
          textField: {
            size: 'small',
            fullWidth: true,
            error: touched[endField] && Boolean(errors[endField]),
            helperText: touched[endField] && errors[endField],
            sx: {
              '& .MuiInputBase-root': {
                height: 48,
                fontSize: 16,
                fontWeight: 500,
                borderRadius: 2,
                backgroundColor: '#fff',
              },
              '& .MuiOutlinedInput-notchedOutline': {
                border: 'none',
              },
            },
          }
        }}
      />
    </Box>
  );
};

DateRangeFields.propTypes = {
  startField: PropTypes.string,
  endField: PropTypes.string,
};

export default DateRangeFields;