import { PRODUCTS, APPLICATION_STEP } from '@utils/constants';
import { getProductName } from '@utils/helpers';
import moment from 'moment';

export const filterByStartEndDate = (items = [], startDate, endDate) => {
  if(!(startDate && endDate)) return [];

  return items.filter((_i) => {
    const createdAt = moment(_i.createdAt);
    return createdAt.isSameOrAfter(startDate, 'day') && createdAt.isSameOrBefore(endDate, 'day');
  })
}

export const formatInfoApplication = ({ step, primaryProduct, cardName, urlCardImage, additionalProduct }) => {
  const stepInfo = APPLICATION_STEP[step] || APPLICATION_STEP.OTHER;

  const isInitStep = stepInfo.key === APPLICATION_STEP.CONFIRM_APP.key;
  const isDisbursementStep = stepInfo.key === APPLICATION_STEP.DISBURSEMENT.key;

  const primaryProducts = Array.isArray(primaryProduct) ? primaryProduct : [];
  const additionalProducts = Array.isArray(additionalProduct) ? additionalProduct : [];

  const hasPrimary = primaryProducts.length > 0;
  const mainProduct = hasPrimary ? primaryProducts[0] : null;
  const baseProduct = PRODUCTS[mainProduct] || {};
  const isCreditCard = mainProduct === 'CC';

  const productInfo = {
    name: '',
    icon: '',
    isIcon: true,
  };

  let additionalRegisteredProductText = '';

  if (isInitStep) {
    // convert lại list sản phẩm bán kèm thành text
    if (additionalProducts.length) additionalRegisteredProductText = getProductName(additionalProducts);

    // convert lại list sản phẩm thành text
    if (hasPrimary)  productInfo.name = getProductName(primaryProducts, ',<br/>')

    productInfo.icon = baseProduct.icon;
    productInfo.isIcon = primaryProducts.length <= 1; // chỉ hiện icon nếu chỉ có 1 sản phẩm
  } else {
    if (isDisbursementStep && stepInfo[`name_${mainProduct}`]) {
      stepInfo.name = stepInfo[`name_${mainProduct}`];
    }

    productInfo.name = isCreditCard
      ? `${baseProduct.name} ${cardName || ''}`.trim()
      : baseProduct.name || '';

    productInfo.icon = isCreditCard && urlCardImage
      ? urlCardImage
      : baseProduct.icon || '';
  }

  return { stepInfo, productInfo, additionalRegisteredProductText };
};