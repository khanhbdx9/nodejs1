import styled from 'styled-components';

export const ListApplicationContainer = styled.div`
  width: 100%;
  height: 100%;
  padding: 24px;
  background: ${({theme}) => theme.colors.shade0};
  @media ${({theme})=>theme.breakpoints.tablet} {
    padding: 16px;
  }

  .tabListApplication {
    gap: 16px;
    display: grid;
    
    .MuiTabs-root{
      max-height: 43px;
    
      .MuiTabs-scroller {
        background: ${({theme}) => theme.colors.white};
        border-radius: 8px;
        max-height: 43px;

        button {
          font-weight: 600;
          border-radius: 8px;
          min-height: 43px;
          font-size: 16px;
          text-transform: none;
          color:  ${({theme}) => theme.colors.neutral};

          &.Mui-selected {
            color:  ${({theme}) => theme.colors.darkBlue};
            background: ${({theme}) => theme.colors.neutra1001};
           
          }
        }
      }
    }
  }
  

  .MuiList-root {
    gap: 16px;
    padding: 0;
    display: grid;
    margin-top: 16px;
  }
`;
