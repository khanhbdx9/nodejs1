import { IcVay, IcWallet } from "@assets/icons"
import { IMGCardDefault } from "@assets/images"
import KEY from '@utils/injectKey'
import moment from 'moment';

export const MAX_RANGE_DAYS = 30;

export const paramsQueryTabCancel = {
  startDate: moment().subtract(MAX_RANGE_DAYS, 'days'),
  endDate: moment(),
}

export const CANCELED = 'CANCELED'

export const PRODUCTS = {
  CC: {
    name: 'Thẻ',
    icon: IMGCardDefault,
  },
  UPL: {
    name: 'Vay',
    icon: IcVay,
  },
  OD: {
    name: "Thấu chi",
    icon: IcWallet,
  },
  CASA: {
    name: "TKTT",
    icon: IcWallet,
  },
  NEO: {
    name: "VPBank NEO",
    icon: IcWallet,
  },
  null: {
    name: "Khác",
    icon: IcWallet,
  }
}

export const RESET_DATA_ACTION = `${KEY.LIST_APPLICATION}/RESET_DATA_ACTION`;
export const GET_LIST_APPLICATION_ACTION = `${KEY.LIST_APPLICATION}/GET_LIST_APPLICATION_ACTION`;
export const FILTER_TAB_CANCEL_BY_DATE_ACTION = `${KEY.LIST_APPLICATION}/FILTER_TAB_CANCEL_BY_DATE_ACTION`;
