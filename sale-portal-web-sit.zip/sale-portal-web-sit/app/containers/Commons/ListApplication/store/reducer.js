import { produce } from 'immer';

import { getListApplicationAction, filterTabCancelByDateAction } from './actions';
import { paramsQueryTabCancel, RESET_DATA_ACTION } from './constants';

export const initialState = {
  isLoading: false,
  isQueryData: true,

  paramsQueryTabCancel,

  processings: [],
  cancelleds: [],

  filterCancelByDate: []
};

const ListApplicationReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      // action saga
      case getListApplicationAction.REQUEST: {
        draft.isQueryData = true;
        draft.applications = [];
        draft.cancelleds = [];
        draft.processings = [];
        draft.filterCancelByDate = [];
        break;
      }
      case getListApplicationAction.SUCCESS: {
        draft.isQueryData = false;
        draft.cancelleds = action?.payload?.cancelleds;
        draft.processings = action?.payload?.processings;
        draft.filterCancelByDate = action?.payload?.cancelByDate;
        break;
      }
      case getListApplicationAction.FAILURE: {
        draft.isQueryData = false;
        break;
      }

      case filterTabCancelByDateAction.REQUEST: {
        draft.isLoading = true;
        break;
      }
      case filterTabCancelByDateAction.SUCCESS: {
        draft.isLoading = false;
        draft.filterCancelByDate = action?.payload?.items ?? draft.filterCancelByDate;
        draft.paramsQueryTabCancel = action?.payload?.params ?? draft.paramsQueryTabCancel;
        break;
      }
      case filterTabCancelByDateAction.FAILURE: {
        draft.isLoading = false;
        break;
      }

      // action redux
      case RESET_DATA_ACTION: {
        return initialState;
      }
    }
  });

export default ListApplicationReducer;
