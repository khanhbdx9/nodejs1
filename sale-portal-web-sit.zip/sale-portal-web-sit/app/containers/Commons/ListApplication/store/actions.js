import { createRoutine } from 'redux-saga-routines';

import * as KEY_CONSTANT from './constants';

export function resetDataAction() {
  return {
    type: KEY_CONSTANT.RESET_DATA_ACTION,
  };
}

export const getListApplicationAction = createRoutine(KEY_CONSTANT.GET_LIST_APPLICATION_ACTION);

export const filterTabCancelByDateAction = createRoutine(KEY_CONSTANT.FILTER_TAB_CANCEL_BY_DATE_ACTION);