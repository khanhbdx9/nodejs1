import { setLoadingAction } from '@App/actions';
import { responseCode } from '@utils/constants';
import KEY from '@utils/injectKey'
import { MESSAGE_SYSTEM } from '@utils/message';
import { URL, apiRequest } from "@utils/services/api";
import getLd from 'lodash/get';
import isEqual from 'lodash/isEqual'
import { toast } from 'react-toastify';
import { all, call, put as dispatch, takeLatest, select, delay } from 'redux-saga/effects';

import { getListApplicationAction, filterTabCancelByDateAction } from './actions';
import { CANCELED } from './constants'
import { filterByStartEndDate } from '../helpers';

export function* listApplicationSaga() {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(getListApplicationAction.request());

    const payload = {
      url: URL.unsecure.getApplication,
    };

    const { data: res = {} } = yield call(apiRequest.get, payload);
    const { data = {}, meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        const { paramsQueryTabCancel } = yield select(state => state[KEY.LIST_APPLICATION]) || {};
        
        const items = Array.isArray(data?.data) ? data.data : [];

        const cancelleds = [];
        const processings = [];

        for (const item of items) {
          if (item?.step === CANCELED) {
            cancelleds.push(item);
          } else {
            processings.push(item);
          }
        }

        // Sort theo order tăng dần
        processings.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

        // Filter data tab canceled application
        const cancelByDate = filterByStartEndDate(
          cancelleds,
          paramsQueryTabCancel?.startDate,
          paramsQueryTabCancel?.endDate
        );

        yield dispatch(
          getListApplicationAction.success({
            cancelleds,
            cancelByDate,
            processings,
            token: getLd(data, 'token', null),
          })
        );
        break;
      }
      default: {
        if(meta?.message) toast.error(meta.message);
        yield dispatch(getListApplicationAction.failure(meta));
        break;
      }
    }
  } catch (error) {
    if(error?.meta?.message) toast.error(error.meta.message);
    yield dispatch(getListApplicationAction.failure());
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

function* filterTabCancelByDateSaga(action) {
  try {
    yield dispatch(filterTabCancelByDateAction.request());

    const { cancelleds = [], paramsQueryTabCancel } = yield select(state => state[KEY.LIST_APPLICATION]) || {};

    if(isEqual(paramsQueryTabCancel, action?.payload)) return

    const params = action?.payload ?? paramsQueryTabCancel;
    const items = filterByStartEndDate(cancelleds, params?.startDate, params?.endDate);
    
    yield delay(300);

    yield dispatch(filterTabCancelByDateAction.success({
      items,
      params,
    }));
  } catch {
    toast.error(MESSAGE_SYSTEM.errorApp);
  } finally {
    yield dispatch(filterTabCancelByDateAction.failure());
  }
}

export default function* watchAll() {
  yield all([
    takeLatest(getListApplicationAction.TRIGGER, listApplicationSaga),
    takeLatest(filterTabCancelByDateAction.TRIGGER, filterTabCancelByDateSaga),
  ]);
}
