import { IcUser } from "@assets/icons";
import { IMGLogoVPB } from "@assets/images";
import AppButton from "@components/AppButton";
import AppImage from "@components/AppImage";
import Title from "@components/Styled/Title";
import { Text } from '@components/Styled/Title'
import TextFieldCustom from "@components/TextFieldCustom";
import Box from "@mui/material/Box";

import Footer from "./components/Footer";
import useHook from "./hook";
import { LoginContainer } from "./styled";


function Login() {
  const { formik, errMessage } = useHook();

  return (
    <LoginContainer>
      <Box className="background">
        <AppImage src={IMGLogoVPB} height={32} width={138} />
      </Box>
      <Box className="formContainer">
        <Box className="titleContainer">
          <Box className="user">
            <AppImage src={IcUser} height={76} width={76} className="avatar" />
            <Text>Khách hàng</Text>
          </Box>
          <Title className="title">Quản lý hồ sơ tại VPBank</Title>
        </Box>
        <form className="form" onSubmit={formik.handleSubmit}>
          <TextFieldCustom
            name="phoneNumber"
            label="Số điện thoại"
            className="formInput"
            value={formik.values.phoneNumber}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            errorMessage={errMessage("phoneNumber")}
            onKeyDown={(e) => {
              if (e.target.value && e.key === "Enter") {
                document.querySelector("#nationalId").focus();
              }
            }}
          />
          <TextFieldCustom
            id="nationalId"
            name="nationalId"
            label="Số CCCD"
            className="formInput"
            value={formik.values.nationalId}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            errorMessage={errMessage("nationalId")}
            onKeyDown={(e) => {
              if (e.target.value && e.key === "Enter") {
                formik.handleSubmit();
              }
            }}
          />
          <AppButton type="submit" className="submitBtn">
            Tìm kiếm hồ sơ
          </AppButton>
        </form>
        <Footer />
      </Box>
    </LoginContainer>
  );
}

export default Login;
