import { MESSAGE_SYSTEM } from "@utils/message";

function validatePhone(phone) {
  // check 3
  const phoneAllow = [
    "032",
    "033",
    "034",
    "035",
    "036",
    "037",
    "038",
    "039",
    "052",
    "055",
    "056",
    "058",
    "059",
    "070",
    "076",
    "077",
    "078",
    "079",
    "081",
    "082",
    "083",
    "084",
    "085",
    "086",
    "088",
    "089",
  ];
  const headerThree = phone.slice(0, 3);
  const checkThree = phoneAllow.includes(headerThree);

  // check 2
  const headerTwo = phone.slice(0, 2);
  const checkTwo = ["09"].includes(headerTwo);
  return checkTwo || checkThree;
}

function validateSignIn({ formValues }) {
  const errors = {};
  const { phoneNumber, nationalId } = formValues;

  // Validate phoneNumber
  if (!phoneNumber) {
    errors.phoneNumber = MESSAGE_SYSTEM.phoneRequired;
  } else if (phoneNumber.length !== 10) {
    errors.phoneNumber = MESSAGE_SYSTEM.phoneError;
  } else if (
    !/^\+?\d{1,3}?[- .]?\(?(?:\d{2,3})\)?[- .]?\d\d\d[- .]?\d\d\d\d$/.test(
      phoneNumber
    )
  ) {
    errors.phoneNumber = MESSAGE_SYSTEM.phoneError;
  } else if (validatePhone && !validatePhone(phoneNumber)) {
    errors.phoneNumber = MESSAGE_SYSTEM.phoneError;
  }

  // Validate nationalId
  if (!nationalId) {
    errors.nationalId = MESSAGE_SYSTEM.cccdRequired;
  } else if (isNaN(Number(nationalId))) {
    errors.nationalId = MESSAGE_SYSTEM.cccdError;
  } else if (String(nationalId).length !== 12) {
    errors.nationalId = MESSAGE_SYSTEM.cccdError;
  }

  return errors;
}

export default validateSignIn;
