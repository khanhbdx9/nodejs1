import { IMGLoginBackgroundM } from "@assets/images";
import styled from "styled-components";

export const LoginContainer = styled.div`
  height: 100vh;
  display: flex;
  @media ${(p) => p.theme.breakpoints.tablet} {
    flex-direction: column;
  }

  .background {
    flex: 1;
    height: 260px;
    padding: 24px;
    @media ${(p) => p.theme.breakpoints.tablet} {
      flex: unset;
      background-image: url(${IMGLoginBackgroundM});
      background-position: center;
      background-size: 100%;
    }
  }

  .formContainer {
    overflow: auto;
    position: relative;
    width: 490px;
    padding: 73px 32px 0;
    background-color: white;
    @media ${(p) => p.theme.breakpoints.tablet} {
      width: 100%;
      padding: 24px 16px 0;
      background: linear-gradient(
        180deg,
        rgba(255, 255, 255, 0) 0%,
        #ffffff 12.65%
      );
      margin-top: -70px;
    }

    .titleContainer {
      display: flex; 
      flex-direction: column;
      gap: 8px;
      margin-top: 24px;
      @media ${(p) => p.theme.breakpoints.tablet} {
        margin-top: 0px;
      }

      .user {
        display: flex;
        flex-direction: column;
        gap: 8px;

        .avatar {
          height: 60px;
          width: 60px;
        }

        span {
          font-weight: 500;
          font-size: 16px;
          line-height: 140%;
          letter-spacing: 0px;
          vertical-align: middle;
          color: ${(p) => p.theme.colors.neutral};
        }
      }

      .title {
        font-weight: 600;
        font-size: 24px;
        line-height: 140%;
        letter-spacing: 0px;
        vertical-align: middle;
        color: ${(p) => p.theme.colors.darkBlue};
      }
    }

    .form {
      display: flex;
      flex-direction: column;
      gap: 24px;
      margin-top: 27px;

      .formInput {
        width: 100%;
      }
    }

    .footer {
      margin: 88px 0px 34px 0px;
      text-align: center;

      .security {
        font-weight: 500;
        font-size: 14px;
        line-height: 140%;
        letter-spacing: 0px;
        text-align: center;
        vertical-align: middle;
        color: ${(p) => p.theme.colors.neutral};
      }

      .link {
        margin-top: 14px;
        display: flex;
        justify-content: center;
        gap: 8px;
        a,
        span {
          font-weight: 500;
          font-size: 14px;
          line-height: 140%;
          letter-spacing: 0px;
          text-align: center;
          vertical-align: middle;
          text-decoration: underline;
          text-decoration-style: solid;
          text-decoration-thickness: 0%;
          text-decoration-skip-ink: auto;
          color: ${(p) => p.theme.colors.lightGreen};
        }
      }
    }
  }
`;
