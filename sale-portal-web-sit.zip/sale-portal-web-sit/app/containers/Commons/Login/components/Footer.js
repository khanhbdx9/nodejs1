import React from "react";
import Title from "@components/Styled/Title";
import Box from "@mui/material/Box";
import Link from "@mui/material/Link";

function FooterLogin() {
  return (
    <Box className="footer">
      <Title className="security">
        © 2020 VPBank – Bản quyền đã được bảo hộ
      </Title>
      <Box className="link">
        <Link href="https://www.vpbank.com.vn/quy-dinh-bao-mat" target="_blank">
          Chính sách bảo mật
        </Link>
        <span className="text">|</span>
        <Link href="https://www.vpbank.com.vn/sitemap" target="_blank">
          Sitemap
        </Link>
      </Box>
    </Box>
  );
}

export default FooterLogin;
