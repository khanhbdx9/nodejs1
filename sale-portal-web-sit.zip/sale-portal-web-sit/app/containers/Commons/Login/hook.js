import { setUserInfoAction } from "@App/actions";
import { TOKEN_COOKIE, TOKEN_KEY } from "@utils/constants";
import { rmCookie } from "@utils/cookie";
import { useDispatchRedux } from "@utils/hooks/useRedux";
import SessionStorageService from "@utils/storage/session";
import { useFormik } from "formik";
import get from "lodash/get";
import { useEffect } from "react";

import { requestLoginAction } from "./store/actions";
import validateSignIn from "./validation";

function useHook() {
  // clear
  rmCookie(TOKEN_KEY);
  localStorage.clear();
  rmCookie(TOKEN_COOKIE);
  SessionStorageService.clear();

  const rqLoginAction = useDispatchRedux(requestLoginAction);
  const setUserInfoApp = useDispatchRedux(setUserInfoAction);

  useEffect(() => {

    // chỉ reset data user info tại đây để nếu sau có lỗi otp thì sẽ check nhanh được là ngta vào thẳng otp hay là đi đúng flow
    setUserInfoApp({});
  }, []);

  const formik = useFormik({
    initialValues: {
      phoneNumber: "",
      nationalId: "",
    },
    validate: (formValues) => validateSignIn({ formValues }),
    onSubmit: ({ phoneNumber, nationalId }) =>
      rqLoginAction({
        phoneNumber: phoneNumber.trim(),
        nationalId: nationalId.trim(),
      }),
  });

  const errMessage = (name) =>
    get(formik, `touched[${name}]`)
      ? get(formik, `errors[${name}]`)
      : undefined;

  return {
    formik,
    errMessage,
  };
}

export default useHook;
