import { createRoutine } from "redux-saga-routines";
import { REQUEST_LOGIN_ACTION } from "./constants";

export const requestLoginAction = createRoutine(REQUEST_LOGIN_ACTION);
