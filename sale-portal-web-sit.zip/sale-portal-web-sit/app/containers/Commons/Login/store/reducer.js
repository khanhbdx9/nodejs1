import { produce } from "immer";
import { requestLoginAction } from "./actions";
import get from "lodash/get";

export const initialState = {
  isLoading: false,
  msgError: "",
};

/* eslint-disable default-case, no-param-reassign */
const OtpReducer = (state = initialState, action) =>
  produce(state, (draft) => {
    switch (action.type) {
      case requestLoginAction.REQUEST: {
        draft.isLoading = true;
        draft.msgError = "";
        break;
      }
      case requestLoginAction.SUCCESS: {
        draft.isLoading = false;
        break;
      }
      case requestLoginAction.FAILURE: {
        draft.isLoading = false;
        draft.msgError = get(action, "payload.message");
        break;
      }
    }
  });

export default OtpReducer;
