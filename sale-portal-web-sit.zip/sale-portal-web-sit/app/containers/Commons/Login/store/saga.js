import get from "lodash/get";
import { toast } from "react-toastify";
import { all, call, put, takeLatest } from "redux-saga/effects";
import history from "@utils/history";
import { MESSAGE_SYSTEM } from "@utils/message";
import { URL, apiRequest } from "@utils/services/api";
import SessionStorageService from "@utils/storage/session";
import { TOKEN_KEY, OTP_REQUEST } from "@utils/constants";
import { setLoadingAction } from "@App/actions";
import { requestLoginAction } from "./actions";
import ROUTE from "@routers/constants";
import { responseCode } from "@utils/constants";

function* requestLoginSaga({ payload }) {
  try {
    const request = {
      url: URL.unsecure.requestLogin,
      data: payload,
    };

    yield put(setLoadingAction(true));
    yield put(requestLoginAction.request());

    const respond = yield call(apiRequest.post, request);
    const { data, meta } = get(respond, "data") || {};
    if (get(meta, "code") === responseCode["IL-200"] && data) {
      if (get(data, "signature") && data?.status != '400') {
        // Set signature
        SessionStorageService.setItem(TOKEN_KEY, data.signature);
        SessionStorageService.setItem(OTP_REQUEST, payload);

        history.push(ROUTE.common.Otp);
        toast.success(get(data, "message"));
        return;
      } 
      
      throw {
        meta: {
          message: data.message,
        },
      };
    } else {
      throw {};
    }
  } catch (error) {
    toast.error(get(error, "meta.message", MESSAGE_SYSTEM.default));
  } finally {
    yield put(setLoadingAction(false));
  }
}

export default function* watchAll() {
  yield all([takeLatest(requestLoginAction.TRIGGER, requestLoginSaga)]);
}
