
import { IcCancelBgRed } from '@assets/icons';
import AppButton from '@components/AppButton';
import LoadingSpinner from '@components/LoadingSpinner';
import Title from "@components/Styled/Title";
import React from 'react';

import { ResultCaptureOCRConatiner, ErrorRetry } from './Styled';

const ResultCaptureOCR = ({
  loading,
  isRetry,
  message,
  imageBlobFront,
  handleOpenCameraTS,
}) => {
  return (
    <ResultCaptureOCRConatiner>
      <div className="titleOCR">
        <Title $size={24} $weight={600} className="title"> 
          Xác thực giấy tờ tùy thân
        </Title>
        <p className="subTitle">Vui lòng chụp mặt trước CMND/CCCD</p>
      </div>

      <div className="contentCapture">
        <div className="boxCapture">
          <img src={imageBlobFront} alt="CCCD_Front" />
          <p>Chụp mặt trước</p>
        </div>

        <ErrorRetry showErrorRetry={isRetry}>
          <img src={IcCancelBgRed} alt="ic cancel" />
          <span> {message} </span>
        </ErrorRetry>
      </div>

      <React.Fragment>
        <LoadingSpinner loading={loading} />
        
        {!loading && (
          <AppButton
            className="btnContinue"
            label={isRetry ? 'Thử lại' : 'Tiếp tục'}
            onClick={handleOpenCameraTS}
          />
        )}
      </React.Fragment>
    </ResultCaptureOCRConatiner>
  );
}


export default ResultCaptureOCR;