

import { settingEkycAction } from '@App/actions';
import { IMGCccdFront } from '@assets/images';
import { SDK_TS, typeImgOCR } from '@utils/constants';
import useShallowEqualSelector from '@utils/hooks/useShallowEqualSelector'
import KEYS from "@utils/injectKey";
import { handleErrorSdkTS } from '@utils/redirect';
import get from 'lodash/get';
import { useRef, useState, useCallback, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { verifyOcrFrontAction } from './store/actions';
import { SDK_ID_FRONT } from './store/constants';

export default function useLogicOCRFront() {
  const dispatch = useDispatch();

  const { settingEkyc } = useShallowEqualSelector(KEYS.GLOBAL, ['settingEkyc']);
  const { isRetry, loading, message, countRetrySystem } = useSelector(state => state[KEYS.OCR_FRONT] || {});

  const refTVWebSDKFront = useRef(null);
  const [imageBlobFront, setImageBlobFront] = useState(IMGCccdFront);

  useEffect(() => {
    dispatch(settingEkycAction());
    // dispatch(getInfoCustomerDetail());
  }, []);

  const genSdk = () => {
    if (refTVWebSDKFront.current === null) {
      refTVWebSDKFront.current = new TVWebSDK.SDK({
        container: document.getElementById(SDK_ID_FRONT),
        lang: 'vi',
        enableAntiDebug: false,
        resourceRoot: SDK_TS.myCdnUrlPrefix,
        assetRoot: `${SDK_TS.myCdnUrlPrefix}tvweb-sdk/${
          SDK_TS.sdkVersion
        }/assets`,
      });
    }
  };

  const handleCloseSdk = () => {
    if (refTVWebSDKFront.current) {
      setTimeout(() => {
        refTVWebSDKFront.current.destroyView();
      }, 500);
    }
  };

  const handleDoneCaptureFront = useCallback(result => {
    const fileName = `image-front.jpg`;
    const resultFront = get(result, 'image.blob');
    const forntFile = new File([resultFront], fileName, typeImgOCR);
    const objectURL = window.URL.createObjectURL(forntFile);
    setImageBlobFront(objectURL);

    const formData = new FormData();
    formData.append('image', forntFile);

    if (
      get(result, 'qrScannedResult') &&
      get(result, 'qrScannedResult.image') &&
      get(result, 'qrScannedResult.image.blob')
    ) {
      const fileNameQR = `Ocr_ID_QR.jpg`;
      const resultQRCode = get(result, 'qrScannedResult');
      const imageBlobQR = get(resultQRCode, 'image.blob');
      const qrFile = new File([imageBlobQR], fileNameQR, typeImgOCR);

      formData.append('qr', qrFile);
      formData.append('metadata', get(resultQRCode, 'result'));
    }

    handleCloseSdk();
    dispatch(verifyOcrFrontAction(formData));
  }, []);

  const handleStartCaptureFront = useCallback(
    clientSettings => {
      refTVWebSDKFront.current.readIDCardUIOnly({
        steps: [
          {
            cardSide: 'front',
            cardType: 'vn.national_id',
            description: 'Vui lòng đặt CMND mặt trước vào trong khung',
            enableConfirmPopup: true,
            frontCamera: false,
            scannerType: 'id_card',
            title: 'Mặt trước CMND/CCCD',
            titleIcon: 'id_card_front.svg',
          },
        ],
        clientSettings,
        apiCheck: true,
        // detectIdCard: e => { },
        onStepDone: handleDoneCaptureFront,
        onError: handleErrorSdkTS,
      });
    },
    [handleDoneCaptureFront],
  );

  const handleOpenCameraTS = () => {
    if(countRetrySystem > 3){ // Lỗi hệ thống quá 3 lần sẽ không thực hiện tiếp
      
      return
    }

    setTimeout(() => {
      handleStartCaptureFront(settingEkyc || {});
    }, 200);
  };

  // Start Camera when get full data.
  // Only process 1 first time.
  useEffect(() => {
    if (get(settingEkyc, 'data') && refTVWebSDKFront.current !== null) {
      handleOpenCameraTS();
    }
  }, [settingEkyc, refTVWebSDKFront.current]);

  return {
    isRetry,
    loading,
    message,
    imageBlobFront,

    genSdk,
    handleOpenCameraTS,
  };
}
