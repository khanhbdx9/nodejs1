import React from 'react';

import { SDK_ID_FRONT } from './store/constants';

import ResultCaptureOCR from './components/ResultCaptureOCR';

import useLogicOCRFront from './hooks';

const Main = () => {
  const {
    isRetry,
    loading,
    message,
    imageBlobFront,
    genSdk,
    handleOpenCameraTS,
  } = useLogicOCRFront();

  React.useLayoutEffect(() => {
    genSdk();
  });

  return (
    <React.Fragment>
      <div id={SDK_ID_FRONT} />

      <ResultCaptureOCR
        loading={loading}
        isRetry={isRetry}
        message={message}
        imageBlobFront={imageBlobFront}
        handleOpenCameraTS={handleOpenCameraTS}
      />
    </React.Fragment>
  );
};

export default Main;
