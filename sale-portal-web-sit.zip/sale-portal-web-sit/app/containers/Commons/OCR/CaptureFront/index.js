import LoadingIndicator from '@components/LoadingIndicator';
import KEYS from "@utils/injectKey";
import { useInjectReducer } from '@utils/injectReducer';
import { useInjectSaga } from '@utils/injectSaga';
import loadable from '@utils/loadable';

import reducer from './store/reducer';
import saga from './store/saga';

const Provider = ({ children }) => {
  useInjectReducer({ key: KEYS.OCR_FRONT, reducer });
  useInjectSaga({ key: KEYS.OCR_FRONT, saga });

  return <>{children}</>;
};

const OCRCaptureFront = loadable(() => import('./Main'), {
  fallback: <LoadingIndicator />,
  provider: Provider,
});

export default OCRCaptureFront;
