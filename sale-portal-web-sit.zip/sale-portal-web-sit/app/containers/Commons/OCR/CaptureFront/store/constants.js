import KEYS from "@utils/injectKey";

export const SDK_ID_FRONT = 'web-sdk-capture-front';

export const VERIFY_OCR_FRONT_ACTION = `app/${KEYS.OCR_FRONT}/VERIFY_OCR_FRONT_ACTION`;
