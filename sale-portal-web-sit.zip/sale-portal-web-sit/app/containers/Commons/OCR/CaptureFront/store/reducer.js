import { produce } from 'immer';
import get from 'lodash/get';
import isNumber from 'lodash/isNumber';

import { verifyOcrFrontAction } from './actions';

export const initialState = {
  loading: false,
  isRetry: false,

  message: '',

  // bộ đếm dưới FE quá 3 lần sẽ không thể thực hiện tiếp
  countRetrySystem: 0,
};

const OcrFrontReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case verifyOcrFrontAction.REQUEST: {
        draft.loading = true;
        break;
      }
      case verifyOcrFrontAction.SUCCESS: {
        draft.loading = false;
        draft.isRetry = false;
        
        draft.message = '';

        draft.countRetrySystem = 0;
        break;
      }
      case verifyOcrFrontAction.FAILURE: {
        if(isNumber(get(action, 'payload.count'))){
          draft.countRetrySystem = action.payload.count;
        }

        draft.loading = false;
        draft.isRetry = true;

        draft.message = get(action, 'payload.message');
        break;
      }
    }
  });
export default OcrFrontReducer;
