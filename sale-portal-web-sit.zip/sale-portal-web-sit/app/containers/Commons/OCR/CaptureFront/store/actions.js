import { createRoutine } from 'redux-saga-routines';

import { VERIFY_OCR_FRONT_ACTION } from './constants';

export const verifyOcrFrontAction = createRoutine(VERIFY_OCR_FRONT_ACTION);
