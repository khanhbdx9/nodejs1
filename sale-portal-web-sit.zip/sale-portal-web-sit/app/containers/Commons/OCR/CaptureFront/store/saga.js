import ROUTE from '@routers/constants'
import history from '@utils/history';
import { MESSAGE_SYSTEM } from '@utils/message';
import { URL, apiRequest } from "@utils/services/api";
import get from 'lodash/get';
import { toast } from 'react-toastify';
import { select, all, call, put, takeLatest } from 'redux-saga/effects';
import KEYS from "@utils/injectKey";

import { verifyOcrFrontAction } from './actions';

export function* verifyOcrFrontSaga(action) {
  try {
    yield put(verifyOcrFrontAction.request());

    const payload = {
      url: URL.unsecure.kycOcrFront,
      data: get(action, 'payload'),
    };

    const respond = yield call(apiRequest.post, payload);
    const { data, meta } = get(respond, 'data') || {};

    if (get(meta, 'code') === 'IL-200' && data) {
      const message = get( data, 'message', 'Ảnh của bạn không đủ chất lượng. Vui lòng bấm “Chụp lại” để thử lại.') ;

      switch (data.action) {
        case "OCR_BACK": {
          yield put(verifyOcrFrontAction.success());
          history.push(`${ROUTE.common.OCRCaptureBack}`);
          break;
        }
        case 'RETRY': {
          yield put(verifyOcrFrontAction.failure({ 
            message 
          }));
          break;
        }
        case 'RETRY_SYSTEM': {
          const count = yield select(state => get(state[KEYS.OCR_FRONT], 'countRetrySystem')) || 0;

          yield put(verifyOcrFrontAction.failure({ 
            message,
            count: count + 1
          }));
          break;
        }
        default: {
          yield put(verifyOcrFrontAction.failure({ 
            message 
          }));
          toast.error(get(data, 'message', MESSAGE_SYSTEM.error_01));
          break;
        }
      }
      return;
    }

    yield put(verifyOcrFrontAction.failure({ message: JSON.stringify(respond) }));
    toast.error(get(meta, 'message', MESSAGE_SYSTEM.error_02));
  } catch (error) {
    toast.error(get(error, 'meta.message', MESSAGE_SYSTEM.default));
    yield put(
      verifyOcrFrontAction.failure({
        message: get(error, 'meta.message', MESSAGE_SYSTEM.default),
      }),
    );
  }
}

export default function* watchAll() {
  yield all([takeLatest(verifyOcrFrontAction.TRIGGER, verifyOcrFrontSaga)]);
}
