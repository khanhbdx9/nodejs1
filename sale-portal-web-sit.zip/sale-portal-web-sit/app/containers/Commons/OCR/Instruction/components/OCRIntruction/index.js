import { IMGInstruction1, IMGInstruction2, IMGInstruction3, IMGInstruction4 } from '@assets/images';
import { IcWarningGreen } from '@assets/icons';
import Title from "@components/Styled/Title";

import AppButton from '@components/AppButton';
import AppTooltip from '@components/AppTooltip';

import OCRGuidelineContainer from './Styled';

const OCRIntruction = ({ isDisabled, handleCaptureOCR }) => (
  <OCRGuidelineContainer>
    <div className="containerOCR">
      <Title $size={24} $weight={600} className="title"> 
        Chụp hai mặt Căn cước công dân
        
        <AppTooltip
          style={{ height: 12 }}
          icon={IcWarningGreen}
          content={`
            Trường hợp Quý khách lựa chọn mở tài khoản thanh toán, đăng ký Khoản vay/thẻ tín dụng..., bằng phương thức điện tử, Quý khách lưu ý:<br/>
            Không sử dụng CMND/CCCD giả mạo, không chính chủ. Khách hàng chịu hoàn toàn trách nhiệm trước pháp luật về hình ảnh CMND/CCCD và các thông tin đã cung cấp. <br/>
            Không được cho thuê, cho mượn tài khoản thanh toán, hoặc sử dụng tài khoản thanh toán của mình để thực hiện các giao dịch bất hợp pháp.<br/>
            Không được sử dụng tài khoản thanh toán để thực hiện các giao dịch nhằm mục đích rửa tiền, tài trợ khủng bố, lừa đảo, gian lận hoặc các hành vi vi phạm pháp luật khác.
          `}
        />
      </Title>

      <div className="content">
        <div className="groupItem">
          <img src={IMGInstruction1} alt="INSTRUCTION1" className="imgCCCD" />
          <span className="textNote">
            Chụp lần lượt mặt trước và mặt sau của CCCD bản gốc, còn hạn sử
            dụng.
          </span>
        </div>
        <div className="groupItem">
          <img src={IMGInstruction2} alt="INSTRUCTION2" className="imgCCCD" />
          <span className="textNote">
            Ảnh chụp CCCD không bị mất góc, bấm lỗ.
          </span>
        </div>
        <div className="groupItem">
          <img src={IMGInstruction3} alt="INSTRUCTION3" className="imgCCCD" />
          <span className="textNote">
            Chú ý ánh sáng, điều kiện chụp. Ảnh chụp cần rõ nét, không bị mờ, bị
            tối hay chói sáng.
          </span>
        </div>
      </div>

      <div className="content warning">
        <div className="groupItem">
          <img src={IMGInstruction4} alt="INSTRUCTION4" className="imgCCCD" />
          <span className="textNote">
            Không chụp lại ảnh CCCD từ màn hình máy tính, điện thoại...
          </span>
        </div>
      </div>

      <AppButton
        label="Tiếp tục"
        className="btnContinue"
        disabled={isDisabled}
        onClick={handleCaptureOCR}
      />
    </div>
  </OCRGuidelineContainer>
);

export default OCRIntruction;
