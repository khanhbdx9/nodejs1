import styled from 'styled-components';

const OCRGuidelineContainer = styled.div`
  width: 100%;
  max-width: 580px;
  margin: auto;
  margin-top: 20px;
  @media (max-width: 680px) {
    max-width: 360px;
    padding: 0 16px;
  }

  img {
    max-width: initial;
  }

  .title {
    display: flex;
    align-items: center;
    justify-content: center;
    @media (max-width: 680px) {
      align-items: unset;
      justify-content: unset;
    }
  }

  .containerOCR {
    margin-bottom: 27.75px;
    @media (max-width: 680px) {
      margin-top: 30px;
      margin-bottom: 20px;
    }

    .content {
      margin-top: 40px;
      border-radius: 4px;
      background: var(--ultra-white, #fff);
      padding: 4px 16px;
      box-shadow: 0px 4px 16px 0px #0000000f;
      @media (max-width: 680px) {
        margin-top: 20px;
      }
      &.warning {
        background: #ffd8d180;
        box-shadow: none;
        margin-top: 20px;
        margin-bottom: 40px;
      }

      .groupItem {
        gap: 16px;
        display: flex;
        padding: 16px 0;
        align-items: center;
        border-bottom: 1px solid #e9eaec;
        &:last-child {
          border-bottom: unset;
        }
        &:nth-child(2) {
          .imgCCCD {
            height: auto;
          }
        }

        .imgCCCD {
          min-width: 68px;
          height: 44px;
        }
        .textNote {
          color: var(--navy-600, #092f51);
          font-size: 16px;
          font-weight: 500;
          line-height: 22px;
          @media (max-width: 680px) {
            font-size: 14px;
            line-height: 21px;
          }
        }
      }
    }
      
    .btnContinue {
      width: 380px;
      display: flex;
      margin: auto;
      @media (max-width: 680px) {
      }
    }
  }
`;

export default OCRGuidelineContainer;
