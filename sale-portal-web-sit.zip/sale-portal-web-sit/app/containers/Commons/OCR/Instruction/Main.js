import OCRIntruction from './components/OCRIntruction';

import useLogicOCRIntruction from './hooks';

const OCRInstruction = () => {
  const { isDisabled, handleCaptureOCR } = useLogicOCRIntruction();

  return (
    <OCRIntruction
      isDisabled={isDisabled}
      handleCaptureOCR={handleCaptureOCR}
    />
  );
};

export default OCRInstruction;
