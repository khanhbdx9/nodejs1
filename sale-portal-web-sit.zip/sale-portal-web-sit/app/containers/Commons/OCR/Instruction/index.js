import loadable from '@utils/loadable';

import LoadingIndicator from '@components/LoadingIndicator';

const Provider = ({ children }) => <>{children}</>;

const OCRInstruction = loadable(() => import('./Main'), {
  fallback: <LoadingIndicator />,
  provider: Provider,
});

export default OCRInstruction;
