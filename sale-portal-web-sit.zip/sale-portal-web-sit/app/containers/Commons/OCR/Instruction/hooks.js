// import get from 'lodash/get';
// import { useDispatch, useSelector } from 'react-redux';

import history from '@utils/history';
import ROUTE from '@routers/constants'

export default function useLogicOCRIntruction() {
  // const { appDetail } = useSelector(state => state.global);

  // const dispatch = useDispatch();

  const handleCaptureOCR = () => {
    history.push(ROUTE.common.OCRCaptureFront);

    // switch (get(appDetail, "step_type")) {
    //   case screenType.OCR_BACK: {
    //     history.push(ROUTE.common.OCRCaptureBack);
    //     break;
    //   }
    //   case screenType.OCR_FRONT: {
    //     history.push(ROUTE.common.OCRCaptureFront);
    //     break;
    //   }
    //   case screenType.CAPTURE_QR: {
    //     history.push(ROUTE.common.OCRCaptureQR);
    //     break;
    //   }
    //   default: {
    //     dispatch(getInfoCustomerDetail());
    //     toast.error(MESSAGE_SYSTEM.RETRY);
    //     break;
    //   }
    // }
  };

  // useEffect(() => {
  //   // checkDeviceSupportCameraTS();
  //   setTimeout(() => dispatch(getInfoCustomerDetail()), 100);
  // }, []);

  return {
    isDisabled: false,

    handleCaptureOCR,
  };
}
