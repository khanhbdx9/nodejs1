import { createRoutine } from 'redux-saga-routines';

import { VERIFY_OCR_QR_ACTION } from './constants';

export const verifyOcrQrAction = createRoutine(VERIFY_OCR_QR_ACTION);
