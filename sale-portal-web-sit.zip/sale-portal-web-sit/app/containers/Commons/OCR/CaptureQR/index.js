import loadable from '@utils/loadable';
import KEYS from "@utils/injectKey";

import { useInjectReducer } from '@utils/injectReducer';
import { useInjectSaga } from '@utils/injectSaga';

import LoadingIndicator from '@components/LoadingIndicator';

import saga from './store/saga';
import reducer from './store/reducer';

const Provider = ({ children }) => {
  useInjectReducer({ key: KEYS.OCR_QR, reducer });
  useInjectSaga({ key: KEYS.OCR_QR, saga });

  return <>{children}</>;
};

const OCRCaptureQR = loadable(() => import('./Main'), {
  fallback: <LoadingIndicator />,
  provider: Provider,
});

export default OCRCaptureQR;
