import get from "lodash/get";
import { useRef, useState, useCallback, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import useShallowEqualSelector from '@utils/hooks/useShallowEqualSelector'

import { IMGCccdBack } from '@assets/images';

import { settingEkycAction } from '@App/actions';
import { SDK_TS, typeImgOCR } from "@utils/constants";
import { handleErrorSdkTS } from "@utils/redirect";
import KEYS from "@utils/injectKey";

import { SDK_ID_QR } from "./store/constants";
import { verifyOcrQrAction } from "./store/actions";

export default function useLogicOCRQR() {
  const dispatch = useDispatch();
  const { settingEkyc } = useShallowEqualSelector(KEYS.GLOBAL, ['settingEkyc']);

  const { isRetry, loading, message, countRetrySystem } = useSelector(state => state[KEYS.OCR_QR] || {});

  const refTVWebSDKInit = useRef(null);
  const [imageBlobQR, setImageBlobQR] = useState(IMGCccdBack);

  // INIT DATA
  useEffect(() => {
    dispatch(settingEkycAction());
  }, []);
  // END INIT DATA

  const genSdk = () => {
    if (refTVWebSDKInit.current === null) {
      refTVWebSDKInit.current = new TVWebSDK.SDK({
        container: document.getElementById(SDK_ID_QR),
        lang: "vi",
        enableAntiDebug: false,
        resourceRoot: SDK_TS.myCdnUrlPrefix,
        assetRoot: `${SDK_TS.myCdnUrlPrefix}tvweb-sdk/${SDK_TS.sdkVersion}/assets`,
      });
    }
  };

  const handleCloseSdk = () => {
    if (refTVWebSDKInit.current) {
      setTimeout(() => {
        refTVWebSDKInit.current.destroyView();
      }, 500);
    }
  };

  const handleDoneCaptureQR = useCallback((result) => {
    console.log("result: ", result);
    const formData = new FormData();

    if (
      get(result, 'qrScannedResult') &&
      get(result, 'qrScannedResult.image') &&
      get(result, 'qrScannedResult.image.blob')
    ) {
      const fileName = `Ocr_ID_QR.jpg`;
      const resultQR = get(result, 'qrScannedResult');
      const imageBlob = get(resultQR, 'image.blob');
      const qrFile = new File([imageBlob], fileName, typeImgOCR);
      const objectURL = window.URL.createObjectURL(qrFile);
      setImageBlobQR(objectURL);

      formData.append('qr', qrFile);
      formData.append('metadata', get(resultQR, 'result'));
    }

    // A Sáng confirm là ko có ảnh thì truyền body rỗng
    handleCloseSdk();
    dispatch(verifyOcrQrAction(formData));
  }, []);

  const handleStartCaptureQR = useCallback(
    (clientSettings) => {
      refTVWebSDKInit.current.readIDCardUIOnly({
        steps: [
          {
            title: "Quét mã QR trên CCCD",
            titleIcon: "",
            enableConfirmPopup: false,
            scannerType: get(TVWebSDK, "ScannerType.QR_CODE", "qr_code"),
          },
        ],
        clientSettings,
        apiCheck: true,
        onStepDone: handleDoneCaptureQR,
        onError: handleErrorSdkTS,
      });
    },
    [handleDoneCaptureQR]
  );

  const handleOpenCameraTS = () => {
    if(countRetrySystem > 3){ // Lỗi hệ thống quá 3 lần sẽ không thực hiện tiếp
      
      return
    }
    
    setTimeout(() => {
      handleStartCaptureQR(settingEkyc || {});
    }, 200);
  };

  // Start Camera when get full data.
  // Only process 1 first time.
  useEffect(() => {
    if (get(settingEkyc, "data") && refTVWebSDKInit.current !== null) {
      handleOpenCameraTS();
    }
  }, [settingEkyc, refTVWebSDKInit.current]);

  return {
    isRetry,
    loading,
    message,
    imageBlobQR,

    genSdk,
    handleOpenCameraTS,
  };
}
