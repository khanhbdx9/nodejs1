import React from 'react';

import ResultCaptureOCR from './components/ResultCaptureOCR';

import { SDK_ID_QR } from './store/constants';

import useLogicOCRQR from './hooks';

const Main = () => {
  const {
    isRetry,
    loading,
    message,
    imageBlobQR,
    genSdk,
    handleOpenCameraTS,
  } = useLogicOCRQR();

  React.useLayoutEffect(() => {
    genSdk();
  });

  return (
    <React.Fragment>
      <div id={SDK_ID_QR} />

      <ResultCaptureOCR
        loading={loading}
        isRetry={isRetry}
        message={message}
        imageBlob={imageBlobQR}
        handleOpenCameraTS={handleOpenCameraTS}
      />
    </React.Fragment>
  );
};

export default Main;
