import { createRoutine } from 'redux-saga-routines';

import { VERIFY_OCR_BACK_ACTION } from './constants';

export const verifyOcrBackAction = createRoutine(VERIFY_OCR_BACK_ACTION);
