import KEYS from "@utils/injectKey";

export const SDK_ID_BACK = 'web-sdk-capture-back';

export const VERIFY_OCR_BACK_ACTION = `app/${KEYS.OCR_BACK}/VERIFY_OCR_BACK_ACTION`;
