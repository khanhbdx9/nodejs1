import get from 'lodash/get';
import { useRef, useState, useCallback, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import useShallowEqualSelector from '@utils/hooks/useShallowEqualSelector'

import { IMGCccdBack } from '@assets/images';

import { isMobile } from '@utils/helpers';
import { handleErrorSdkTS } from '@utils/redirect';
import { SDK_TS, typeImgOCR } from '@utils/constants';
import { settingEkycAction } from '@App/actions';
import KEYS from "@utils/injectKey";

import { SDK_ID_BACK } from './store/constants';
import { verifyOcrBackAction } from './store/actions';

export default function useLogicOCRBack() {
  const dispatch = useDispatch();

  const { settingEkyc } = useShallowEqualSelector(KEYS.GLOBAL, ['settingEkyc']);
  const { isRetry, loading, message, countRetrySystem } = useSelector(state => state[KEYS.OCR_BACK] || {});

  const refTVWebSDKBack = useRef(null);
  const [imageBlobBack, setImageBlobBack] = useState(IMGCccdBack);

  useEffect(() => {
    dispatch(settingEkycAction());
    // dispatch(getInfoCustomerDetail());
  }, []);

  const genSdk = () => {
    if (refTVWebSDKBack.current === null) {
      refTVWebSDKBack.current = new TVWebSDK.SDK({
        container: document.getElementById(SDK_ID_BACK),
        lang: 'vi',
        enableAntiDebug: false,
        resourceRoot: SDK_TS.myCdnUrlPrefix,
        assetRoot: `${SDK_TS.myCdnUrlPrefix}tvweb-sdk/${
          SDK_TS.sdkVersion
        }/assets`,
      });
    }
  };

  const handleCloseSdk = () => {
    if (refTVWebSDKBack.current) {
      setTimeout(() => {
        refTVWebSDKBack.current.destroyView();
      }, 500);
    }
  };

  const handleDoneCaptureBack = useCallback(result => {
    const resultBack = get(result, 'image.blob');
    const fileName = `image-back.jpg`;
    const backFile = new File([resultBack], fileName, typeImgOCR);
    const objectURL = window.URL.createObjectURL(backFile);
    setImageBlobBack(objectURL);

    const formData = new FormData();
    formData.append('image', backFile);
    formData.append('isMobile', isMobile());

    handleCloseSdk();
    dispatch(verifyOcrBackAction(formData));
  }, []);

  const handleStartCaptureBack = useCallback(
    clientSettings => {
      refTVWebSDKBack.current.readIDCardUIOnly({
        steps: [
          {
            cardSide: 'back',
            cardType: 'vn.national_id',
            description: 'Vui lòng đặt CMND mặt sau vào trong khung',
            enableConfirmPopup: true,
            frontCamera: false,
            scannerType: 'id_card',
            title: 'Mặt sau CMND/CCCD',
            titleIcon: 'id_card_back.svg',
          },
        ],
        clientSettings,
        apiCheck: true,
        // detectIdCard: e => { },
        onStepDone: handleDoneCaptureBack,
        onError: handleErrorSdkTS,
      });
    },
    [handleDoneCaptureBack],
  );

  const handleOpenCameraTS = () => {
    if(countRetrySystem > 3){ // Lỗi hệ thống quá 3 lần sẽ không thực hiện tiếp
      
      return
    }
    
    setTimeout(() => {
      handleStartCaptureBack(settingEkyc || {});
    }, 200);
  };

  // Start Camera when get full data.
  // Only process 1 first time.
  useEffect(() => {
    if (get(settingEkyc, 'data') && refTVWebSDKBack.current !== null) {
      handleOpenCameraTS();
    }
  }, [settingEkyc, refTVWebSDKBack.current]);

  return {
    isRetry,
    loading,
    message,
    imageBlobBack,

    genSdk,
    handleOpenCameraTS,
  };
}
