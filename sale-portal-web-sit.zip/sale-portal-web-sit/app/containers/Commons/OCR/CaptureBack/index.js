import loadable from '@utils/loadable';

import { useInjectReducer } from '@utils/injectReducer';
import { useInjectSaga } from '@utils/injectSaga';

import KEYS from "@utils/injectKey";
import LoadingIndicator from '@components/LoadingIndicator';

import saga from './store/saga';
import reducer from './store/reducer';

const Provider = ({ children }) => {
  useInjectReducer({ key: KEYS.OCR_BACK, reducer });
  useInjectSaga({ key: KEYS.OCR_BACK, saga });

  return <>{children}</>;
};

const OCRCaptureBack = loadable(() => import('./Main'), {
  fallback: <LoadingIndicator />,
  provider: Provider,
});

export default OCRCaptureBack;
