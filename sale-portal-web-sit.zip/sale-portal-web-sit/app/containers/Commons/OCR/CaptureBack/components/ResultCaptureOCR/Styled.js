import styled from 'styled-components';

const ErrorRetry = styled.div`
  gap: 8px;
  align-items: center;
  justify-content: center;
  display: ${props => (props.showErrorRetry ? 'flex' : 'none')};
}`;

const ResultCaptureOCRConatiner = styled.div`
  gap: 40px;
  margin: auto;
  display: grid;
  margin-top: 40px;
  margin-bottom: 40px;
  max-width: 580px;
  @media (max-width: 580px) {
    padding: 0 16px;
  }

  .titleOCR {
    gap: 20px;
    display: grid;
    text-align: center;

    .subTitle {
      margin: 0;
      color: #092f51;
      font-size: 14px;
      font-weight: 500;
      line-height: 22px;
      text-align: center;
    }
  }

  .boxCapture {
    gap: 16px;
    padding: 16px;
    width: 380px;
    margin: auto;
    display: grid;
    height: 272px;
    background: #fff;
    border-radius: 16px;
    justify-content: center;
    border: 1px solid #ffffff;
    @media (max-width: 580px) {
      width: 320px;
    }

    img {
      width: 352px;
      height: 204px;
      border-radius: 8px;
      object-fit: cover;
    }
    p {
      margin: 0;
      font-size: 16px;
      font-weight: 600;
      line-height: 17px;
      letter-spacing: 0em;
      text-align: center;
    }
  }

  .btnContinue {
    margin: auto;
    width: 380px;
    @media (max-width: 580px) {
      width: 100%;
    }
  }
`;

ErrorRetry.shouldForwardProp = (prop) => !["showErrorRetry"].includes(prop);

export {
  ErrorRetry,
  ResultCaptureOCRConatiner,
}
