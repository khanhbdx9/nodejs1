import React from 'react';

import ResultCaptureOCR from './components/ResultCaptureOCR';

import { SDK_ID_BACK } from './store/constants';

import useLogicOCRBack from './hooks';

const Main = () => {
  const {
    isRetry,
    loading,
    message,
    imageBlobBack,
    genSdk,
    handleOpenCameraTS,
  } = useLogicOCRBack();

  React.useLayoutEffect(() => {
    genSdk();
  });

  return (
    <React.Fragment>
      <div id={SDK_ID_BACK} />

      <ResultCaptureOCR
        loading={loading}
        isRetry={isRetry}
        message={message}
        imageBlobBack={imageBlobBack}
        handleOpenCameraTS={handleOpenCameraTS}
      />
    </React.Fragment>
  );
};

export default Main;
