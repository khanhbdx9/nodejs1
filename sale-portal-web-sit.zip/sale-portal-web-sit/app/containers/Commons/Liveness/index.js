import loadable from '@utils/loadable';

import { useInjectReducer } from '@utils/injectReducer';
import { useInjectSaga } from '@utils/injectSaga';

import LoadingIndicator from '@components/LoadingIndicator';

import saga from './store/saga';
import reducer from './store/reducer';
import KEYS from "@utils/injectKey";

const Provider = ({ children }) => {
  useInjectReducer({ key: KEYS.LIVENESS, reducer });
  useInjectSaga({ key: KEYS.LIVENESS, saga });

  return <>{children}</>;
};

const Liveness = loadable(() => import('./Main'), {
  fallback: <LoadingIndicator />,
  provider: Provider,
});

export default Liveness;
