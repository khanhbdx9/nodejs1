import styled from 'styled-components';

const LivenessContainer = styled.div`
  gap: 40px;
  margin: auto;
  display: grid;
  @media (max-width: 656px) {
    gap: 20px;
    margin: 0px;
    padding: 16px;
  }

  .title {
    text-align: center;
  }
`;

export default LivenessContainer;
