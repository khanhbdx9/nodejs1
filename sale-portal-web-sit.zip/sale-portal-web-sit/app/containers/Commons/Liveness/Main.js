import React from 'react';

import Title from "@components/Styled/Title";

import TakeShotLiveness from './components/TakeShot';
import GuidelineLiveness from './components/Guideline';

import useLogicLiveness from './hooks';
import LivenessContainer from './Styled';

const Main = () => {
  const {
    loading,
    isDisabled,
    isShowRetry,
    messageError,
    titleTakeShot,
    imageBlobLeft,
    imageBlobRight,
    imageBlobCenter,
    isShowLayoutTakeShot,
    isShowLayoutGuideline,
    genSdk,
    handleOpenCamera,
  } = useLogicLiveness();

  React.useLayoutEffect(() => {
    genSdk();
  }, []);

  return (
    <LivenessContainer>
      <div id="TakeShot" />

      <React.Fragment>
        <Title $size={24} $weight={600} className="title"> 
          Nhận diện khuôn mặt
        </Title>

        {isShowLayoutGuideline && (
          <GuidelineLiveness
            isDisabled={isDisabled}
            handleOpenCamera={handleOpenCamera}
          />
        )}

        {isShowLayoutTakeShot && (
          <TakeShotLiveness
            loading={loading}
            isDisabled={isDisabled}
            isShowRetry={isShowRetry}
            messageError={messageError}
            titleTakeShot={titleTakeShot}
            imageBlobLeft={imageBlobLeft}
            imageBlobRight={imageBlobRight}
            imageBlobCenter={imageBlobCenter}
            handleOpenCamera={handleOpenCamera}
          />
        )}
      </React.Fragment>
    </LivenessContainer>
  );
};

export default Main;
