import styled from 'styled-components';

export const ErrorRetry = styled.div`
  gap: 8px;
  align-items: center;
  justify-content: center;
  display: ${props => (props.showErrorRetry ? 'flex' : 'none')};
}`;

const TakeShotLivenessContainer = styled.div`
  display: grid;
  gap: 40px;
  margin: auto;
  max-width: 656px;
  margin-bottom: 40px;
  @media (max-width: 656px) {
    gap: 30px;
    width: 100%;
  }

  .titleTakeShot {
    margin: 0;
    margin: auto;
    color: #092f51;
    font-size: 16px;
    font-weight: 500;
    line-height: 22px;
    text-align: center;
    // max-width: 371px;
    @media (max-width: 656px) {
      text-align: left;
      font-size: 14px;
      line-height: 20px;
      margin: unset;
    }
  }
  .groupLiveness {
    gap: 40px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    @media (max-width: 656px) {
      gap: 8px;
    }

    .item {
      width: 192px;
      height: 285px;
      background: #fff;
      border-radius: 8px;
      border: 1px solid #dfdfdf;
      display: grid;
      padding: 16px;
      justify-content: center;
      align-items: center;
      @media (max-width: 656px) {
        width: 100%;
        height: 164px;
        padding: 8px;
      }

      img {
        width: 160px;
        height: 213px;
        object-fit: cover;
        @media (max-width: 656px) {
          width: auto;
          height: 118px;
          border-radius: 4px;
          min-width: 88px;
        }
      }
      p {
        margin: 0;
        font-size: 16px;
        font-weight: 600;
        line-height: 24px;
        text-align: center;
        color: #333333;
        @media (max-width: 656px) {
          font-size: 14px;
          line-height: 15px;
        }
      }
    }
  }
  .btnConfirm {
    margin: auto;
    @media (max-width: 656px) {
      width: 100%;
    }
    button {
      width: 380px;
      height: 48px;
      border-radius: 4px;
      @media (max-width: 656px) {
        width: 100%;
        max-width: 100%;
      }
    }
  }
`;

export default TakeShotLivenessContainer;
