import { IcCancelBgRed } from '@assets/icons';

import AppButton from '@components/AppButton';
import LoadingProcessing from '../LoadingProcessing';
// import LoadingSpinner from 'components/LoadingSpinner';

import TakeShotLivenessContainer, { ErrorRetry } from './Styled';

const TakeShotLiveness = ({
  loading,
  isDisabled,
  isShowRetry,
  messageError,
  titleTakeShot,
  imageBlobLeft,
  imageBlobRight,
  imageBlobCenter,
  handleOpenCamera,
}) => (
  <>
    <LoadingProcessing loading={loading} />

    <TakeShotLivenessContainer>
      <h5
        className="titleTakeShot"
        dangerouslySetInnerHTML={{ __html: titleTakeShot }}
      />

      <div className="groupLiveness">
        <div className="item">
          <img src={imageBlobCenter} alt="Chính diện" />
          <p>Chính diện</p>
        </div>
        <div className="item">
          <img src={imageBlobLeft} alt="Xoay trái" />
          <p>Xoay trái</p>
        </div>
        <div className="item">
          <img src={imageBlobRight} alt="Xoay phải" />
          <p>Xoay phải</p>
        </div>
      </div>

      {messageError && (
        <ErrorRetry showErrorRetry={messageError}>
          <img src={ICCancelBgRed} alt="ic cancel" />
          <span>{messageError}</span>
        </ErrorRetry>
      )}

      {/* <LoadingSpinner loading={loading} /> */}
      {/* {!loading && ( */}
      <AppButton
        className="btnContinue"
        label={isShowRetry ? 'Chụp lại' : 'Tiếp tục'}
        onClick={handleOpenCamera}
        disabled={isDisabled}
      />
      {/* )} */}
    </TakeShotLivenessContainer>
  </>
);

export default TakeShotLiveness;
