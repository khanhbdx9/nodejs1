import styled from 'styled-components';

const GuidelineLivenessContainer = styled.div`
  gap: 40px;
  margin: auto;
  max-width: 580px;
  margin-bottom: 72px;
  display: grid;
  @media (max-width: 580px) {
    margin-bottom: 0;
    max-width: 100%;
  }

  .boxGuideline {
    box-shadow: 0px 4px 16px 0px #0000000f;
    position: relative;
    @media (max-width: 580px) {
      margin-top: 14px;
    }
    .titleGuideline {
      z-index: 5;
      position: absolute;
      color: var(--navy-500, #104370);
      font-size: 14px;
      font-style: normal;
      font-weight: 600;
      line-height: 20px;
      border-radius: 4px;
      border-bottom: 1px solid #e9eaec;
      background: var(--white, #fff);
      padding: 4px 8px;
      left: 16px;
      top: -14px;
    }
  }
  .MuiList-root {
    // gap: 16px;
    padding: 16px;
    display: grid;
    background: #ffffff;
    border-radius: 4px;
    padding-bottom: 4px;
    @media (max-width: 580px) {
      padding-bottom: 22px;
    }

    .MuiListItem-root {
      gap: 16px;
      padding: 16px 0px;
      border-bottom: 1px solid #e9eaec;
      &:last-child {
        border-bottom: unset;
      }

      .MuiAvatar-root {
        height: 60px;
        width: 60px;
        border-radius: unset;
      }
      .MuiListItemText-root {
        margin: 0;

        .MuiTypography-root {
          font-size: 16px;
          font-weight: 500;
          line-height: 22px;
          color: #092f51;
          @media (max-width: 580px) {
            font-size: 14px;
          }
        }
      }
    }
  }

  .btnConfirm {
    margin: auto;
    width: 380px;
    @media (max-width: 580px) {
      width: 100%;
    }
  }
`;

export default GuidelineLivenessContainer;
