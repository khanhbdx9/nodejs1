import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import Avatar from '@mui/material/Avatar';

import AppButton from '@components/AppButton';

import { IMGLivenessGuideline1, IMGLivenessGuideline2, IMGLivenessGuideline3 } from '@assets/images'

import GuidelineLivenessContainer from './Styled';

const GuidelineLiveness = ({ isDisabled, handleOpenCamera }) => (
  <GuidelineLivenessContainer>
    <div className="boxGuideline">
      <span className="titleGuideline">Hướng dẫn nhận diện khuôn mặt</span>
      <List>
        <ListItem>
          <Avatar src={IMGLivenessGuideline1} />
          <ListItemText primary="Đưa khung hình vào khớp khuôn mặt và làm theo hướng dẫn" />
        </ListItem>
        <ListItem>
          <Avatar src={IMGLivenessGuideline2} />
          <ListItemText primary="Chú ý đến điều kiện ánh sáng để ảnh không bị tối, bị chói sáng" />
        </ListItem>
        <ListItem>
          <Avatar src={IMGLivenessGuideline3} />
          <ListItemText primary="Không đeo kính mát, khẩu trang hoặc mũ" />
        </ListItem>
      </List>
    </div>
    
    <AppButton 
      label="Tiếp tục"
      className="btnConfirm"
      onClick={handleOpenCamera} 
      disabled={isDisabled}
    />
  </GuidelineLivenessContainer>
);

export default GuidelineLiveness;
