import React from 'react';
import PropTypes from 'prop-types';

import LoadingSpinner from '@components/LoadingSpinner';

import LoadingProcessingContainer from './Styled';

const LoadingProcessing = ({ loading }) => (
  <>
    {loading && (
      <LoadingProcessingContainer>
        <div className="loadingWrapper">
          <div className="loading-watting">
            <LoadingSpinner loading={loading} />
            <div className="content">
              Hệ thống đang thực hiện kiểm tra, vui lòng không đóng hoặc F5
              trình duyệt.
            </div>
          </div>
        </div>
      </LoadingProcessingContainer>
    )}
  </>
);

LoadingProcessing.propTypes = {
  loading: PropTypes.bool,
};

export default LoadingProcessing;
