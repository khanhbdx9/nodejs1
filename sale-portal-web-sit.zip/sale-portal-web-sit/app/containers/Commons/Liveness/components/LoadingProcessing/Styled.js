import styled from 'styled-components';

const LoadingProcessingContainer = styled.div`
  .loadingWrapper {
    position: fixed;
    z-index: 9999;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgb(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-wrap: nowrap;
    &.forMobile {
      justify-content: flex-start;
      align-items: flex-start;
      .loadingIcon {
        width: 30px;
        height: 30px;
        margin: 10px;
        border-width: 2px;
      }
    }
  }
  .loading-watting {
    background: #fff;
    border-radius: 8px;
    padding: 16px 24px;
    display: grid;
    align-items: center;
    justify-content: center;
    gap: 24px;
    padding-bottom: 32px;

    .content {
      color: #092f51;
      font-size: 16px;
      font-weight: 500;
      line-height: 22px;
      text-align: center;
      font-family: SVN-Gilroy;
    }
  }
`;

export default LoadingProcessingContainer;
