import React from 'react';
import get from 'lodash/get';
import size from 'lodash/size';
import { useDispatch, useSelector } from 'react-redux';

import { settingEkycAction } from '@App/actions';

import {IcLivenessCenter, IcLivenessLeft, IcLivenessRight} from '@assets/icons'

import KEYS from "@utils/injectKey";
import useShallowEqualSelector from '@utils/hooks/useShallowEqualSelector'

import { SDK_TS } from '@utils/constants';
import { getLocalByKey } from '@utils/helpers';
import { handleErrorSdkTS } from '@utils/redirect';

import { typeImage, captureFrameSettings } from './store/constants';
import { verifyLivenessAction } from './store/actions';

export default function useLogicLiveness() {
  const dispatch = useDispatch();

  const { settingEkyc } = useShallowEqualSelector(KEYS.GLOBAL, ['settingEkyc']);

  const { 
    loading,
    isShowRetry,
    messageError,
    titleTakeShot,
  } = useSelector(state => state[KEYS.LIVENESS] || {});


  const refTVWebSDK = React.useRef(null);

  const [isShowLayoutTakeShot, setShowLayoutTakeShot] = React.useState(false);
  const [isShowLayoutGuideline, setShowLayoutGuideline] = React.useState(true);
  const [imageBlobLeft, setImageBlobLeft] = React.useState(IcLivenessLeft);
  const [imageBlobRight, setImageBlobRight] = React.useState(IcLivenessRight);
  const [imageBlobCenter, setImageBlobCenter] = React.useState(
    IcLivenessCenter,
  );

  const genSdk = () => {
    if (refTVWebSDK.current === null) {
      refTVWebSDK.current = new TVWebSDK.SDK({
        enableAntiDebug: false,
        container: document.getElementById('TakeShot'),
        lang: 'vi',
        resourceRoot: SDK_TS.myCdnUrlPrefix,
        assetRoot: `${SDK_TS.myCdnUrlPrefix}tvweb-sdk/${
          SDK_TS.sdkVersion
        }/assets`,
      });
    }
  };

  const handleOpenCamera = () => {
    setTimeout(() => {
      handleStartCard(settingEkyc || {});
    }, 500);
  };

  const handleDone = result => {
    const formData = new FormData();
    const appId = getLocalByKey('appId');
    const capturedFrames = get(result, 'capturedFrames', []);
    const images = [
      ...get(result, 'steps', []),
      ...get(result, 'frontalFaces', []).map(_i => ({ image: { blob: _i } })),
    ];

    // convert file Image to jpg and inset formData
    images.forEach((entryReq, indexReq) => {
      let entryReqName = '';
      if (indexReq === size(images) - 1) entryReq.name = 'final';
      if (entryReq.name) {
        entryReqName = `_${entryReq.name}`;
      }

      const imageBolb = get(entryReq, 'image.blob', null);
      const nameFile = `Liveness${appId}${entryReqName}.jpg`;
      const newFile = new File([imageBolb], nameFile, typeImage);

      const objectURL = URL.createObjectURL(newFile);
      if (entryReq.name === 'left') {
        setImageBlobLeft(objectURL);
      }
      if (entryReq.name === 'right') {
        setImageBlobRight(objectURL);
      }
      if (entryReq.name === 'final') {
        setImageBlobCenter(objectURL);
      }

      formData.append("images", newFile);
    });

    // convert frame to jpg and inset formData
    if (size(capturedFrames)) {
      capturedFrames.forEach(frame => {
        const imgBase64 = get(frame, 'base64', null);
        const imgName = `Frame_Liveness_${appId}.jpg`;
        const file = new File(
          [Uint8Array.from(atob(imgBase64), m => m.codePointAt(0))],
          imgName,
          typeImage,
        );

        formData.append('frames', file);
      });
    }

    // append videos for form
    if (get(result, 'video')) {
      const video = get(result, 'video', null);
      const nameFile = `Video${appId}.mp4`;
      // 11/7/24: FE đã warning cho BE là file có thể ko phải mp4
      const newFile = new File([video], nameFile, {
        type: get(result, 'video.type', 'video/mp4'),
      });

      formData.append('video', newFile);
    }

    setShowLayoutTakeShot(true);
    setShowLayoutGuideline(false);
    dispatch(verifyLivenessAction({ formData }));
  };

  const onProcessing = React.useCallback(() => {
    // to avoid camera close immediately when complete steps
    setTimeout(() => {
      refTVWebSDK.current.destroyView();
    }, 250);
  }, []);

  const handleStartCard = React.useCallback(
    clientSettings => {
      refTVWebSDK.current.livenessDetection({
        mode: TVWebSDK.Constants.Mode.ACTIVE,
        onLivenessDetectionDone: handleDone,
        onError: handleErrorSdkTS,
        clientSettings,
        onProcessing,
        captureFrameSettings,
        // apiCredentials: {
        //   accessKey: ACCESS_KEY,
        //   secretKey: PRIVATE_KEY,
        //   apiUrl: API_URL,
        // },
      });
    },
    [handleDone],
  );

  React.useEffect(() => {
    dispatch(settingEkycAction());
  }, []);

  return {
    loading,
    isShowRetry,
    messageError,
    titleTakeShot,
    imageBlobLeft,
    imageBlobRight,
    imageBlobCenter,
    isShowLayoutTakeShot,
    isShowLayoutGuideline,

    isDisabled: false,

    genSdk,
    handleOpenCamera,
  };
}
