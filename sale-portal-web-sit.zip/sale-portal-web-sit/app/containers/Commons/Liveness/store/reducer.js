import { produce } from 'immer';
import get from 'lodash/get';

import { verifyLivenessAction } from './actions';

export const initialState = {
  loading: false,
  isShowRetry: false,
  messageError: null,
  titleTakeShot: 'Vui lòng làm theo hướng dẫn để nhận diện khuôn mặt',
};

const LivenessReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case verifyLivenessAction.REQUEST: {
        draft.loading = true;
        draft.messageError = '';
        draft.isShowRetry = false;
        draft.titleTakeShot = get(action, 'payload.titleTakeShot');
        break;
      }
      case verifyLivenessAction.SUCCESS: {
        // draft.loading = false;
        break;
      }
      case verifyLivenessAction.FAILURE: {
        draft.loading = false;
        draft.isShowRetry = get(action, 'payload.isShowRetry');
        draft.titleTakeShot = get(action, 'payload.titleTakeShot');
        draft.messageError = get(action, 'payload.messageError', null);
        break;
      }
    }
  });

export default LivenessReducer;
