import KEYS from "@utils/injectKey";

export const typeImage = { type: 'image/jpeg' };
export const captureFrameSettings = {
  enable: true,
  framesIntervalTime: 180,
  framesBatchLength: 10,
};


export const VERIFY_LIVENESS_ACTION = `app/${KEYS.LIVENESS}/VERIFY_LIVENESS_ACTION`;
