import { all, call, put, takeLatest } from 'redux-saga/effects';
import { toast } from 'react-toastify';
import get from 'lodash/get';
import { URL, apiRequest } from "@utils/services/api";
import { MESSAGE_SYSTEM } from '@utils/message';
import { verifyLivenessAction } from './actions';

export function* verifyLivenessSaga(action) {
  const payload = {
    url: URL.unsecure.liveness,
    data: get(action, 'payload.formData', null),
  };

  yield put(
    verifyLivenessAction.request({
      titleTakeShot:
        'Hệ thống đang thực hiện nhận diện khuôn mặt. <br/> Vui lòng không tắt hoặc làm mới (F5) trình duyệt.',
    }),
  );

  try {
    const respond = yield call(apiRequest.post, payload);
    const { data, meta } = get(respond, 'data') || {};

    if (get(meta, 'code') === 'IL-200' && data) {
      switch (get(data, 'action')) {
        case 'RETRY': {
          yield put(
            verifyLivenessAction.failure({
              isShowRetry: true,
              messageError: get(data, 'message', ''),
              titleTakeShot: 'Hình ảnh khuôn mặt đã được nhận diện của bạn:',
            }),
          );
          return;
        }
        case 'SUCCESS': {
          yield put(verifyLivenessAction.success());
          toast.success("EKYC thành công");
          break;
        }
        default: {
          toast.error(get(data, 'message', MESSAGE_SYSTEM.error_01));
          break;
        }
      }
      return;
    }

    yield put(
      verifyLivenessAction.failure({
        isShowRetry: true,
        titleTakeShot: 'Hình ảnh khuôn mặt đã được nhận diện của bạn:',
      }),
    );
    toast.error(get(meta, 'message', MESSAGE_SYSTEM.error_02));
  } catch (error) {
    yield put(
      verifyLivenessAction.failure({
        isShowRetry: true,
        titleTakeShot: 'Hình ảnh khuôn mặt đã được nhận diện của bạn:',
      }),
    );

    toast.error(get(error, 'meta.message', MESSAGE_SYSTEM.default));
  }
}

export default function* watchAll() {
  yield all([takeLatest(verifyLivenessAction.TRIGGER, verifyLivenessSaga)]);
}
