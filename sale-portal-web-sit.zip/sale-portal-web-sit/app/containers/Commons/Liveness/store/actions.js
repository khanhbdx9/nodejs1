import { createRoutine } from 'redux-saga-routines';

import { VERIFY_LIVENESS_ACTION } from './constants';


export const verifyLivenessAction = createRoutine(VERIFY_LIVENESS_ACTION);
