import styled, { keyframes } from "styled-components";

const fadeInBounce = keyframes`
  0% {
    opacity: 0;
    transform: translateY(-20px);
  }
  50% {
    opacity: 0.5;
    transform: translateY(5px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
`;

const pulse = keyframes`
  0% {
    opacity: 0.7;
    transform: scale(1);
  }
  50% {
    opacity: 1;
    transform: scale(1.05);
  }
  100% {
    opacity: 0.7;
    transform: scale(1);
  }
`;

const floating = keyframes`
  0% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-10px);
  }
  100% {
    transform: translateY(0);
  }
`;

export const NotFoundContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background: ${({ theme }) => theme.colors.white};
  text-align: center;
  padding: 20px;
`;

// Hiển thị hình ảnh SVG bằng <object> với hiệu ứng floating
export const Image = styled.img`
  width: 500px;
  height: auto;
  margin-bottom: 56px;
  animation: ${floating} 3s ease-in-out infinite;

  @media ${({ theme }) => theme.width.mobile} {
    margin-bottom: 24px;
    width: 360px;
  }
`;

export const Title = styled.h1`
  font-weight: 600;
  margin: 0;
  font-size: 22px;
  margin-bottom: 16px;
  color: ${({ theme }) => theme.colors.drakBlue};
  animation: ${fadeInBounce} 1s ease-in-out;

  @media ${({ theme }) => theme.width.mobile} {
    font-size: 20px; 
    margin-bottom: 8px;
  }
`;

export const Description = styled.p`
  margin: 0;
  font-size: 16px;
  color: ${({ theme }) => theme.colors['5A6D7D']};
  margin-bottom: 24px;
  font-weight: 500;

  @media ${({ theme }) => theme.width.mobile} {
    font-size: 13px;
  }
`;
