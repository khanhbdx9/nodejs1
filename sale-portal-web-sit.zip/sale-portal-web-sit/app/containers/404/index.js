import { IMG404NotFound } from '@assets/images'
import AppButton from '@components/AppButton';
import authService from '@utils/services/authService'
import React from 'react'

import { NotFoundContainer, Image, Title, Description } from './Styled';

const NotFound = () => {
  const handleLogout = () =>  authService.logout();

  return (
    <NotFoundContainer>
      <Image src={IMG404NotFound} alt="404 Not Found" />

      <Title>Lỗi 404, không tìm thấy trang</Title>

      <Description>Xin lỗi, trang bạn tìm kiếm không tồn tại</Description>

      <AppButton variant="outlined" onClick={handleLogout}>
        Về trang chủ
      </AppButton>
    </NotFoundContainer>
  )
};

export default NotFound;
