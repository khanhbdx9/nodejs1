import Box from "@mui/material/Box";
import styled from "styled-components";

const ApplicationDetailContainer = styled(Box)`
  position: relative;
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  overflow: hidden;
`;

export const BodyDetailContainer = styled(Box)`
  padding: 24px;
  display: flex;
  flex-direction: column;
  gap: ${({ gap = 16 }) => gap}px;
  background-color: ${({ theme, $color }) =>
    $color
      ? theme.colors[$color]
        ? theme.colors[$color]
        : $color
      : theme.colors.white};
  @media ${({ theme }) => theme.breakpoints.tablet} {
    padding: 16px;
  }

  .MuiAutocomplete-root {
    background: ${({ theme }) => theme.colors.white};
    max-width: 147px;

    .MuiInputBase-root {
      height: 48px;
      fieldset{
        border-color:${({ theme }) => theme.colors.neutra1001};
        border-width: 1px;
      }
    }
  }

  ul {
    li {
      span {
        b {
          color: ${({ theme }) => theme.colors.lightGreen};
        }
      }
    }
  }
`;

export default ApplicationDetailContainer;
