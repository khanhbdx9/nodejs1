import { createRoutine } from 'redux-saga-routines';

import * as KEY_CONSTANT from './constants';

export const toggleModalConsentAction = payload => ({
  type: KEY_CONSTANT.TOGGLE_MODAL_CONSENT_ACTION,
  payload,
})

export const toggleModalCancelApplicationAction = payload => ({
  type: KEY_CONSTANT.TOGGLE_MODAL_CANCEL_APPLICATION_ACTION,
  payload,
})

export const toggleModalSelectProvinceAction = payload => ({
  type: KEY_CONSTANT.TOGGLE_MODAL_SELECT_PROVINCE_ACTION,
  payload,
})

export const toggleModalSelectBranchAction = payload => ({
  type: KEY_CONSTANT.TOGGLE_MODAL_SELECT_BRANCH_ACTION,
  payload,
})

export const setLayoutEcontractAction = payload => ({
  type: KEY_CONSTANT.SET_LAYOUT_ECONTRACT_ACTION,
  payload,
})

export const resetDataEcontractAction = () => ({
  type: KEY_CONSTANT.RESET_DATA_ECONTRACT_ACTION
})

export const setFieldValueAction = (key, value) => ({
  type: KEY_CONSTANT.SET_FIELD_VALUE_ACTION,
  payload: { key, value }
})

export const deliveryBranchAction = createRoutine(KEY_CONSTANT.DELIVERY_BRANCH_ACTION);

export const submitDeliveryCardAction = createRoutine(KEY_CONSTANT.SUBMIT_DELIVEY_CARD_ACTION);

export const confirmEcontractAction = createRoutine(KEY_CONSTANT.CONFIRM_ECONTRACT_ACTION);

export const cancelEcontractAction = createRoutine(KEY_CONSTANT.CANCEL_ECONTRACT_ACTION);

export const verifyOtpEcontractAction = createRoutine(KEY_CONSTANT.VERIFY_OTP_ECONTRACT_ACTION);

export const resendOtpEcontractAction = createRoutine(KEY_CONSTANT.RESEND_OTP_ECONTRACT_ACTION);