import { produce } from 'immer';

import { 
  deliveryBranchAction, 
  verifyOtpEcontractAction, 
  resendOtpEcontractAction,
  confirmEcontractAction,
  submitDeliveryCardAction
} from './actions';
import { 
  ECONTRACT_LAYOUT,
  SET_FIELD_VALUE_ACTION,
  RESET_DATA_ECONTRACT_ACTION,
  SET_LAYOUT_ECONTRACT_ACTION,
  TOGGLE_MODAL_SELECT_BRANCH_ACTION,
  TOGGLE_MODAL_SELECT_PROVINCE_ACTION,
} from './constants';

export const initialState = {
  isModalConsent: false,
  isModalCancelApp: false,
  isModalSuccessApp: false,
  isModalSelectBranch: false,
  isModalSelectProvince: false,
  isModalCancelEcontract: false,

  currentLayoutEContract: ECONTRACT_LAYOUT.LOADING,

  branchOpt: [],
  msgError: "",
};

const EContractReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      // --------------- SAGA -----------------
      case deliveryBranchAction.REQUEST: {
        draft.branchOpt = [];
        break;
      }
      case deliveryBranchAction.SUCCESS: {
        draft.branchOpt = action?.payload?.items;
        break;
      }
      case deliveryBranchAction.FAILURE: { break }

      case confirmEcontractAction.REQUEST: { break }
      case confirmEcontractAction.FAILURE: { break }
      case confirmEcontractAction.SUCCESS: {
        draft.currentLayoutEContract = ECONTRACT_LAYOUT.CONFIRM_E_CONTRACT;
        break;
      }

      case submitDeliveryCardAction.REQUEST: { break }
      case submitDeliveryCardAction.FAILURE: { break }
      case submitDeliveryCardAction.SUCCESS: {
        draft.currentLayoutEContract = ECONTRACT_LAYOUT.E_CONTRACT;
        break;
      }

      case resendOtpEcontractAction.REQUEST: {
        draft.msgError = "";
        break;
      }
      case resendOtpEcontractAction.SUCCESS: {
        draft.msgError = "";
        break;
      }
      case resendOtpEcontractAction.FAILURE: {
        draft.msgError = action.payload?.message || '';
        break;
      }

      case verifyOtpEcontractAction.REQUEST: {
        draft.msgError = "";
        break;
      }
      case verifyOtpEcontractAction.SUCCESS: {
        draft.msgError = "";
        draft.isModalSuccessApp = true;
        draft.currentLayoutEContract = ECONTRACT_LAYOUT.E_CONTRACT;
        break;
      }
      case verifyOtpEcontractAction.FAILURE: {
        draft.msgError = action.payload?.message || '';
        break;
      }

      // --------------- ACTION NORMAL -----------------
      case TOGGLE_MODAL_SELECT_PROVINCE_ACTION: {
        draft.isModalSelectProvince = action?.payload || false;
        break;
      }

      case TOGGLE_MODAL_SELECT_BRANCH_ACTION: {
        draft.isModalSelectBranch = action?.payload || false;
        break;
      }

      case SET_LAYOUT_ECONTRACT_ACTION: {
        draft.currentLayoutEContract = action?.payload || ECONTRACT_LAYOUT.OTHER;
        break;
      }

      case SET_FIELD_VALUE_ACTION: {
        draft[action.payload.key] = action.payload.value;
        break;
      }   

      case RESET_DATA_ECONTRACT_ACTION: {
        return initialState
      }
    }
  });

export default EContractReducer;
