import LoadingIndicator from '@components/LoadingIndicator';
// import NewFeature from '@components/NewFeature'
import TabsWithTransition from "@components/TabsWithTransition";
import ROUTE from "@routers/constants";
import { useSearchParams } from '@utils/helpers'
import history from "@utils/history";
import { useReduxSameUseState, useDispatchRedux } from "@utils/hooks/useRedux";
import KEY from '@utils/injectKey'
import PropTypes from 'prop-types';
import { useMemo, useEffect } from 'react'

import CardAddressConfirm from './components/CardAddressConfirm';
import CardAddressConfirmForm from './components/CardAddressConfirmForm';
import ConfirmEcontract from './components/ConfirmEcontract'
import Signing from "./components/Signing";
import { setLayoutEcontractAction, resetDataEcontractAction } from './store/actions'
import { ECONTRACT_LAYOUT } from './store/constants';

const Main = ({ detail }) => {
  const { dg } = useSearchParams();

  const resetDataEcontract = useDispatchRedux(resetDataEcontractAction);
  const [currentLayoutEContract, setCurrentLayoutEContract] = useReduxSameUseState(KEY.E_CONTRACT, 'currentLayoutEContract', setLayoutEcontractAction)

  // TODO: cần xử lý lại
  useEffect(()=> {
    if (!dg && detail?.downgrade){
      history.push(ROUTE.portal.DowngradeCard);
      return;
    }
    
    const path = window.location.pathname.replace("/theo-doi-ho-so", "");
    history.replace(path);
    setCurrentLayoutEContract(ECONTRACT_LAYOUT.DELIVERY_ADDRESS);
  }, [detail?.downgrade]);

  const layouts = useMemo(()=>{
    return [
      {
        label: "loading",
        content: <LoadingIndicator />,
      },
      {
        label: "Thông tin nhận thẻ",
        props: { ...detail },
        content: (props) => <CardAddressConfirm {...props} />,
      },
      {
        label: "Thay đổi thông tin nhận thẻ",
        props: { ...detail },
        content: (props) => <CardAddressConfirmForm {...props} />,
      },
      {
        label: "hợp đồng",
        props: { ...detail },
        content: (props) => <Signing {...props} />,
      },
      {
        label: "OTP xác nhận hợp đồng",
        props: {  ...detail },
        content: (props) => <ConfirmEcontract {...props}/>,
      },
      // {
      //   label: "other",
      //   content: <NewFeature 
      //     title="Màn hình không tồn tại" 
      //     dest={`Screen: ${screen} không trùng khớp [DELIVERY_ADDRESS, E_CONTRACT, APPROVED]`}
      //   />,
      // },
    ]
  }, [detail?.id])

  useEffect(()=> {
    return () =>  resetDataEcontract();
  }, []);

  return (
    <TabsWithTransition 
      tabs={layouts} 
      hiddenTabHeader 
      activeTab={currentLayoutEContract} 
    />
  );
};

Main.propTypes = {
  detail: PropTypes.shape({
    downgrade: PropTypes.bool,
    id: PropTypes.oneOfType(PropTypes.string, PropTypes.number),
  }).isRequired,
};

export default Main;
