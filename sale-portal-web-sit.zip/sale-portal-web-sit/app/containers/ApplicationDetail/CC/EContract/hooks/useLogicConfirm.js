import { useDispatchRedux } from "@utils/hooks/useRedux";

import {  resendOtpEcontractAction, verifyOtpEcontractAction } from '../store/actions';

const useLogicConfirm = (id) => {
  const rqResendOtpEcontract = useDispatchRedux(resendOtpEcontractAction);
  const rqVerifyOtpEcontract = useDispatchRedux(verifyOtpEcontractAction);

  const handleResendOtp = () => {
    return rqResendOtpEcontract(id);
  };

  const handleVerifyOtp = (data) => {
    return rqVerifyOtpEcontract({ data, id });
  };
  
  return {
    handleResendOtp,
    handleVerifyOtp,
  }
}

export default useLogicConfirm;