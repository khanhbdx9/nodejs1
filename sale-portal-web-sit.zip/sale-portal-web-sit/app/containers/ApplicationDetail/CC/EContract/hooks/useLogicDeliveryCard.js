import useProvince from "@utils/hooks/useProvince";
import { useDispatchRedux } from "@utils/hooks/useRedux";
import { useFormik } from "formik";
import { useMemo } from "react";
// import sizeLd from "lodash/size";

import useBranchOpt from "./useBranchOpt";
import { setLayoutEcontractAction, submitDeliveryCardAction, setFieldValueAction } from "../store/actions";
import { defaultInitialValues, DELIVERY, ECONTRACT_LAYOUT } from "../store/constants";

const useLogicDeliveryCard = ({ provinceCode, branchCode, deliveryType, validation }) => {
  const { provinceOpt } = useProvince();
  const { branchOpt, fetchDeliveryBranch } = useBranchOpt(provinceCode);
  
  const submitDeliveryCard = useDispatchRedux(submitDeliveryCardAction);
  const setLayoutEcontract = useDispatchRedux(setLayoutEcontractAction);
  const setFieldValueEcontractRedux = useDispatchRedux(setFieldValueAction);

  const setToggleSelecteBranch = (value) => setFieldValueEcontractRedux('isModalSelectBranch', value)
  const setToggleSelecteProvice = (value) => setFieldValueEcontractRedux('isModalSelectProvince', value)

  const initialValues = useMemo(() => {
    const _deliveryType = deliveryType || defaultInitialValues.deliveryType;
    const branch = branchOpt.find(b => b?.branch_code === branchCode) || defaultInitialValues.branch;
    const province = provinceOpt.find(p => p?.code === provinceCode) || defaultInitialValues.province;
    return { branch, province, deliveryType: _deliveryType };
  }, [provinceCode, branchCode, deliveryType, provinceOpt]);

  const formik = useFormik({
    initialValues,
    validate: validation,
    enableReinitialize: true,
    onSubmit: ({ deliveryType, branch, province }) => {
      const isBranch = deliveryType === DELIVERY.BRANCH.type;

      const payload = {
        deliveryType: deliveryType || null,
        ...(isBranch && {
          branchCode: branch?.branch_code || null,
          provinceCode: province?.code || null,
        }),
      };
    
      submitDeliveryCard(payload);
    },
  });
  console.log(formik.values)

  const isBranchDelivery = formik.values.deliveryType === DELIVERY.BRANCH.type;

  const handleProvinceChange = (event) => {
    const code = event?.target?.value?.code;
    if (formik.values.branch.branch_code) {
      formik.setFieldValue('branch', defaultInitialValues.branch);
    }
    if (code) fetchDeliveryBranch(code);
    formik.handleChange(event);
  };

  return { 
    formik,
    branchOpt,
    provinceOpt,
    isBranchDelivery,

    handleProvinceChange,
    setToggleSelecteBranch,
    setToggleSelecteProvice,
    
    handleCancel: () => setLayoutEcontract(ECONTRACT_LAYOUT.DELIVERY_ADDRESS),
  }

}

export default useLogicDeliveryCard;