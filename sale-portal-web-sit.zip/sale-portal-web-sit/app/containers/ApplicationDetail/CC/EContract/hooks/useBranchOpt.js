import useShallowEqualSelector from '@utils/hooks/useShallowEqualSelector';
import KEY from '@utils/injectKey'
import { useEffect } from 'react';
import { useDispatch } from 'react-redux';

import { deliveryBranchAction } from '../store/actions'

const useBranchOpt = (provinceCode) => {
  const dispatch = useDispatch();

  const { branchOpt = [] } = useShallowEqualSelector(KEY.E_CONTRACT, ['branchOpt'])

  const fetchDeliveryBranch = (code) => dispatch(deliveryBranchAction({ provinceCode: code }))

  useEffect(() => {
    if (provinceCode) fetchDeliveryBranch(provinceCode);
  }, [provinceCode]);

  return {
    branchOpt,
    fetchDeliveryBranch
  }
}

export default useBranchOpt;