import { useDispatchRedux } from "@utils/hooks/useRedux";
import { useEffect } from 'react';

import { 
  confirmEcontractAction,
  cancelEcontractAction,
  setFieldValueAction,
} from '../store/actions';
import { APPROVED } from '../store/constants';

const useLogicSigning = (screen) => {
  const rqConfirmEcontract = useDispatchRedux(confirmEcontractAction)
  const rqCancelEcontract = useDispatchRedux(cancelEcontractAction)
  const setFieldValueEcontractRedux = useDispatchRedux(setFieldValueAction)

  const onConfirmEcontract = (appId) =>  rqConfirmEcontract({ id: appId })
  
  const onCancelEcontract = () => setFieldValueEcontractRedux('isModalCancelEcontract', true)
  
  const closeModalCancelEcontract = () => setFieldValueEcontractRedux('isModalCancelEcontract', false);

  const confirmCancelEcontract = (appId) => {
    closeModalCancelEcontract();
    rqCancelEcontract({ appId })
  }

  useEffect(()=>{
    if(screen !== APPROVED) return
    
    setFieldValueEcontractRedux('isModalSuccessApp', true)
  },[screen])

  return {
    onCancelEcontract,
    onConfirmEcontract,
    confirmCancelEcontract,
    closeModalCancelEcontract,
  }
}

export default useLogicSigning;