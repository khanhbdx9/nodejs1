import ModalSearchByFieldName from '@components/Modal/ModalSearchByFieldName';
import useShallowEqualSelector from '@utils/hooks/useShallowEqualSelector';
import KEY from '@utils/injectKey';
import PropTypes from 'prop-types';

const ModalBranchSelect = ({ name, items = [], itemActive, provinceName = '', handleClose, handleChange }) => {
  const { isModalSelectBranch } = useShallowEqualSelector(KEY.E_CONTRACT, ['isModalSelectBranch']);

  const onChange = (value) => {
    handleChange({ target: { name, value } });
    handleClose();
  };

  return (
    <ModalSearchByFieldName 
      open={isModalSelectBranch}
      itemActive={itemActive}
      items={items}
      field="branch_code"
      fieldName="branch_name"
      title={`Chi nhánh thuộc ${provinceName}`}
      desEmpty="Không tìm thấy Chi nhánh nào!"
      handleClose={handleClose}
      handleChange={onChange}
    />
  );
};

ModalBranchSelect.propTypes = {
  name: PropTypes.string.isRequired,
  items: PropTypes.arrayOf(PropTypes.object),
  itemActive: PropTypes.object,
  provinceName: PropTypes.string,
  handleClose: PropTypes.func.isRequired,
  handleChange: PropTypes.func.isRequired,
};

export default ModalBranchSelect;
