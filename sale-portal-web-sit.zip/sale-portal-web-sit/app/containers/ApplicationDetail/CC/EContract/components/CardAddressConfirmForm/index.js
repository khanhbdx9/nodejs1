import AppButton from "@components/AppButton";
import { ListItemDetail } from "@components/Detail";
import { Title, Text, ErrorMessage } from "@components/Styled/Title";
import BorderColorOutlinedIcon from "@mui/icons-material/BorderColorOutlined";
import Box from "@mui/material/Box";
import VPB_COLOR from "@ThemeProvider/colors";
import PropTypes from "prop-types";
import { Fragment } from "react";

import CardRadioLabel from './CardRadioLabel'
import ModalBranchSelect from "./ModalBranchSelect";
import ModalProviceSelect from "./ModalProviceSelect";
import { CardAddressConfirmFormContainer, TextBranchContainer } from "./Styled";
import validation from "./validation"
import useLogicDeliveryCard from "../../hooks/useLogicDeliveryCard";
import { DELIVERY } from "../../store/constants";
import { ActionContainer } from "../../Styled";

const CardAddressConfirmForm = ({
  provinceCode,
  branchCode,
  deliveryType,
  currentAddress,
  companyAddress,
}) => {
  const {
    formik,
    branchOpt,
    provinceOpt,
    isBranchDelivery,

    handleCancel,
    handleProvinceChange,
    setToggleSelecteBranch,
    setToggleSelecteProvice,
  } = useLogicDeliveryCard({ provinceCode, branchCode, deliveryType, validation });

  const { province, branch, deliveryType: selectedDeliveryType } = formik.values;

  return (
    <Fragment>
      <CardAddressConfirmFormContainer
        name="deliveryType"
        value={selectedDeliveryType}
        onChange={formik.handleChange}
      >
        <Title $size={16} $weight={500} $color={VPB_COLOR.neutral} $align="center">
          Vui lòng xác nhận thông tin địa chỉ nhận thẻ tín dụng vật lý của bạn
        </Title>

        {/* --- BRANCH ADDRESS --- */}
        <CardRadioLabel value={DELIVERY.BRANCH.type} label={DELIVERY.BRANCH.name}>
          <ListItemDetail
            primary="Tỉnh/ Thành phố"
            secondary={
              <Box className="dgrid">
                <Box className="dflex gap-8">
                  <Text $weight={600} $color={province?.code ? VPB_COLOR.darkBlue : VPB_COLOR.neutra1}>
                    {province?.name || "Chọn Tỉnh/Thành phố"}
                  </Text>
                  {isBranchDelivery && (
                    <AppButton
                      variant="text"
                      // disabled={!isBranchDelivery}
                      onClick={() => setToggleSelecteProvice(true)}
                      style={{ padding: 0, minWidth: 20, height: 20 }}
                    >
                      <BorderColorOutlinedIcon color={VPB_COLOR.darkBlue} />
                    </AppButton>
                  )}
                  
                </Box>
                <ErrorMessage $error={formik.touched.province} align="right">{formik.errors.province}</ErrorMessage>
              </Box>
            }
          />
          <ListItemDetail
            primary="Chi nhánh"
            secondary={
              <Box>
                <TextBranchContainer>
                  <Box className="dflex gap-8 justify-end">
                    <Text $weight={600} $color={branch?.branch_code ? VPB_COLOR.darkBlue : VPB_COLOR.neutra1}>
                      {branch?.branch_name || "Chọn chi nhánh"}
                    </Text>
                    {isBranchDelivery && (
                      <AppButton
                        variant="text"
                        disabled={!province?.code}
                        onClick={() => setToggleSelecteBranch(true)}
                        style={{ padding: 0, minWidth: 20, height: 20 }}
                      >
                        <BorderColorOutlinedIcon color={VPB_COLOR.darkBlue} />
                      </AppButton>
                    )}
                  </Box>
                  {branch?.address_detail && (
                    <Text $size={14} $line="120%" $align="right" $color={VPB_COLOR.neutral}>
                      {branch.address_detail}
                    </Text>
                  )}
                </TextBranchContainer>

                <ErrorMessage $error={formik.touched.province} align="right">{formik.errors.branch}</ErrorMessage>
              </Box>
            }
          />
        </CardRadioLabel>

        {/* --- CURRENT ADDRESS --- */}
        <CardRadioLabel value={DELIVERY.CURADDR.type} label={DELIVERY.CURADDR.name}>
          <Text $color={VPB_COLOR.neutral}>
            {currentAddress || "Chưa có địa chỉ hiện tại"}
          </Text>
        </CardRadioLabel>

        {/* --- COMPANY ADDRESS --- */}
        <CardRadioLabel value={DELIVERY.COMPANY.type} label={DELIVERY.COMPANY.name}>
          <Text $color={VPB_COLOR.neutral}>
            {companyAddress || "Chưa có địa chỉ công ty"}
          </Text>
        </CardRadioLabel>

        <ActionContainer $position="right" $minWidth={150}>
          <AppButton
            variant="outlined"
            label="Hủy"
            style={{ color: VPB_COLOR.darkBlue, borderColor: VPB_COLOR.neutra1 }}
            onClick={handleCancel}
          />
          <AppButton 
            label="Tiếp tục" 
            onClick={formik.handleSubmit} 
          />
        </ActionContainer>
      </CardAddressConfirmFormContainer>

      <ModalProviceSelect
        name="province"
        items={provinceOpt}
        itemActive={province}
        handleChange={handleProvinceChange}
        handleClose={() => setToggleSelecteProvice(false)}
      />
      <ModalBranchSelect
        name="branch"
        items={branchOpt}
        provinceName={province?.name || ''}
        handleChange={formik.handleChange}
        handleClose={() => setToggleSelecteBranch(false)}
      />
    </Fragment>
  );
};

CardAddressConfirmForm.propTypes = {
  provinceCode: PropTypes.string,
  branchCode: PropTypes.string,
  currentAddress: PropTypes.string,
  companyAddress: PropTypes.string,
  deliveryType: PropTypes.string,
};

export default CardAddressConfirmForm;
