import AppButton from "@components/AppButton";
import { GroupBox } from "@components/Detail";
import { Title, Text } from "@components/Styled/Title";
import VPB_COLOR from "@ThemeProvider/colors";
import { useDispatchRedux } from "@utils/hooks/useRedux"
import PropTypes from "prop-types";

import BranchAddressDetail from "./BranchAddressDetail";
import { CardAddressConfirmContainer } from "./Styled";
import { setLayoutEcontractAction, submitDeliveryCardAction } from "../../store/actions";
import { DELIVERY, ECONTRACT_LAYOUT } from "../../store/constants";
import { ActionContainer } from "../../Styled";

const CardAddressConfirm = ({
  deliveryType = "",
  provinceCode = "",
  branchCode = "",
  currentAddress = "",
  companyAddress = "",
  branchName = "",
  branchDetail = "",
  provinceName = "",
}) => {
  const submitDeliveryCard = useDispatchRedux(submitDeliveryCardAction);
  const setLayoutEcontract = useDispatchRedux(setLayoutEcontractAction);

  const delivery = DELIVERY[deliveryType] || {};

  const renderDeliveryContent = () => {
    switch (deliveryType) {
      case DELIVERY.BRANCH.type:
        return (
          <BranchAddressDetail
            branchName={branchName}
            branchDetail={branchDetail}
            provinceName={provinceName}
          />
        );
      case DELIVERY.CURADDR.type:
        return <Text $color={VPB_COLOR.neutral}>{currentAddress}</Text>;
      case DELIVERY.COMPANY.type:
        return <Text $color={VPB_COLOR.neutral}>{companyAddress}</Text>;
      default:
        return (
          <Text $color={VPB_COLOR.neutral}>
            {`Loại địa chỉ: ${deliveryType} không tồn tại địa chỉ nhận thẻ!`}
          </Text>
        );
    }
  };

  const handleSubmit = () => {
    const payload = { deliveryType }

    if(deliveryType === DELIVERY.BRANCH.type){
      payload.branchCode = branchCode;
      payload.provinceCode = provinceCode;
    }

    submitDeliveryCard(payload)
  }

  return (
    <CardAddressConfirmContainer>
      <Title
        $size={16}
        $weight={500}
        $color={VPB_COLOR.neutral}
        $align="center"
      >
        Vui lòng xác nhận thông tin địa chỉ nhận thẻ tín dụng vật lý của bạn
      </Title>

      <GroupBox title={delivery.name || "Địa chỉ nhận thẻ"} contentPadding="0px 16px 16px">
        {renderDeliveryContent()}
      </GroupBox>

      <ActionContainer $position="right" $minWidth={150}>
        <AppButton
          variant="outlined"
          label="Thay đổi"
          style={{ color: VPB_COLOR.darkBlue, borderColor: VPB_COLOR.neutra1 }}
          onClick={()=> setLayoutEcontract(ECONTRACT_LAYOUT.CHANGE_DELIVERY_ADDRESS)}
        />
        <AppButton 
          label="Tiếp tục" 
          onClick={handleSubmit}
        />
      </ActionContainer>
    </CardAddressConfirmContainer>
  );
};

CardAddressConfirm.propTypes = {
  deliveryType: PropTypes.string,
  provinceCode: PropTypes.string,
  branchCode: PropTypes.string,
  branchName: PropTypes.string,
  branchDetail: PropTypes.string,
  provinceName: PropTypes.string,
  currentAddress: PropTypes.string,
  companyAddress: PropTypes.string,
};

export default CardAddressConfirm;
