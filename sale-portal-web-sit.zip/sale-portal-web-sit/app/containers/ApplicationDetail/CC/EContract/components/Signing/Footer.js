import AppButton from "@components/AppButton";
import { Text } from "@components/Styled/Title";
import Box from "@mui/material/Box";
import Link from "@mui/material/Link";
import PropTypes from 'prop-types';

import { ActionContainer } from "../../Styled";

function Footer({
  onConfirm = () => {},
  onCancel = () => {},
}) {
  return (
    <Box>
      <Text>
        Bằng cách nhấn chọn vào nút ‘Xác nhận hợp đồng’, tôi xin xác nhận:
        Đã đọc, hiểu rõ và chấp thuận toàn bộ thông tin hợp đồng cấp hạn mức tín
        dụng, phát hành và sử dụng thẻ cũng như:
        {" "} <Link target='_blank' href="https://www.vpbank.com.vn/-/media/vpbank-latest/tai-lieu-bieu-mau/bieu-mau/khcn/dieu-kien-giao-dich-chung-ve-cap-tin-dung-danh-cho-khach-hang-ca-nhan-tai-vpbank-07112022.pdf"> Điều khoản và điều kiện tín dụng</Link>
        {" "} và
        {" "} <Link target='_blank' href="https://www.vpbank.com.vn/-/media/vpbank-latest/tai-lieu-bieu-mau/bieu-mau/khcn/dkgd-chung-ve-cung-cap-va-su-dung-dich-vu-phi-tin-dung-ap-dung-doi-voi-khcn-tai-vpbank.pdf"> Điều khoản và điều kiện phi tín dụng </Link>
        {" "} của VPBank
      </Text>

      <ActionContainer
        $position="right"
        $minWidth={150}
        sx={{ marginTop: "16px" }}
      >
        <AppButton 
          variant="outlined" 
          label="Hủy hồ sơ" 
          onClick={onCancel}
        />
        <AppButton 
          label="Xác nhận" 
          onClick={onConfirm}
        />
      </ActionContainer>
    </Box>
  );
}

Footer.propTypes = {
  isDisabled: PropTypes.bool,
  onConfirm: PropTypes.func,
  onCancel: PropTypes.func,
};

export default Footer;
