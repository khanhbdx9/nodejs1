import OtpInput from "@components/OtpInput";
import { BodyDetailContainer } from "@containers/ApplicationDetail/styles";
import { useOneState } from "@utils/hooks/useRedux";
import KEYS from "@utils/injectKey";
import PropTypes from "prop-types";

import useLogicConfirm from "../../hooks/useLogicConfirm";

const ConfirmEcontract = ({ id, phoneNumber }) => {
  const msgError = useOneState(KEYS.E_CONTRACT, "msgError");
  const { handleResendOtp, handleVerifyOtp } = useLogicConfirm(id);

  const handleSubmitOtp = (otpCode) => {
    handleVerifyOtp({ otpCode, phoneNumber });
  };

  return (
    <BodyDetailContainer>
      <OtpInput
        phoneNumber={phoneNumber}
        errorText={msgError}
        onResendOtp={handleResendOtp}
        onSubmit={handleSubmitOtp}
      />
    </BodyDetailContainer>
  );
};

ConfirmEcontract.propTypes = {
  id: PropTypes.number.isRequired,
  phoneNumber: PropTypes.string.isRequired,
};

export default ConfirmEcontract;
