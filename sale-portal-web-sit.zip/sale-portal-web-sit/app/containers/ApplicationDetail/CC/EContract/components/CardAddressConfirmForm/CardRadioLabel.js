import { GroupBox } from "@components/Detail";
import { Text } from "@components/Styled/Title";
import FormControlLabel from "@mui/material/FormControlLabel";
import Radio from "@mui/material/Radio";
import PropTypes from "prop-types";

const CardRadioLabel = ({
  value,
  label,
  children,
}) => (
  <GroupBox
    contentPadding="0px 16px 16px"
    title={
      <FormControlLabel
        value={value}
        control={<Radio />}
        label={<Text $weight={600} $size={18}>{label}</Text>}
      />
    }
  >
    {children}
  </GroupBox>
);

CardRadioLabel.propTypes = {
  value: PropTypes.string.isRequired,
  label: PropTypes.string.isRequired,
  children: PropTypes.node,
};

export default CardRadioLabel;
