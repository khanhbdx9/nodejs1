import ApplicationStep from "@components/ApplicationStep";
import { BodyDetailContainer } from "@containers/ApplicationDetail/styles";
import PropTypes from 'prop-types';

import Contracts from "./Contracts";
import Footer from "./Footer";
import LoanInfo from "./LoanInfo";
import ModalCloseEcontract from './ModalCloseEcontract'
import ModalSuccess from './ModalSuccess'
import useLogicSigning from '../../hooks/useLogicSigning'

function Signing({ 
  id,
  casa = null,
  cardName = "",
  screen = "",
  saleFullName = "",
  salePhoneNumber = "",
  primaryProductIcon = "",
  primaryProductName = "",
  expiryDateFormat = "", 
  finalApprovedLimitFormat="",
}) {
  const {
    onCancelEcontract, 
    onConfirmEcontract,
    confirmCancelEcontract,
    closeModalCancelEcontract
  } = useLogicSigning(screen)

  return (
    <>
      <BodyDetailContainer>
        <ApplicationStep currentStep={4} />

        <Contracts isCasa={!!casa}/>

        <LoanInfo
          cardName={cardName}
          expiryDateFormat={expiryDateFormat}
          primaryProductName={primaryProductName}
          primaryProductIcon={primaryProductIcon}
          finalApprovedLimitFormat={finalApprovedLimitFormat}
        />

        <Footer
          onCancel={onCancelEcontract}
          onConfirm={() => onConfirmEcontract(id)}
        />
      </BodyDetailContainer>

      <ModalSuccess saleFullName={saleFullName} salePhoneNumber={salePhoneNumber}/>

      <ModalCloseEcontract
        handleClose={closeModalCancelEcontract}
        handleConfirm={() => confirmCancelEcontract(id)}
      />
    </>
    
  );
}

Signing.propTypes = {
  id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  screen: PropTypes.string,
  cardName: PropTypes.string,
  saleFullName: PropTypes.string,
  salePhoneNumber: PropTypes.string,
  primaryProductIcon: PropTypes.string,
  primaryProductName: PropTypes.string,
  expiryDateFormat: PropTypes.string,
  casa: PropTypes.bool,
  finalApprovedLimitFormat: PropTypes.string,
};


export default Signing;
