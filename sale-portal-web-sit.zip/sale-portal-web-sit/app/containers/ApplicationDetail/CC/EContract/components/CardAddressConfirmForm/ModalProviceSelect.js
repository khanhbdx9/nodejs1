import ModalSearchByFieldName from '@components/Modal/ModalSearchByFieldName';
import useShallowEqualSelector from '@utils/hooks/useShallowEqualSelector';
import KEY from '@utils/injectKey';
import PropTypes from 'prop-types';

const ModalProviceSelect = ({ 
  name, 
  items = [], 
  itemActive = null, 
  handleClose, 
  handleChange 
}) => {
  const { isModalSelectProvince } = useShallowEqualSelector(KEY.E_CONTRACT, ['isModalSelectProvince']);

  const onChange = (value) => {
    handleChange({ target: { name, value } });
    handleClose();
  };

  return (
    <ModalSearchByFieldName 
      open={isModalSelectProvince}
      itemActive={itemActive}
      items={items}
      field="code"
      title="Tỉnh/Thành phố" 
      desEmpty="Không tìm thấy Tỉnh/Thành phố nào!"
      handleClose={handleClose}
      handleChange={onChange}
    />
  );
};

ModalProviceSelect.propTypes = {
  name: PropTypes.string.isRequired,
  items: PropTypes.arrayOf(PropTypes.object),
  itemActive: PropTypes.object,
  handleClose: PropTypes.func.isRequired,
  handleChange: PropTypes.func.isRequired,
};

export default ModalProviceSelect;
