import { Box } from '@mui/material';
import styled from 'styled-components';
import RadioGroup from '@mui/material/RadioGroup';

export const CardAddressConfirmFormContainer = styled(RadioGroup)`
  padding: 24px;
  display: grid;
  gap: 16px;
  @media ${(p) => p.theme.breakpoints.tablet} {
    padding: 16px;
  }

  h3 {
    line-height: 40px;
    @media ${(p) => p.theme.breakpoints.tablet} {
      line-height: 140%;
    }
  }

  .GroupBox {
    .header {
      padding: 16px;
      
      h3{
        line-height: 150%;

        .MuiFormControlLabel-root {
          margin: 0;
          gap: 16px;
          margin-left: -5px;

          .MuiButtonBase-root {
            padding: 4px;
          }
        }
      }
    }
    .body {
      .MuiListItemText-root {
        &:last-child {
          align-items: flex-start;
        }  

        .MuiTypography-body1 {
          min-width: 125px;
        }
      }
    }
  }
  
`;

export const TextBranchContainer = styled(Box)`
  display: grid;
  gap: 16px;
`;

