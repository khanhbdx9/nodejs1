import { DELIVERY } from "../../store/constants";

const validation = ({ deliveryType, branch, province }) => {
  const error = {};

  const isBranchDelivery = deliveryType === DELIVERY.BRANCH.type;

  if (isBranchDelivery) {
    if (!province?.code) {
      error.province = "Chọn tỉnh thành phố!";
    }

    if (!branch?.branch_code) {
      error.branch = "Chọn chi nhánh!";
    }
  }

  return error;
};

export default validation;
