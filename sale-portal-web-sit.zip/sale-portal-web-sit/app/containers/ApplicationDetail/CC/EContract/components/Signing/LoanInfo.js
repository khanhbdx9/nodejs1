import AppImage from "@components/AppImage"
import { ListItemDetail, CollapseBox } from "@components/Detail";
import Title, { Text } from "@components/Styled/Title";
import Box from "@mui/system/Box";
import PropTypes from "prop-types";

import { LoanContainer } from "../../Styled";

const LoanInfo = ({
  primaryProductName = "",
  primaryProductIcon = "",
  finalApprovedLimitFormat = "",
  expiryDateFormat = "",
  cardName = ""
}) => {
  return (
    <CollapseBox>
      <LoanContainer>
        <AppImage src={primaryProductIcon} minWidth={60} width={160} height={95} isOrientation/>
        <Box className="cardName">
          <Text $color="neutral">{primaryProductName}</Text>
          <Title>{cardName}</Title>
        </Box>
      </LoanContainer>

      <ListItemDetail
        hideBorder
        primary="Hạn mức phê duyệt"
        secondary={`${finalApprovedLimitFormat} VNĐ`}
      />

      {/* <ListItemDetail primary="Lãi suất" secondary={limit} /> */}

      <ListItemDetail primary="Thời hạn xác nhận" secondary={expiryDateFormat} />
    </CollapseBox>
  );
};

LoanInfo.propTypes = {
  cardName: PropTypes.string,
  primaryProductName: PropTypes.string,
  primaryProductIcon: PropTypes.string,
  finalApprovedLimitFormat: PropTypes.string,
  expiryDateFormat: PropTypes.string,
};

export default LoanInfo;
