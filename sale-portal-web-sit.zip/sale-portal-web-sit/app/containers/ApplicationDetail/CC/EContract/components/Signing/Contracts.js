import { IcPdf } from "@assets/icons";
import { GroupBox } from "@components/Detail";
import { Text } from "@components/Styled/Title";
import Box from "@mui/material/Box";
import Link from "@mui/material/Link";
import VPB_COLOR from '@ThemeProvider/colors';
import { ROOT_URI } from '@utils/constants'
import { openExternalLink } from "@utils/helpers";
import { URL } from "@utils/services/api";
import PropTypes from "prop-types";

import { ContractListContainer } from "../../Styled";

const linkCasa = `${ROOT_URI}/${URL.unsecure.genCasa}`
const linkEcontract = `${ROOT_URI}/${URL.unsecure.genEContract}`

const Contracts = ({ isCasa }) => {
  return (
    <GroupBox contentPadding="16px">
      <Text>
        Căn cứ trên hồ sơ mà Quý khách cung cấp, chúng tôi tạo lập hợp đồng điện
        tử như sau:
      </Text>
      <ContractListContainer>
        <Box className="contract">
          <img src={IcPdf} alt="pdf" />
          <Link 
            component="button" 
            onClick={() => openExternalLink(linkEcontract)} 
            style={{ 
              color: VPB_COLOR.darkBlue,
              textDecorationColor: VPB_COLOR.darkBlue,
            }}
          >
            <Text>Hợp đồng điện tử</Text>
          </Link>
        </Box>
        {
          isCasa && (
            <Box className="contract">
              <img src={IcPdf} alt="pdf" />
              <Link 
                component="button" 
                onClick={() => openExternalLink(linkCasa)} 
                style={{ 
                  color: VPB_COLOR.darkBlue,
                  textDecorationColor: VPB_COLOR.darkBlue,
                }}
              >
                <Text>Hợp đồng Tài khoản thanh toán</Text>
              </Link>
            </Box>
          )
        }
        
      </ContractListContainer>
    </GroupBox>
  );
};

Contracts.propTypes = {
  isCasa: PropTypes.bool,
};

export default Contracts;
