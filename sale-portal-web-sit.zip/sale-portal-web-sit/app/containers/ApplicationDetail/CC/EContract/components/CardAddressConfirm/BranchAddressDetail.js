import { ListItemDetail } from "@components/Detail";
import { Text } from "@components/Styled/Title";
import VPB_COLOR from "@ThemeProvider/colors";
import PropTypes from "prop-types";

import { TextBranchContainer } from "./Styled";

const BranchAddressDetail = ({
  branchName = "",
  branchDetail = "",
  provinceName = "",
}) => {

  return (
    <>
      <ListItemDetail
        primary="Tỉnh/ Thành phố"
        secondary={<Text $weight={600}>{provinceName}</Text>}
      />
      <ListItemDetail
        primary="Chi nhánh"
        style={{ paddingBottom: 0 }}
        secondary={
          <TextBranchContainer>
            <Text $weight={600} $align="right">
              {branchName}
            </Text>
            <Text
              $size={14}
              $line="120%"
              $align="right"
              color={VPB_COLOR.neutral}
            >
              {branchDetail}
            </Text>
          </TextBranchContainer>
        }
      />
    </>
  );
};

BranchAddressDetail.propTypes = {
  branchName: PropTypes.string.isRequired,
  branchDetail: PropTypes.string.isRequired,
  provinceName: PropTypes.string.isRequired,
};

export default BranchAddressDetail;
