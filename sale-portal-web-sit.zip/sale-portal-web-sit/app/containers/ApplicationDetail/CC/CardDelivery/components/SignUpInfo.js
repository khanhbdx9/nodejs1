import AppImage from "@components/AppImage";
import { Text } from "@components/Styled/Title";
import PropTypes from "prop-types";

import { SignUpInfoStyle } from "../Styled";

const SignUpInfo = ({
  isVPO,
  urlCardImage = "",  }) => {
  return (
    <SignUpInfoStyle>
      <AppImage src={urlCardImage} alt="card" width={"auto"} height={254} isOrientation/>
      
      <Text $align="center" $size={24} $weight={700}>
        {isVPO ? "Thẻ được mở thành công" : "Hoàn thành đăng ký"}
      </Text>

      <Text $align="center">Thẻ tín dụng đang được giao đến bạn</Text>
    </SignUpInfoStyle>
  );
};

SignUpInfo.propTypes = {
  isVPO: PropTypes.bool,
  urlCardImage: PropTypes.string,
};

export default SignUpInfo;
