import { ListItemDetail, GroupBox } from "@components/Detail";
import { PACKAGE } from '@utils/constants'
import PropTypes from "prop-types";

const VPBankOnlineInfo = ({ account = "", servicePackage = "" }) => {
  return (
    <GroupBox
      title="Thông tin dịch vụ VPBank Online"
      color={{ border: "paleAqua", background: "lightAqua" }}
    >
      <ListItemDetail primary="Tên đăng nhập" secondary={account} hideBorder />
      
      <ListItemDetail
        primary="Mật khẩu"
        secondary={"Vui lòng kiểm tra tin nhắn từ VPBank"}
      />

      <ListItemDetail primary="Gói đăng ký" secondary={PACKAGE[servicePackage] || ''} />
    </GroupBox>
  );
};

VPBankOnlineInfo.propTypes = {
  account: PropTypes.string,
  servicePackage: PropTypes.string,
};

export default VPBankOnlineInfo;
