import ApplicationStep from "@components/ApplicationStep";
import { ListItemDetail, GroupBox } from "@components/Detail";
import PropTypes from "prop-types";

import { DeliveryDetailContainer } from '../Styled'

const steps = [
  { label: "In thẻ" },
  { label: "Bàn giao cho đơn vị vận chuyển" },
  { label: "Giao thành công" },
];

const DeliveryDetail = ({ shippingUnit = "", shippingCode = "", stepDeliveryCard = 0 }) => {
  return (
    <DeliveryDetailContainer>
      <GroupBox
        title="Hành trình giao thẻ"
        color={{ border: "neutra1001", background: "white" }}
      >
        <ApplicationStep steps={steps} currentStep={stepDeliveryCard} />
        
        <ListItemDetail
          primary="Đơn vị vận chuyển"
          secondary={shippingUnit}
          hideBorder
        />

        <ListItemDetail primary="Mã vận đơn" secondary={shippingCode} />
      </GroupBox>
    </DeliveryDetailContainer>
  );
};

DeliveryDetail.propTypes = {
  shippingUnit: PropTypes.string,
  shippingCode: PropTypes.string,
  stepDeliveryCard: PropTypes.number,
};

export default DeliveryDetail;
