import { IcLocation } from "@assets/icons";
import AppImage from "@components/AppImage";
import { GroupBox } from "@components/Detail";
import Title, { Text } from "@components/Styled/Title";
import Box from "@mui/material/Box";
import PropTypes from "prop-types";

import { ReceiveAddressStyle } from "../Styled";

const ReceiveAddress = ({
  branch = "Chi nhánh VPBank",
  addressDetail = "89 Láng Hạ, Đống Đa, Hà Nội",
}) => {
  return (
    <GroupBox
      contentPadding="16px"
      color={{ border: "neutra1001", background: "white" }}
    >
      <ReceiveAddressStyle>
        <Box className="title">
          <AppImage src={IcLocation} alt="card" width={18} height={18} />
          <Text>Địa chỉ nhận thẻ</Text>
        </Box>
        <Title>{branch}</Title>
        <Text>{addressDetail}</Text>
      </ReceiveAddressStyle>
    </GroupBox>
  );
};

ReceiveAddress.propTypes = {
  branch: PropTypes.string,
  addressDetail: PropTypes.string,
};

export default ReceiveAddress;
