import { StepLabel } from '@components/ApplicationStep/Styled'
import Box from "@mui/material/Box";
import styled from "styled-components";

export const SignUpInfoStyle = styled(Box)`
  display: flex;
  flex-direction: column;
  margin: 0px auto;
  gap: 16px;
`;

export const ReceiveAddressStyle = styled(Box)`
  display: flex;
  flex-direction: column;
  margin: 0px auto;
  gap: 16px;
  .title {
    display: flex;
    gap: 6;
    align-items: center;
  }
`;

export const DeliveryDetailContainer = styled(Box)`
  .body {
    margin-top: 8px;

    ${StepLabel} {
      max-width: unset;
      @media ${({ theme }) => theme.breakpoints.mobile} {
        display: block;
        max-width: 117px;
      }
    }
  }
`;
