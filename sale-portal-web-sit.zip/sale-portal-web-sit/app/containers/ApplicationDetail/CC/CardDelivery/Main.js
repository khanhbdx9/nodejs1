import ApplicationStep from "@components/ApplicationStep";
import { BodyDetailContainer } from "@containers/ApplicationDetail/styles";
import { get } from "lodash";
import PropTypes from "prop-types";
import { useMemo } from 'react'

import DeliveryDetail from "./components/DeliveryDetail";
import ReceiveAddress from "./components/ReceiveAddress";
import SignUpInfo from "./components/SignUpInfo";
import VPBankOnlineInfo from "./components/VPBankOnlineInfo";
import { CARD_STATUS } from './store/constants'

const Main = ({ detail }) => {
  const { 
    isVPO,
    vpoAccount,
    cardStatus,
    shippingUnit,
    urlCardImage,
    shippingCode,
    vpoServicePackage,
  } = detail || {};

  const stepDeliveryCard = useMemo(()=> {
    return CARD_STATUS[cardStatus] || 0
  }, [cardStatus])

  return (
    <BodyDetailContainer>
      <ApplicationStep currentStep={6} />
      
      <SignUpInfo
        urlCardImage={urlCardImage}
        isVPO={isVPO}
      />
      
      <VPBankOnlineInfo
        account={vpoAccount}
        servicePackage={vpoServicePackage}
      />
      
      <DeliveryDetail
        shippingUnit={shippingUnit}
        shippingCode={shippingCode}
        stepDeliveryCard={stepDeliveryCard}
      />
      
      <ReceiveAddress
        branch={get(detail, "branchName", "")}
        addressDetail={get(detail, "branchDetail", "")}
      />
    </BodyDetailContainer>
  );
};

Main.propTypes = {
  detail: PropTypes.shape({
    id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    appId: PropTypes.string,
    fullName: PropTypes.string,
    nationalId: PropTypes.string,
    expiryDateFormat: PropTypes.string,
    dateOfBirthFormat: PropTypes.string,
    phoneNumber: PropTypes.string,
    primaryProductName: PropTypes.string,
    additionalProductText: PropTypes.string,
    createdAtFormat: PropTypes.string,
    saleFullName: PropTypes.string,
    salePhoneNumber: PropTypes.string,
    customerConfirmRegister: PropTypes.oneOfType([
      PropTypes.bool,
      PropTypes.oneOf([null]),
    ]),
  }),
};

export default Main;
