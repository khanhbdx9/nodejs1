import styled from 'styled-components';

const CardBeingIssuedContainer = styled.div`
  padding: 24px;

  .__cardContainer {
    margin-top: 24px;

    .header {
      padding-bottom: 16px;
    }
    .body {
      .MuiListItemText-root {
        border-top: 1px solid #CAD3DA4D;
      }
    }

    .__cardContainer___respectfully {
      display: none;
    }
  }
`;

export { CardBeingIssuedContainer }
