import { IMGSuccessApp } from '@assets/images'
import ApplicationStep from "@components/ApplicationStep";
import SalesSupportCard from '@components/SalesSupportCard';
import PropTypes from 'prop-types';

import { CardBeingIssuedContainer } from './Styled';

const Main = ({ 
  detail
}) => {
  const { saleFullName, salePhoneNumber } = detail;

  return (
    <CardBeingIssuedContainer>
      <ApplicationStep currentStep={5}/>

      <SalesSupportCard
        titleSaleBox="Nhân viên hỗ trợ"
        title="Hoàn thành đăng ký"
        desc="Hồ sơ của bạn đang được xử lý. Ngân hàng sẽ thông báo đến bạn trong thời gian sớm nhất"
        image={IMGSuccessApp}
        saleFullName={saleFullName}
        salePhoneNumber={salePhoneNumber}
      />
    </CardBeingIssuedContainer>
  );
};

Main.propTypes = {
  detail: PropTypes.shape({
    saleFullName: PropTypes.string,
    salePhoneNumber: PropTypes.string,
  }),
};

export default Main;
