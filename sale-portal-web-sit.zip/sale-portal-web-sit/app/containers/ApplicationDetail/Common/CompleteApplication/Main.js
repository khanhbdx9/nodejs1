import ApplicationStep from "@components/ApplicationStep";
import { BodyDetailContainer } from "@containers/ApplicationDetail/styles";
import PropTypes from "prop-types";

import ViewDetail from "./components/ViewDetail";
import useLogic from "./hook";

const Main = ({ detail, applicationSteps }) => {
  const { listDocument, typeDocument } = useLogic();

  return (
    <BodyDetailContainer>
      <ApplicationStep currentStep={2} steps={applicationSteps} />
      
      <ViewDetail
        detail={detail}
        listDocument={listDocument}
        typeDocument={typeDocument}
      />
    </BodyDetailContainer>
  );
};

Main.propTypes = {
  detail: PropTypes.shape({
    id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    appId: PropTypes.string,
    fullName: PropTypes.string,
    nationalId: PropTypes.string,
    expiryDateFormat: PropTypes.string,
    dateOfBirthFormat: PropTypes.string,
    phoneNumber: PropTypes.string,
    primaryProductName: PropTypes.string,
    additionalProductText: PropTypes.string,
    createdAtFormat: PropTypes.string,
    saleFullName: PropTypes.string,
    salePhoneNumber: PropTypes.string,
    customerConfirmRegister: PropTypes.oneOfType([
      PropTypes.bool,
      PropTypes.oneOf([null]),
    ]),
  }),
  applicationSteps: PropTypes.array,
};

export default Main;
