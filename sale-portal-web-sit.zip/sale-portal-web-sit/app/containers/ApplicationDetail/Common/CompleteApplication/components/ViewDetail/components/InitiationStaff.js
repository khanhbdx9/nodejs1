import { ListItemDetail, GroupBox } from "@components/Detail";

import PropTypes from "prop-types";

const InitiationStaff = ({ saleFullName = "", salePhoneNumber = "" }) => {
  return (
    <GroupBox title="Nhân viên hỗ trợ">
      <ListItemDetail primary="Họ & tên nhân viên" secondary={saleFullName} hideBorder/>
      <ListItemDetail
        enableCopy
        primary="Số điện thoại"
        secondary={salePhoneNumber}
      />
    </GroupBox>
  );
};

InitiationStaff.propTypes = {
  saleFullName: PropTypes.string,
  salePhoneNumber: PropTypes.string,
};

export default InitiationStaff;
