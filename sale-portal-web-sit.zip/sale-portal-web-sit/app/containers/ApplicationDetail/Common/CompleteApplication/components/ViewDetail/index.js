import AppButton from "@components/AppButton";
import { Notifications, AppButtonFixed } from "@components/Detail";
import { BodyDetailContainer } from "@containers/ApplicationDetail/styles";
import { redirectListApplication } from "@utils/redirect";
import getLd from "lodash/get";
import PropTypes from "prop-types";

import DocumentView from "./components/DocumentView";
import InitiationStaff from "./components/InitiationStaff";
import JobInformation from "./components/JobInformation";
import LoanInfo from "./components/LoanInfo";
import ProfileInformation from "./components/ProfileInformation";

function ViewDetail({ detail, listDocument, typeDocument }) {
  return (
    <BodyDetailContainer sx={{ padding: "0px" }}>
      <Notifications
        type="alert"
        title={"Hồ sơ đang được thu thập thông tin bởi nhân viên VPBank."}
      />

      <InitiationStaff
        saleFullName={getLd(detail, "saleFullName") || ""}
        salePhoneNumber={getLd(detail, "salePhoneNumber") || ""}
      />

      <LoanInfo
        cardName={getLd(detail, "cardName") || ""}
        primaryProductIcon={getLd(detail, "primaryProductIcon")}
        primaryProductName={getLd(detail, "primaryProductName")}
        limit={getLd(detail, "requestLimit") || ""}
        interest={getLd(detail, "interest") || ""}
        productType={getLd(detail, "productType") || ""}
      />

      <ProfileInformation
        fullName={getLd(detail, "fullName") || ""}
        phoneNumber={getLd(detail, "phoneNumber") || ""}
        nationalId={getLd(detail, "nationalId") || ""}
        oldNationalId={getLd(detail, "nationalId") || ""}
        dateOfBirth={getLd(detail, "dateOfBirth")}
        currentAddress={getLd(detail, "currentAddress") || ""}
        permanentAddress={getLd(detail, "permanentAddress") || ""}
      />

      <JobInformation
        companyName={getLd(detail, "companyName")}
        companyAddress={getLd(detail, "companyAddress") || ""}
        taxCode={getLd(detail, "taxCode") || ""}
        monthlyIncome={getLd(detail, "income") || 0}
      />

      <DocumentView listDocument={listDocument} typeDocument={typeDocument} />

      <AppButtonFixed>
        <AppButton
          sx={{ width: "100%" }}
          label="Danh sách hồ sơ"
          variant="outlined"
          onClick={redirectListApplication}
        />
      </AppButtonFixed>
    </BodyDetailContainer>
  );
}

ViewDetail.propTypes = {
  detail: PropTypes.object,
  listDocument: PropTypes.object,
  typeDocument: PropTypes.array,
};

export default ViewDetail;
