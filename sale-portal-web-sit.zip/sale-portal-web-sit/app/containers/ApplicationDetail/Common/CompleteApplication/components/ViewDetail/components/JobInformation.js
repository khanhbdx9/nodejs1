import { ListItemDetail, CollapseBox } from "@components/Detail";
import { formatNumber } from "@utils/helpers";

import PropTypes from "prop-types";

const JobInformation = ({
  companyName = "",
  companyAddress = "",
  taxCode = "",
  monthlyIncome = 0,
}) => {
  return (
    <CollapseBox title="Thông tin công việc">
      <ListItemDetail
        hideBorder
        primary="Tên công ty"
        secondary={companyName}
      />
      <ListItemDetail primary="Địa chỉ công ty" secondary={companyAddress} />
      <ListItemDetail primary="Mã số thuế" secondary={taxCode} />
      <ListItemDetail
        primary="Thu nhập hàng tháng của bạn"
        secondary={formatNumber(monthlyIncome)}
      />
    </CollapseBox>
  );
};

JobInformation.propTypes = {
  companyName: PropTypes.string,
  companyAddress: PropTypes.string,
  taxCode: PropTypes.string,
  monthlyIncome: PropTypes.number,
};

export default JobInformation;
