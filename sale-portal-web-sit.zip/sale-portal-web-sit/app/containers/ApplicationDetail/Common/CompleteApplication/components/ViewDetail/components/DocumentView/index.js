import { CollapseBox } from "@components/Detail";
import Title from "@components/Styled/Title";
import Box from "@mui/material/Box";
import get from "lodash/get";
import isArray from "lodash/isArray";
import size from "lodash/size";
import PropTypes from "prop-types";
import { Fragment } from "react";

import ItemPreview from "./ItemPreview";
import { DocumentContainer } from "../../../../Styled";

const DocumentView = ({ listDocument, typeDocument }) => {
  return (
    <CollapseBox title="Tài liệu, chứng từ">
      <DocumentContainer>
        {isArray(typeDocument) &&
          typeDocument.map((docType) => {
            if (!size(get(listDocument, docType.code_cms))) {
              return;
            }
            return (
              <Box className="documentGroup" key={docType.code_cms}>
                <Box className="headerGroup">
                  <Title>{docType.document_type_name}</Title>
                  {/* <Text $size={14} $weight={400} $color="neutral">
                    Ảnh hộ khẩu, ảnh...
                  </Text> */}
                </Box>
                <Box className="itemList">
                  {isArray(get(listDocument, docType.code_cms, [])) &&
                    get(listDocument, docType.code_cms, []).map((doc) => {
                      return (
                        <Fragment key={doc.url_download}>
                          <ItemPreview
                            src={doc.url_download}
                            alt={doc.doc_name}
                            isPdf={String(doc.doc_name).endsWith(".pdf")}
                            folderName={doc.folder_name}
                            fileName={doc.doc_name}
                          />
                        </Fragment>
                      );
                    })}
                </Box>
              </Box>
            );
          })}
      </DocumentContainer>
    </CollapseBox>
  );
};

DocumentView.propTypes = {
  listDocument: PropTypes.object,
  typeDocument: PropTypes.array,
};

export default DocumentView;
