import { IcPdf } from "@assets/icons";
import AppImage from "@components/AppImage";
import Box from "@mui/material/Box";
import { ROOT_URI } from "@utils/constants";
import { openExternalLink } from "@utils/helpers";
import { URL as ApiUrl } from "@utils/services/api";
import PropTypes from "prop-types";
import { memo } from "react";

function ItemPreview({ src, alt = "Preview", isPdf, folderName, fileName }) {
  const urlView = `${ROOT_URI}/${ApiUrl.gateway.getFile}?folderName=${folderName}&fileName=${fileName}&isThumb=true`;
  return (
    <Box
      className="item"
      onClick={() => {
        isPdf ? openExternalLink(src) : {};
      }}
    >
      {!isPdf ? (
        <AppImage src={urlView} alt={alt} width={56} height={56} />
      ) : (
        <img src={IcPdf} alt={alt} />
      )}
    </Box>
  );
}

ItemPreview.propTypes = {
  thumbnail: PropTypes.string,
  src: PropTypes.string,
  folderName: PropTypes.string,
  fileName: PropTypes.string,
  alt: PropTypes.string,
  isPdf: PropTypes.bool,
};

export default memo(ItemPreview);
