import { DateFormat1 } from "@utils/constants";
import moment from "moment";
import PropTypes from "prop-types";
import { ListItemDetail, CollapseBox } from "@components/Detail";

const ProfileInformation = ({
  fullName = "",
  phoneNumber = "",
  nationalId = "",
  oldNationalId = "",
  dateOfBirth = "",
  permanentAddress = "",
  currentAddress = "",
}) => {
  const dateOfBirthFormat = dateOfBirth
    ? moment(dateOfBirth).format(DateFormat1)
    : "";

  return (
    <CollapseBox title="Thông tin của bạn">
      <ListItemDetail secondary={fullName} primary="Họ & tên KH" />
      <ListItemDetail primary="Số điện thoại" secondary={phoneNumber} />
      <ListItemDetail secondary={nationalId} primary="CCCD chính" />
      <ListItemDetail secondary={oldNationalId} primary="CCCD cũ" />
      <ListItemDetail secondary={dateOfBirthFormat} primary="Năm sinh" />
      <ListItemDetail
        secondary={permanentAddress}
        primary="Địa chỉ thưởng trú"
      />
      <ListItemDetail secondary={currentAddress} primary="Địa chỉ hiện tại" />
    </CollapseBox>
  );
};

ProfileInformation.propTypes = {
  fullName: PropTypes.string,
  phoneNumber: PropTypes.string,
  nationalId: PropTypes.string,
  oldNationalId: PropTypes.string,
  dateOfBirth: PropTypes.string,
  permanentAddress: PropTypes.string,
  currentAddress: PropTypes.string,
};

export default ProfileInformation;
