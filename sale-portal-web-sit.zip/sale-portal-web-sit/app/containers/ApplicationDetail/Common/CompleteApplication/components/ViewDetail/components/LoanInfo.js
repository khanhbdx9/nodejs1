import AppImage from "@components/AppImage";
import { ListItemDetail, CollapseBox } from "@components/Detail";
import Title from "@components/Styled/Title";
import Typography from "@mui/material/Typography";
import Box from "@mui/system/Box";
import { formatNumber } from "@utils/helpers";
import PropTypes from "prop-types";
import { useMemo, Fragment } from "react";

import { LoanCardContainer } from "../../../Styled";

const MAPPING_LOAN_INFO = {
  CC: {
    title: "Thông tin sản phẩm",
    contents: [
      {
        render: ({ primaryProductIcon, primaryProductName, cardName }) => (
          <LoanCardContainer>
            <Box className="cardImage">
              <AppImage
                src={primaryProductIcon}
                height={95}
                width={60}
                className="urlCardImage"
                isOrientation
              />
            </Box>
            <Box className="cardName">
              <Typography>{primaryProductName}</Typography>
              <Title $weight={600}>{cardName}</Title>
            </Box>
          </LoanCardContainer>
        ),
      },
      {
        label: "Sản phẩm",
        field: "primaryProductName",
      },
      {
        label: "Hạn mức đề nghị",
        field: "limit",
        render: val => val ? `${formatNumber(val)} VNĐ` : '',
      },
    ],
  },
  UPL: {
    title: "Thông tin sản phẩm",
    contents: [
      {
        label: "Sản phẩm vay",
        field: "primaryProductName",
      },
      {
        label: "Hạn mức đề nghị",
        field: "limit",
        render: val => val ? `${formatNumber(val)} VNĐ` : '',
      },
      {
        label: "Lãi suất",
        field: "interest",
        render: val => val ? `${val}%/năm` : ''
      },
    ],
  },
  OD: {
    title: "Thông tin sản phẩm",
    contents: [
      {
        label: "Sản phẩm vay",
        field: "primaryProductName",
      },
      {
        label: "Hạn mức đề nghị",
        field: "limit",
        render: val => val ? `${formatNumber(val)} VNĐ` : '',
      },
      {
        label: "Lãi suất",
        field: "interest",
        render: val => val ? `${val}%/năm` : ''
      },
    ],
  },
};

const LoanInfo = (details) => {
  
  const dataRender = useMemo(() => {
    return MAPPING_LOAN_INFO[details?.productType] || null;
  }, [details?.productType]);

  if (!dataRender) return null;

  return (
    <CollapseBox title={dataRender.title}>
      {dataRender.contents.map((item, index) => {
        if(!item.label && !item.field && item.render){
          return (
            <Fragment key={`LOAN-INFO-${index}`}>
              {item.render(details)}
            </Fragment>
          );
        }

        const value = item.render
          ? item.render(details[item.field])
          : details[item.field] || "";

        return (
          <ListItemDetail
            key={`LOAN-INFO-${index}`}
            primary={item.label}
            secondary={value}
          />
        );
      })}
    </CollapseBox>
  );
};

LoanInfo.propTypes = {
  productType: PropTypes.string,
  primaryProductIcon: PropTypes.string,
  primaryProductName: PropTypes.string,
  cardName: PropTypes.string,
  limit: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  interest: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};

export default LoanInfo;
