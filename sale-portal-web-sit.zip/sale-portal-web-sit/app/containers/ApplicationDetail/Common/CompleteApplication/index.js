import LoadingIndicator from '@components/LoadingIndicator';
import loadable from '@utils/loadable';
import PropTypes from 'prop-types';

import KEY from '@utils/injectKey'
import { useInjectReducer } from '@utils/injectReducer';
import { useInjectSaga } from '@utils/injectSaga';
import reducer from './store/reducer';
import saga from './store/saga';

const Provider = ({ children }) => {
  useInjectReducer({ key: KEY.COMPLETE_APPLICATION, reducer });
  useInjectSaga({ key: KEY.COMPLETE_APPLICATION, saga });
  return <>{children}</>;
};

Provider.propTypes = {
  children: PropTypes.node.isRequired,
};

const CompleteApplication = loadable(() => import('./Main'), {
  fallback: <LoadingIndicator />,
  provider: Provider,
});

export default CompleteApplication;
