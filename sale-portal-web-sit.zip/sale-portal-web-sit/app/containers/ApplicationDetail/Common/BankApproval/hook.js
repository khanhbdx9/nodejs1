import useShallowEqualSelector from "@utils/hooks/useShallowEqualSelector";
import KEY from "@utils/injectKey";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { useParams } from "react-router-dom";
import { getListDocumentAction, getTypeDocumentAction } from "./store/actions";

const useLogic = () => {
  const dispatch = useDispatch();
  const { id } = useParams();

  const { listDocument = [], typeDocument = [] } = useShallowEqualSelector(
    KEY.BANK_APPROVAL,
    ["listDocument", "typeDocument"]
  );

  useEffect(() => {
    if (id) {
      setTimeout(() => {
        dispatch(getTypeDocumentAction(id));
        dispatch(getListDocumentAction(id));
      }, 100);
    }
  }, [id]);

  return {
    listDocument,
    typeDocument,
  };
};

export default useLogic;
