import IconButton from "@mui/material/IconButton";
import Box from "@mui/material/Box";
import styled from "styled-components";

export const LoanCardContainer = styled(Box)`
  margin-top: 16px;
  display: flex;
  gap: 16px;
  background-color: white;
  padding: 16px;
  border-radius: 8px;
  align-items: center;
  .cardImage {
    width: 60px;
    height: 95px;
  }
`;

export const DocumentContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  margin: 16px 0px;
  .documentGroup {
    background-color: white;
    display: flex;
    flex-direction: column;
    border-radius: 8px;
    padding: 16px 16px 0px;

    .itemList {
      display: flex;
      gap: 16px;
      overflow: auto;
      width: 100%;
      padding: 16px 0px;
      .item {
        cursor: pointer;
        background-color: ${(p) => p.theme.colors.shade1};
        width: 58px;
        height: 58px;
        display: flex;
        flex-shrink: 0;
        align-items: center;
        justify-content: center;
        border: 1px solid ${(p) => p.theme.colors.shade0};
        border-style: dashed;
        border-radius: 8px;
      }
    }

    .header {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
    }
    .action {
      padding-left: 30px;
      height: 40px;
      border-top: 1px solid ${(p) => p.theme.colors.shade0};
      display: flex;
      align-items: center;
      gap: 24px;
      .uploadBtn {
        gap: 8px;
        cursor: pointer;
        padding: 8px 0px;
        display: flex;
        align-items: center;
      }
    }
  }

  .footer {
    display: flex;
    justify-content: flex-end;
    gap: 16px;
    button {
      min-width: 127px;
      @media ${(p) => p.theme.breakpoints.tablet} {
        flex: 1;
      }
    }
  }
`;

export const StyledDocumentPreview = styled(Box)(() => ({
  position: "relative",
  borderRadius: 8,
}));

export const PreviewImage = styled("img")({
  width: 58,
  height: 58,
  objectFit: "cover",
});

export const PreviewPdfIcon = styled(Box)({
  width: 58,
  height: 58,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  backgroundColor: "#f4f4f4",
});

export const CloseButton = styled(IconButton)(({ theme }) => ({
  position: "absolute !important",
  top: -12,
  right: -12,
  backgroundColor: theme.palette.background.paper,
  "&:hover": {
    backgroundColor: theme.palette.grey[300],
  },
}));
