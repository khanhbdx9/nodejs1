import ApplicationStep from "@components/ApplicationStep";
import ViewDetail from "@containers/ApplicationDetail/Common/CompleteApplication/components/ViewDetail";
import { BodyDetailContainer } from "@containers/ApplicationDetail/styles";
import PropTypes from "prop-types";

import useLogic from "./hook";

const Main = ({ detail, applicationSteps }) => {
  const { listDocument, typeDocument } = useLogic();

  return (
    <BodyDetailContainer>
      <ApplicationStep currentStep={3} steps={applicationSteps} />

      {/* 
        30/09/2025: Tại thời điểm hiện tại 2 step này giống nhau mọi thứ, 
        nếu tương lai thay đổi thì phải trỏ lại component internal 
        để code không code chung nhau 
      */}
      <ViewDetail
        detail={detail}
        listDocument={listDocument}
        typeDocument={typeDocument}
      />
    </BodyDetailContainer>
  );
};

Main.propTypes = {
  detail: PropTypes.shape({
    id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    appId: PropTypes.string,
    fullName: PropTypes.string,
    nationalId: PropTypes.string,
    expiryDateFormat: PropTypes.string,
    dateOfBirthFormat: PropTypes.string,
    phoneNumber: PropTypes.string,
    primaryProductName: PropTypes.string,
    additionalProductText: PropTypes.string,
    createdAtFormat: PropTypes.string,
    saleFullName: PropTypes.string,
    salePhoneNumber: PropTypes.string,
    customerConfirmRegister: PropTypes.oneOfType([
      PropTypes.bool,
      PropTypes.oneOf([null]),
    ]),
  }),
  applicationSteps: PropTypes.shape({
    label: PropTypes.string,
  })
};

export default Main;
