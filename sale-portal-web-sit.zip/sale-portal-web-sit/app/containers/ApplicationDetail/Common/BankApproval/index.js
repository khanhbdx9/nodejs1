import LoadingIndicator from '@components/LoadingIndicator';
import loadable from '@utils/loadable';
import PropTypes from 'prop-types';
import { Fragment } from 'react'

import KEY from '@utils/injectKey'
import { useInjectReducer } from '@utils/injectReducer';
import { useInjectSaga } from '@utils/injectSaga';
import reducer from './store/reducer';
import saga from './store/saga';

const Provider = ({ children }) => {
  useInjectReducer({ key: KEY.BANK_APPROVAL, reducer });
  useInjectSaga({ key: KEY.BANK_APPROVAL, saga });
  return <Fragment>{children}</Fragment>;
};

Provider.propTypes = {
  children: PropTypes.node.isRequired,
};

const BankApproval = loadable(() => import('./Main'), {
  fallback: <LoadingIndicator />,
  provider: Provider,
});

export default BankApproval;
