import { produce } from "immer";
import { getListDocumentAction, getTypeDocumentAction } from "./actions";
import get from "lodash/get";

export const initialState = {
  listDocument: {},
  typeDocument: [],
};

const EContractReducer = (state = initialState, action) =>
  produce(state, (draft) => {
    switch (action.type) {
      case getListDocumentAction.REQUEST: {
        draft.listDocument = {};
        break;
      }

      case getListDocumentAction.SUCCESS: {
        draft.listDocument = (get(action.payload, "items", []) || []).reduce(
          (acc, curr) => {
            acc[curr.type] = [...(acc[curr.type] || []), curr];
            return acc;
          },
          {}
        );
        break;
      }

      case getListDocumentAction.FAILURE: {
        draft.listDocument = {};
        break;
      }

      case getTypeDocumentAction.REQUEST: {
        draft.typeDocument = [];
        break;
      }

      case getTypeDocumentAction.SUCCESS: {
        draft.typeDocument = action?.payload.items || [];
        break;
      }

      case getTypeDocumentAction.FAILURE: {
        draft.typeDocument = [];
        break;
      }
    }
  });

export default EContractReducer;
