import { setLoadingAction } from "@App/actions";
import { responseCode } from "@utils/constants";
import { MESSAGE_SYSTEM } from "@utils/message";
import { toast } from "react-toastify";
import { all, call, put as dispatch, takeLatest } from "redux-saga/effects";
import { URL, apiRequest } from "@utils/services/api";
import { getListDocumentAction, getTypeDocumentAction } from "./actions";
import get from "lodash/get";

function* getListDocumentSaga({ payload }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(getListDocumentAction.request());

    const request = {
      url: URL.unsecure.getListDocument,
      params: { feAppId: payload },
    };

    const respond = yield call(apiRequest.get, request);
    const { data, meta } = get(respond, "data") || {};
    if (get(meta, "code") === responseCode["IL-200"] && data) {
      yield dispatch(getListDocumentAction.success({ items: data }));
    } else {
      throw {};
    }
  } catch (error) {
    yield dispatch(getListDocumentAction.failure());
    toast.error(get(error, "meta.message", MESSAGE_SYSTEM.documentNotFound));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

function* getTypeDocumentSaga({ payload }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(getTypeDocumentAction.request());

    const request = {
      url: URL.unsecure.getTypeDocument(payload),
      params: { isCus: false },
    };

    const respond = yield call(apiRequest.get, request);
    const { data, meta } = get(respond, "data") || {};
    if (get(meta, "code") === responseCode["IL-200"] && data) {
      yield dispatch(getTypeDocumentAction.success({ items: data }));
    } else {
      throw {};
    }
  } catch (error) {
    yield dispatch(getTypeDocumentAction.failure());
    toast.error(get(error, "meta.message", MESSAGE_SYSTEM.documentNotFound));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export default function* watchAll() {
  yield all([takeLatest(getListDocumentAction.TRIGGER, getListDocumentSaga)]);
  yield all([takeLatest(getTypeDocumentAction.TRIGGER, getTypeDocumentSaga)]);
}
