import { createRoutine } from "redux-saga-routines";

import {
  GET_LIST_DOCUMENT_ACTION,
  GET_TYPE_DOCUMENT_ACTION,
} from "./constants";

export const getListDocumentAction = createRoutine(GET_LIST_DOCUMENT_ACTION);
export const getTypeDocumentAction = createRoutine(GET_TYPE_DOCUMENT_ACTION);
