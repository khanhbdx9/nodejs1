import { setLoadingAction } from '@App/actions';
import { responseCode } from '@utils/constants';
import { TOKEN_KEY, SUCCESS } from "@utils/constants";
import { MESSAGE_SYSTEM } from '@utils/message';
import { URL, apiRequest } from "@utils/services/api";
import SessionStorageService from "@utils/storage/session";
import getLd from 'lodash/get';
import { toast } from 'react-toastify';
import { all, call, put as dispatch, takeLatest } from 'redux-saga/effects';

import { 
  verifyOtpAction, 
  resendOtpAction,
  cancelInitAppAction,
  setLayoutInitAppAction,
  requestConfirmInitAppAction, 
} from './actions';
import { INIT_APP_LAYOUT } from './constants';

function* requestConfirmInitAppSaga(action) {
  try {
    if(!action?.payload?.id){
      toast.error(MESSAGE_SYSTEM.notFindAppId);
      return;
    }

    yield dispatch(setLoadingAction(true));
    yield dispatch(requestConfirmInitAppAction.request());

    const payload = {
      url: URL.unsecure.requestConfirmInitApp(action?.payload?.id),
    };

    const { data: res = {} } = yield call(apiRequest.post, payload);
    const { data = {}, meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        if(data?.status === 200){
          SessionStorageService.setItem(TOKEN_KEY, data?.signature);
          
          toast.success(data?.message || '');
          
          yield dispatch(setLayoutInitAppAction(INIT_APP_LAYOUT.CONFIRM_INIT_APP));
          return;
        }

        toast.error('Gửi mã OTP không thành công. Vui lòng thử lại!');
        break;
      }
      default: {
        toast.error(getLd(meta, 'message', MESSAGE_SYSTEM.error_02));
        break;
      }
    }
  } catch (error) {
    toast.error(getLd(error, 'meta.message', MESSAGE_SYSTEM.default));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

function* verifyOtpInitSaga({ payload }) {
  try {
    const request = {
      url: URL.unsecure.otpConfirmAppInit(payload?.id),
      data: payload?.data,
    };
    
    yield dispatch(setLoadingAction(true));
    yield dispatch(verifyOtpAction.request());

    const { data: res = {} } = yield call(apiRequest.post, request);
    const { data = {}, meta = {} } = res;

    switch (meta?.code) {
      case responseCode["IL-200"]: {
        if(data?.status === 200 && data?.message === SUCCESS){
          yield dispatch(verifyOtpAction.success());

          yield dispatch(setLayoutInitAppAction(INIT_APP_LAYOUT.APPLICATION_INFO));
          break;
        }

        yield dispatch(verifyOtpAction.failure({
          message: data?.message || meta?.message
        }));
        break;
      }
      default: {
        yield dispatch(verifyOtpAction.failure(meta));
        break;
      }
    }
  } catch (error) {
    yield dispatch(verifyOtpAction.failure(error?.meta));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

function* resendOtpInitSaga() {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(resendOtpAction.request());

    const request = {
      url: URL.unsecure.resendConfirmInitApp,
    };

    const { data: res = {} } = yield call(apiRequest.get, request);
    const { data = {}, meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        if(data?.signature){
          yield dispatch( resendOtpAction.success());

          SessionStorageService.setItem(TOKEN_KEY, data.signature);
          toast.success(data?.message);
          break;
        }
        
        yield dispatch(resendOtpAction.failure({
          message: data?.message || meta?.message || MESSAGE_SYSTEM?.notToken
        }));
        break;
      }
      default: {
        yield dispatch(resendOtpAction.failure(meta));
        break;
      }
    }
  } catch (error) {
    yield dispatch(resendOtpAction.failure(error?.meta));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

function* cancelInitAppSaga({ payload }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(cancelInitAppAction.request());

    const request = {
      url: URL.unsecure.cancelCustByCustomer,
      params: payload,
    };

    const { data: res = {} } = yield call(apiRequest.post, request);
    const { data = {}, meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        if(data?.message === SUCCESS){
          yield dispatch(cancelInitAppAction.success());
          return
        }
        
        toast.error(data?.message || meta?.message);
        break;
      }
      default: {
        toast.error(data?.message || meta?.message);
        break;
      }
    }
  } catch (error) {
    toast.error(error?.meta?.message || '');
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export default function* watchAll() {
  yield all([
    takeLatest(verifyOtpAction.TRIGGER, verifyOtpInitSaga),
    takeLatest(resendOtpAction.TRIGGER, resendOtpInitSaga),
    takeLatest(cancelInitAppAction.TRIGGER, cancelInitAppSaga),
    takeLatest(requestConfirmInitAppAction.TRIGGER, requestConfirmInitAppSaga),
  ]);
}
