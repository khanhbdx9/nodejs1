import { produce } from 'immer';

import { resendOtpAction, verifyOtpAction, cancelInitAppAction } from './actions';
import { 
  INIT_APP_LAYOUT,
  RESET_INIT_APP_ACTION,
  SET_LAYOUT_INIT_APP_ACTION,
  SET_FIELD_VALUE_INIT_APP_ACTION,
} from './constants';

export const initialState = {
  currentLayoutInitApp: INIT_APP_LAYOUT.APPLICATION_INFO,

  isModalConsent: false,
  isModalCloseApp: false,
  isModalCancelApp: false,
  isModalSuccessApp: false,

  msgError: "",
};

const InitApplicationReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      // --------------- ACTION NORMAL -----------------
      case SET_LAYOUT_INIT_APP_ACTION: {
        draft.currentLayoutInitApp = action?.payload;
        break;
      }
      case SET_FIELD_VALUE_INIT_APP_ACTION: {
        draft[action.payload.key] = action.payload.value;
        break;
      }
      case RESET_INIT_APP_ACTION: {
        return initialState;
      }
      
      // --------------- SAGA -----------------
      case resendOtpAction.REQUEST: {
        draft.msgError = "";
        break;
      }
      case resendOtpAction.SUCCESS: {
        draft.msgError = "";
        break;
      }
      case resendOtpAction.FAILURE: {
        draft.msgError = action.payload?.message || '';
        break;
      }

      case verifyOtpAction.REQUEST: {
        draft.msgError = "";
        break;
      }
      case verifyOtpAction.SUCCESS: {
        draft.msgError = "";
        draft.isModalSuccessApp = true;
        break;
      }
      case verifyOtpAction.FAILURE: {
        draft.msgError = action.payload?.message || '';
        break;
      }

      case cancelInitAppAction.REQUEST: {
        break;
      }
      case cancelInitAppAction.SUCCESS: {
        draft.isModalCancelApp = true;
        break;
      }
      case cancelInitAppAction.FAILURE: {
        break;
      }
      
    }
  });

export default InitApplicationReducer;
