import { createRoutine } from 'redux-saga-routines';

import * as KEY_CONSTANT from './constants';

export const setLayoutInitAppAction = payload => ({
  type: KEY_CONSTANT.SET_LAYOUT_INIT_APP_ACTION,
  payload,
})

export const setFieldValueInitAppAction = (key, value) => ({
  type: KEY_CONSTANT.SET_FIELD_VALUE_INIT_APP_ACTION,
  payload: { key, value },
})

export const resetInitAppAction = () => ({
  type: KEY_CONSTANT.RESET_INIT_APP_ACTION,
})

export const requestConfirmInitAppAction = createRoutine(KEY_CONSTANT.REQUEST_CONFIRM_INIT_APP_ACTION);

export const verifyOtpAction = createRoutine(KEY_CONSTANT.VERIFY_OTP_ACTION);

export const resendOtpAction = createRoutine(KEY_CONSTANT.RESEND_OTP_ACTION);

export const cancelInitAppAction = createRoutine(KEY_CONSTANT.CANCEL_INIT_APP_ACTION);
