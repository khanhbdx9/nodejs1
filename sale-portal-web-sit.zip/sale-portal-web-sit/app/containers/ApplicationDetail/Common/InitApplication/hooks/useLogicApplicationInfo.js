import { useDispatchRedux } from "@utils/hooks/useRedux";
import { useEffect } from 'react';

import {
  cancelInitAppAction,
  requestConfirmInitAppAction, 
  setFieldValueInitAppAction
} from '../store/actions';
import { STATUS_INIT } from '../store/constants';

const useLogicApplicationInfo = (id, screen) => {
  const isDisabled = !id;
  const isFooter = [STATUS_INIT.WAITING_INIT].includes(screen);

  const setFieldValueInitAppRedux = useDispatchRedux(setFieldValueInitAppAction)
  const rqConfirmInitApp = useDispatchRedux(requestConfirmInitAppAction)
  const rqCancelInitApp = useDispatchRedux(cancelInitAppAction)

  const toggleModalConsent = (value) => {
    return setFieldValueInitAppRedux('isModalConsent', value)
  }

  const toggleModalCloseApp = (value) => {
    return setFieldValueInitAppRedux('isModalCloseApp', value)
  }

  const handleOpenModalSuccess = () => {
    return setFieldValueInitAppRedux('isModalSuccessApp', true)
  }

  const handleOpenModalCancelApp = () => {
    return setFieldValueInitAppRedux('isModalCancelApp', true)
  }

  const handleRqConfirmInitApp = () => {
    toggleModalConsent(false)
    return rqConfirmInitApp({ id })
  }

  const handleRqCancelInitApp = () => {
    toggleModalCloseApp(false);

    return rqCancelInitApp({ appId: id })
  }

  useEffect(()=>{
    switch(screen) {
      case STATUS_INIT.REJECT_INIT: {
        handleOpenModalCancelApp();
        break;
      }
      case STATUS_INIT.SUCCESS_INIT: {
        handleOpenModalSuccess();
        break;
      }
      default: break;
    }
  }, [screen])

  return {
    isFooter,
    isDisabled,
    toggleModalConsent,
    toggleModalCloseApp,
    handleRqCancelInitApp,
    handleRqConfirmInitApp,
  }
}

export default useLogicApplicationInfo;