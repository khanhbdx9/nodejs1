import { useOneState, useDispatchRedux } from "@utils/hooks/useRedux";
import KEYS from "@utils/injectKey";

import { verifyOtpAction, resendOtpAction } from '../store/actions';

const useLogicConfirmInitApp = (id, phoneNumber) => {
  const message = useOneState(KEYS.INIT_APPLICATION, 'msgError')

  const rqResendOtp = useDispatchRedux(resendOtpAction)
  const rqVerifyOtp = useDispatchRedux(verifyOtpAction)

  const handleVerifyOtp = otpCode => {
    return rqVerifyOtp({ 
      id,
      data: { otpCode,  phoneNumber }
    })
  }

  return {
    message,
    rqResendOtp,
    handleVerifyOtp,
  }
}

export default useLogicConfirmInitApp;