import TabsWithTransition from '@components/TabsWithTransition'
import { useOneState, useDispatchRedux } from "@utils/hooks/useRedux";
import KEYS from "@utils/injectKey";
import PropTypes from "prop-types";
import { useMemo, useEffect } from 'react'

import ApplicationInfo from "./components/ApplicationInfo";
import ConfirmCreateApp from "./components/ConfirmCreateApp";
import { resetInitAppAction } from './store/actions';

const Main = ({ detail, applicationSteps }) => {
  const currentLayoutInitApp = useOneState(KEYS.INIT_APPLICATION, 'currentLayoutInitApp')

  const resetInitAppRedux = useDispatchRedux(resetInitAppAction)

  const tabData = useMemo(()=>{
    return [
      {
        label: 'thông tin hồ sơ',
        props: { detail, applicationSteps },
        content: (props) => <ApplicationInfo {...props} />
      },
      {
        label: 'xác nhận khởi tạo hồ sơ',
        props: { ...detail },
        content: (props) => <ConfirmCreateApp {...props} />
      },
    ]
  }, [detail]);


  useEffect(() => {
    return () => resetInitAppRedux();
  }, []);

  return (
    <TabsWithTransition  
      tabs={tabData} 
      hiddenTabHeader
      activeTab={currentLayoutInitApp}
    />
  );
};

Main.propTypes = {
  detail: PropTypes.shape({
    id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    appId: PropTypes.string,
    fullName: PropTypes.string,
    nationalId: PropTypes.string,
    expiryDateFormat: PropTypes.string,
    dateOfBirthFormat: PropTypes.string,
    phoneNumber: PropTypes.string,
    primaryProductName: PropTypes.string,
    additionalProductText: PropTypes.string,
    createdAtFormat: PropTypes.string,
    saleFullName: PropTypes.string,
    salePhoneNumber: PropTypes.string,
    customerConfirmRegister: PropTypes.oneOfType([
      PropTypes.bool,
      PropTypes.oneOf([null])
    ]),
  }),
  applicationSteps: PropTypes.shape({
    label: PropTypes.string,
  })
};

export default Main;
