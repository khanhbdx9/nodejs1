import AppButton from "@components/AppButton";
import { AppButtonFixed } from "@components/Detail";
import PropTypes from "prop-types";

import { FooterContainer } from "../../Styled";

const Footer = ({ disableBtn, toggleModalCloseApp, toggleModalConsent }) => {
  return (
    <AppButtonFixed>
      <FooterContainer>
        <AppButton
          label="Từ chối"
          variant="text"
          disabled={disableBtn}
          onClick={() => toggleModalCloseApp(true)}
        />

        <AppButton
          disabled={disableBtn}
          label="Xác nhận khởi tạo"
          onClick={() => toggleModalConsent(true)}
        />
      </FooterContainer>
    </AppButtonFixed>
  );
};

Footer.propTypes = {
  disableBtn: PropTypes.bool,
  toggleModalConsent: PropTypes.func.isRequired,
  toggleModalCloseApp: PropTypes.func.isRequired,
};

export default Footer;
