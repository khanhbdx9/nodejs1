import OtpInput from "@components/OtpInput";
import { BodyDetailContainer } from "@containers/ApplicationDetail/styles";
import PropTypes from 'prop-types';

import useLogicConfirmInitApp from '../../hooks/useLogicConfirmInitApp'

const ConfirmCreateApp = ({ 
  id,
  phoneNumber,
}) => {
  const { message, handleVerifyOtp, rqResendOtp } = useLogicConfirmInitApp(id,phoneNumber)

  return (
    <BodyDetailContainer>
      <OtpInput
        errorText={message}
        phoneNumber={phoneNumber}
        onSubmit={handleVerifyOtp}
        onResendOtp={rqResendOtp}
      />
    </BodyDetailContainer>
  )
}

ConfirmCreateApp.propTypes = {
  id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  phoneNumber: PropTypes.string.isRequired,
};

export default ConfirmCreateApp;