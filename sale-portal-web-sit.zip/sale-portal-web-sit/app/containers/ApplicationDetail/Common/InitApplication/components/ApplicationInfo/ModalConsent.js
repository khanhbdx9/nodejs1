import { IcPdfFile } from '@assets/icons';
import AppButton from "@components/AppButton";
import AppImage from '@components/AppImage';
import ModalContainer from "@components/Modal/ModalContainer";
import Title from "@components/Styled/Title";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import Link from '@mui/material/Link';
import VPB_COLOR from '@ThemeProvider/colors';
import { ROOT_URI } from '@utils/constants'
import { isMobile } from '@utils/helpers'
import { openExternalLink } from '@utils/helpers'
import useShallowEqualSelector from '@utils/hooks/useShallowEqualSelector'
import KEY from '@utils/injectKey'
import { URL } from "@utils/services/api";
import PropTypes from 'prop-types';
import { useState, Fragment } from 'react';

import { ModalConsentContainer } from '../../Styled';

const link = `${ROOT_URI}/${URL.unsecure.genConfirmDataPersonal}`

const ModalConsent = ({ 
  toggleModalConsent,
  handleConfirm
}) => {
  const { isModalConsent } = useShallowEqualSelector(KEY.INIT_APPLICATION, ['isModalConsent'])

  const [isConsent, setConsent] = useState(false);

  const handleChangeConsent = (event) => {
    const checked = event.target.checked;

    setConsent(checked)
  }

  return (
    <ModalContainer
      open={isModalConsent} 
      position={isMobile() ? 'bottom' : 'center'}

      handleClose={()=>toggleModalConsent(false)}
    >
      <ModalConsentContainer>
        <Title $weight={600} $size={16}>Kính gửi Quý khách hàng</Title>

        <FormControlLabel
          className='align-start'
          control={
            <Checkbox 
              style={{ marginTop: 3 }}
              checked={isConsent} 
              onChange={handleChangeConsent} 
            />
          }
          label={
            <Fragment>
              Tôi đã đọc và đồng ý với Bản điều kiện giao dịch chung về bảo vệ dữ liệu cá nhân  quy định tại
              {' '}<Link target='_blank' href='https://www.vpbank.com.vn/-/media/vpbank-latest/tai-lieu-bieu-mau/bieu-mau/khcn/dkgd-chung-ve-cung-cap-va-su-dung-dich-vu-phi-tin-dung-ap-dung-doi-voi-khcn-tai-vpbank.pdf'>
                 Điều kiện giao dịch chung về dịch vụ phi tín dụng
              </Link>{' '}
              và đồng ý cho VPBank xử lý dữ liệu của Tôi theo Văn bản xác nhận phía dưới:
            </Fragment>
          }
        />

        <FormControlLabel
          style={{ border: 'unset', padding: 0 }}
          control={<AppImage width={24} height={24} src={IcPdfFile}/>        }
          label={
            <Link 
              style={{ 
                color: VPB_COLOR.darkBlue,
                textDecorationColor: VPB_COLOR.darkBlue,
              }}
              component="button"
              onClick={() => openExternalLink(link)}
            >
              Văn Bản Xác Nhận Bảo Vệ Dữ Liệu Cá nhân
            </Link>
          }
        />

        <AppButton 
          label="Đồng ý & Tiếp tục" 
          disabled={!isConsent} 
          onClick={handleConfirm}
        />
      </ModalConsentContainer>
    </ModalContainer>
  )
}

ModalConsent.propTypes = {
  toggleModalConsent: PropTypes.func.isRequired,
  handleConfirm: PropTypes.func.isRequired,
};

export default ModalConsent;