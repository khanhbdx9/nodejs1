import ApplicationStep from "@components/ApplicationStep";
import { Notifications } from "@components/Detail";
import { BodyDetailContainer } from "@containers/ApplicationDetail/styles";
import PropTypes from 'prop-types';

import CustomerInfo from "./CustomerInfo";
import Footer from "./Footer";
import ModalCancel from './ModalCancel';
import ModalCloseApp from "./ModalCloseApp";
import ModalConsent from "./ModalConsent";
import ModalSuccess from "./ModalSuccess";
import StaffInfo from "./StaffInfo";
import useLogicApplicationInfo from '../../hooks/useLogicApplicationInfo'

const ApplicationInfo = ({ 
  detail,
  applicationSteps, 
}) => {
  const { 
    id = '', 
    appId = '',
    screen = '',
    fullName = '',
    nationalId = '',
    phoneNumber = '',
    saleFullName = '',
    salePhoneNumber = '',
    createdAtFormat = '',
    expiryDateFormat = '',
    dateOfBirthFormat = '',
    primaryProductName = '',
    additionalProductText = '',
  } = detail;

  const { 
    isFooter,
    isDisabled,
    toggleModalCloseApp,
    toggleModalConsent,
    handleRqCancelInitApp,
    handleRqConfirmInitApp,
  } = useLogicApplicationInfo(id, screen)

  return (
    <>
      <BodyDetailContainer>
        <ApplicationStep currentStep={1} steps={applicationSteps}/>

        <Notifications
          type="alert"
          title={`Hồ sơ ${appId} có yêu cầu khởi tạo.`}
          subTitle="Vui lòng xác nhận để cán bộ bán tiếp tục hoàn thiện hồ sơ.!"
        />

        <StaffInfo
          saleFullName={saleFullName}
          createdAtFormat={createdAtFormat}
          salePhoneNumber={salePhoneNumber}
        />

        <CustomerInfo
          fullName={fullName}
          nationalId={nationalId}
          phoneNumber={phoneNumber}
          expiryDateFormat={expiryDateFormat}
          dateOfBirthFormat={dateOfBirthFormat}
          primaryProductName={primaryProductName}
          additionalProductText={additionalProductText}
        />

        {isFooter && (
          <Footer
            disableBtn={isDisabled}
            toggleModalCloseApp={toggleModalCloseApp}
            toggleModalConsent={toggleModalConsent}
          />
        )}
        
      </BodyDetailContainer>

      <ModalSuccess 
        saleFullName={saleFullName}
        salePhoneNumber={salePhoneNumber}
      />

      <ModalCancel 
        saleFullName={saleFullName}
        salePhoneNumber={salePhoneNumber}
      />
      
      <ModalConsent
        toggleModalConsent={toggleModalConsent}
        handleConfirm={handleRqConfirmInitApp}
      />

      <ModalCloseApp 
        handleClose={()=>toggleModalCloseApp(false)}
        handleConfirm={handleRqCancelInitApp}
      />
    </>
  )
}

ApplicationInfo.propTypes = {
  detail: PropTypes.shape({
    id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    appId: PropTypes.string,
    createdAtFormat: PropTypes.string,
    saleFullName: PropTypes.string,
    salePhoneNumber: PropTypes.string,
    fullName: PropTypes.string,
    nationalId: PropTypes.string,
    expiryDateFormat: PropTypes.string,
    dateOfBirthFormat: PropTypes.string,
    phoneNumber: PropTypes.string,
    primaryProductName: PropTypes.string,
    additionalProductText: PropTypes.string,
    screen: PropTypes.string,
  }),
  applicationSteps: PropTypes.shape({
    label: PropTypes.string,
  })
};

export default ApplicationInfo;