import { ListItemDetail, GroupBox } from "@components/Detail";
import PropTypes from "prop-types";

const StaffInfo = ({
  createdAtFormat = "",
  saleFullName = "",
  salePhoneNumber = "",
}) => {
  return (
    <GroupBox
      title="Cán bộ khởi tạo"
      timeInit={createdAtFormat}
      contentPadding="0px 16px 0px"
    >
      <ListItemDetail primary="Họ & tên" secondary={saleFullName} hideBorder />
      <ListItemDetail
        enableCopy
        primary="Số điện thoại"
        secondary={salePhoneNumber}
      />
    </GroupBox>
  );
};

StaffInfo.propTypes = {
  createdAtFormat: PropTypes.string,
  saleFullName: PropTypes.string,
  salePhoneNumber: PropTypes.string,
};

export default StaffInfo;
