import { ListItemDetail, CollapseBox } from "@components/Detail";
import PropTypes from "prop-types";

const CustomerInfo = ({
  fullName = "",
  nationalId = "",
  phoneNumber = '',
  expiryDateFormat = '',
  dateOfBirthFormat = "",
  primaryProductName = "",
  additionalProductText = "",
}) => {

  return (
    <CollapseBox title="Thông tin hồ sơ" disableCollapse>
      <ListItemDetail secondary={fullName} primary="Họ & tên" hideBorder/>

      <ListItemDetail primary="Ngày sinh" secondary={dateOfBirthFormat} />
      
      <ListItemDetail primary="Số điện thoại" secondary={phoneNumber} />

      <ListItemDetail primary="Số giấy tờ" secondary={nationalId}  />

      <ListItemDetail primary="Sản phẩm chính" secondary={primaryProductName}  />

      <ListItemDetail primary="Sản phẩm đăng ký thêm" secondary={additionalProductText} />

      <ListItemDetail primary="Thời gian hết hạn xác nhận" secondary={expiryDateFormat} />
    </CollapseBox>
  );
};

CustomerInfo.propTypes = {
  fullName: PropTypes.string,
  nationalId: PropTypes.string,
  phoneNumber: PropTypes.string,
  expiryDateFormat: PropTypes.string,
  dateOfBirthFormat: PropTypes.string,
  primaryProductName: PropTypes.string,
  additionalProductText: PropTypes.string,
};

export default CustomerInfo;
