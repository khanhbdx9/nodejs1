import { IMGCancelApp } from '@assets/images'
import ModalContainer from "@components/Modal/ModalContainer";
import SalesSupportCard from '@components/SalesSupportCard';
import { useOneState } from "@utils/hooks/useRedux";
import KEY from '@utils/injectKey';
import PropTypes from "prop-types";

const ModalCancel = ({
  saleFullName,
  salePhoneNumber,
}) => {
  const isOpen = useOneState(KEY.INIT_APPLICATION, 'isModalCancelApp')

  return (
    <ModalContainer 
      position='center'
      open={isOpen}
      hiddenBtnClose
    >
      <SalesSupportCard
        image={IMGCancelApp}
        title="Từ chối khởi tạo hồ sơ"
        desc="Bạn cần hỗ trợ bạn vui lòng liên hệ"
        saleFullName={saleFullName}
        salePhoneNumber={salePhoneNumber}
      />
    </ModalContainer>
  )
}

ModalCancel.propTypes = {
  saleFullName: PropTypes.string,
  salePhoneNumber: PropTypes.string,
};

export default ModalCancel;