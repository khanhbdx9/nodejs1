import styled from 'styled-components';

const width = window.innerWidth;

const FooterContainer = styled.div`
  gap: 24px;
  display: flex;
  margin-top: 16px;
  margin-bottom: 18px;
  justify-content: flex-end;

  .MuiButton-textPrimary {
    text-decoration: underline;
  }
`;

const ModalConsentContainer = styled.div`
  display: grid;
  gap: 16px;
  max-width: calc(659px - 48px);
  @media ${({theme})=>theme.breakpoints.tablet} {
    max-height: 80%;
  }

  .MuiFormControlLabel-root {
    margin: 0;
    gap: 8px;
    padding: 0;
    padding-top: 16px;
    border-top: 1px solid ${({theme}) => theme.colors.paleBlueGray};

    .MuiButtonBase-root {
      padding: 0;
      gap: 16px;

      svg{
        font-size: 20px;
      }
      .MuiTypography-root {
        padding: 0;
      }
    }
  }
`;

const ApplicationInfoContainer = styled.div`
  width: 100%;
  height: 100%;
  gap: 16px;
  display: flex;
  flex-direction: column;
  background: ${({theme}) => theme.colors.white};

  .GroupBox {
    .header {
      padding-bottom: 0;
    }
    .body {
      .MuiListItemText-root {
        &:first-child {
          border-top: unset;
        }
      }
    }
  }
`;

const ConfirmInitApplicationContainer = styled.div`
  width: 100%;
  height: 100%;
  gap: 16px;
  display: flex;
  flex-direction: column;
  background: ${({theme}) => theme.colors.white};
`;

export {
  FooterContainer,
  ModalConsentContainer,
  ApplicationInfoContainer,
}
