import AppButton from "@components/AppButton";
import { ActionContainer } from '@components/Styled/Form'
import { Text } from "@components/Styled/Title";
import Box from "@mui/material/Box";
import Link from "@mui/material/Link";
import PropTypes from 'prop-types';

function Footer({
  onConfirm = () => {},
  onCancel = () => {},
}) {
  return (
    <Box>
      <Text>
        Bằng cách nhấn chọn vào nút ‘Xác nhận hợp đồng’, tôi xin xác nhận:
        Đã đọc, hiểu rõ và chấp thuận toàn bộ thông tin hợp đồng cấp hạn mức tín
        dụng, phát hành và sử dụng thẻ cũng như:
        {" "} <Link target='_blank' href="https://www.vpbank.com.vn/-/media/vpbank-latest/tai-lieu-bieu-mau/bieu-mau/khcn/dieu-kien-giao-dich-chung-ve-cap-tin-dung-danh-cho-khach-hang-ca-nhan-tai-vpbank-07112022.pdf"> Điều khoản và điều kiện tín dụng</Link>
        {" "} và
        {" "} <Link target='_blank' href="https://www.vpbank.com.vn/-/media/vpbank-latest/tai-lieu-bieu-mau/bieu-mau/khcn/dkgd-chung-ve-cung-cap-va-su-dung-dich-vu-phi-tin-dung-ap-dung-doi-voi-khcn-tai-vpbank.pdf"> Điều khoản và điều kiện phi tín dụng </Link>
        {" "} của VPBank.
      </Text>
      <br/>
      <Text>
        Đồng ý cho Ngân hàng chuyển số tiền cho vay thanh toán phí 
        bảo hiểm cho Công ty bảo hiểm một lần duy nhất vào thời điểm 
        giải ngân. Số tiền cho vay tiêu dung sẽ được chuyển vào tài 
        khoản nhận tiền giải ngân của Khách hàng theo quy định của 
        VPBank nhưng không quá 07 ngày làm việc kể từ ngày tôi xác 
        nhận chấp thuận toàn bộ thông tin trên.
      </Text>

      <ActionContainer
        $position="right"
        $minWidth={150}
        sx={{ marginTop: "16px" }}
      >
        <AppButton 
          variant="outlined" 
          label="Hủy hồ sơ" 
          onClick={onCancel}
        />
        <AppButton 
          label="Xác nhận" 
          onClick={onConfirm}
        />
      </ActionContainer>
    </Box>
  );
}

Footer.propTypes = {
  isDisabled: PropTypes.bool,
  onConfirm: PropTypes.func,
  onCancel: PropTypes.func,
};

export default Footer;
