import { IcQuestion } from '@assets/icons'
import AppButton from "@components/AppButton";
import AppImage from "@components/AppImage";
import ModalContainer from "@components/Modal/ModalContainer";
import { Title } from "@components/Styled/Title";
import Box from '@mui/material/Box'
import { useOneState } from "@utils/hooks/useRedux";
import KEY from '@utils/injectKey'
import PropTypes from "prop-types";

const ModalCloseEcontract = ({
  handleConfirm,
  handleClose,
}) => {
  const isOpen = useOneState(KEY.UPL_ECONTRACT, 'isModalCancelEcontract')

  return (
    <ModalContainer 
      hiddenBtnClose
      position='center'
      open={isOpen}
    >
      <Box display="grid" gap="16px" sx={{ maxWidth: 330 }}>
        <AppImage src={IcQuestion} width={60} height={60} styleWrap={{ margin: 'auto'}}/>

        <Title $align="center">Bạn chắc chắn muốn hủy xác nhận hợp đồng này</Title>
        
        <Box display="flex" gap="16px" width="100%">
          <AppButton 
            label='Không'
            fullWidth
            variant='outlined'
            onClick={handleClose}
          />
          <AppButton 
            label='Có'
            fullWidth 
            onClick={handleConfirm}
          />
        </Box>
      </Box>
    </ModalContainer>
  )
}

ModalCloseEcontract.propTypes = {
  handleConfirm: PropTypes.func.isRequired,
  handleClose: PropTypes.func.isRequired,
};

export default ModalCloseEcontract;