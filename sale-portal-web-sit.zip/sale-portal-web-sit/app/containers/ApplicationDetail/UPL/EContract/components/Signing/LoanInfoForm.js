import { ListItemDetail, GroupBox } from "@components/Detail";
import Selected from "@components/Selected";
import Stack from "@mui/material/Stack";
import { useOneState } from "@utils/hooks/useRedux";
import KEY from "@utils/injectKey";
import { useFormik } from "formik";
import PropTypes from "prop-types";
import { useMemo, useEffect, useCallback } from "react";

import Footer from "./Footer";
import validation from './validation';
import { defaultInitialValues } from '../../store/constants'
import { FormLoanContainer } from "../../Styled";

const InsuranceDetails = ({ detail }) => {
  if (!Number(detail?.feeInsurance)) return null;

  return (
    <>
      <ListItemDetail primary="TK nhận phí bảo hiểm" secondary={detail.insuranceReceivingAccount} />
      <ListItemDetail primary="Tên người thụ hưởng" secondary={detail.beneficiaryPerson} />
      <ListItemDetail primary="Ngân hàng thụ hưởng" secondary={detail.beneficiaryBank} />
      <ListItemDetail primary="Mục đích vay" secondary={detail.loanOfPurpose} />
    </>
  );
};

InsuranceDetails.propTypes = {
  detail: PropTypes.shape({
    feeInsurance: PropTypes.string,
    insuranceReceivingAccount: PropTypes.string,
    beneficiaryPerson: PropTypes.string,
    beneficiaryBank: PropTypes.string,
    loanOfPurpose: PropTypes.string,
  }),
};

const LoanInfo = ({
  detail,
  rqMaturityDate,
  rqFirstPaymentDate,
  accountDisbOpt,
  monthlyPaymentDateOpt,
  onCancelEcontract,
  onConfirmEcontract,
  isContractConfirmed,
}) => {
  const maturityDate = useOneState(KEY.UPL_ECONTRACT, "maturityDate");
  const firstPaymentDateOpt = useOneState(KEY.UPL_ECONTRACT, "firstPaymentDateOpt");

  const initialValues = useMemo(() => {
    return {
      ...defaultInitialValues,
      appId: detail?.id,
      isSelectedAccount: accountDisbOpt.length > 0,
    };
  }, [detail.id, accountDisbOpt]);

  const formik = useFormik({
    initialValues,
    validate: validation,
    enableReinitialize: true,
    onSubmit: onConfirmEcontract,
  });

  const { isSelectedAccount, firstPaymentDate, monthlyPaymentDate, accountDisb } = formik.values;

  // Ngày trả nợ đầu tiên và Ngày đáo hạn khoản vay 
  useEffect(() => {
    if (isContractConfirmed || !monthlyPaymentDate) return
    rqFirstPaymentDate({ monthlyRepayment: monthlyPaymentDate, appId: detail.id });
    rqMaturityDate({ monthlyRepayment: monthlyPaymentDate, appId: detail.id });
  }, [monthlyPaymentDate]);

  useEffect(() => {
    if (firstPaymentDateOpt.length === 1 && !firstPaymentDate){
      handleChangeOptByName('firstPaymentDate', firstPaymentDateOpt[0])
    } 
  }, [firstPaymentDate, firstPaymentDateOpt]);

  const handleChangeOptByName = useCallback(
    (name, newValue) => {
      if (name === "monthlyPaymentDate") {
        formik.setFieldValue("firstPaymentDate", "");
      }
      formik.setFieldValue(name, newValue.id);
    },
    [formik]
  );

  return (
    <FormLoanContainer>
      <Stack spacing={2}>
        <GroupBox title="Thông tin khoản vay" color={{ background: "background", border: "background" }}>
          <ListItemDetail primary="Hạn mức phê duyệt" secondary={`${detail?.finalApprovedLimitFormat} VND`} />
          
          <ListItemDetail primary="Số tiền cho vay tiêu dùng" secondary={`${detail?.customerLoanAmountFormat} VND`} />
          
          <ListItemDetail primary="Số tiền cho vay thanh toán phí bảo hiểm sức khỏe OPES" secondary={`${detail?.feeInsuranceFormat} VND`} />

          <InsuranceDetails detail={detail} />

          <ListItemDetail
            primary="Thời hạn vay"
            secondary={detail?.adjustRequestTenor ? `${detail.adjustRequestTenor} Tháng` : ""}
          />

          <ListItemDetail
            primary="Lãi suất"
            secondary={detail?.interestRate ? `${detail.interestRate}%` : ""}
          />

          {/* 
            Xác nhận với a Haohv - 06/10/25: 
             - HHB thì field interestRateMargin luôn có giá trị
             - RB luôn là null 
          */}
          {detail?.interestRateMargin && (
            <ListItemDetail
              primary="Lãi suất điều chỉnh"
              secondary={`${detail.interestRateMargin}%`}
            />
          )}

          <ListItemDetail
            primary="Ngày trả nợ hàng tháng"
            secondary={
              <Selected
                disableClearable
                placeholder="Chọn"
                name="monthlyPaymentDate"
                classNameContainer="select"
                options={monthlyPaymentDateOpt}
                value={monthlyPaymentDate}
                error={formik.errors.monthlyPaymentDate}
                helperText={formik.errors.monthlyPaymentDate}
                onChange={(e, newValue) => handleChangeOptByName("monthlyPaymentDate", newValue)}
              />
            }
          />

          <ListItemDetail
            primary="Ngày trả nợ đầu tiên"
            secondary={
              <Selected
                disableClearable
                placeholder="Chọn"
                name="firstPaymentDate"
                classNameContainer="select"
                options={firstPaymentDateOpt}
                value={firstPaymentDate}
                error={formik.errors.firstPaymentDate}
                helperText={formik.errors.firstPaymentDate}
                onChange={(e, newValue) => handleChangeOptByName("firstPaymentDate", newValue)}
              />
            }
          />

          <ListItemDetail primary="Ngày đáo hạn khoản vay" secondary={maturityDate} />

          {/* 
            Tài khoản giải ngân (nếu có) 
            Hoặc câu thông báo NH sẽ tiến hành mở TK cho KH nếu KH ko có TK đủ điều kiện 
          */}
          <ListItemDetail
            className={isSelectedAccount ? "" : "message"}
            primary={
              isSelectedAccount
                ? "Tài khoản giải ngân"
                : "Khách hàng chưa có Tài khoản. Ngân hàng sẽ tiến hành mở mới TKTT"
            }
            secondary={
              isSelectedAccount && (
                <Selected
                  disableClearable
                  placeholder="Chọn"
                  name="accountDisb"
                  classNameContainer="select"
                  value={accountDisb}
                  options={accountDisbOpt}
                  error={formik.errors.accountDisb}
                  helperText={formik.errors.accountDisb}
                  onChange={(e, newValue) => handleChangeOptByName("accountDisb", newValue)}
                />
              )
            }
          />

          <ListItemDetail primary="Thời hạn xác nhận" secondary={detail?.expiryDateFormat} />
        </GroupBox>

        <Footer onCancel={onCancelEcontract} onConfirm={formik.handleSubmit} />
      </Stack>
    </FormLoanContainer>
  );
};

LoanInfo.propTypes = {
  detail: PropTypes.shape({
    id: PropTypes.string,
    finalApprovedLimitFormat: PropTypes.string,
    customerLoanAmountFormat: PropTypes.string,
    feeInsuranceFormat: PropTypes.string,
    adjustRequestTenor: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    interestRate: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    interestRateMargin: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    firstPaymentDate: PropTypes.string,
    expiryDateFormat: PropTypes.string,
  }),
  rqMaturityDate: PropTypes.func.isRequired,
  isContractConfirmed: PropTypes.bool.isRequired,
  rqFirstPaymentDate: PropTypes.func.isRequired,
  accountDisbOpt: PropTypes.array.isRequired,
  monthlyPaymentDateOpt: PropTypes.array.isRequired,
  onCancelEcontract: PropTypes.func.isRequired,
  onConfirmEcontract: PropTypes.func.isRequired,
};

export default LoanInfo;
