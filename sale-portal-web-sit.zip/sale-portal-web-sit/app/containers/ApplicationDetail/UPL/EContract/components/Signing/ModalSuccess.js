import { IMGSuccessApp } from '@assets/images'
import ModalContainer from "@components/Modal/ModalContainer";
import SalesSupportCard from '@components/SalesSupportCard';
import { useOneState } from "@utils/hooks/useRedux";
import KEY from '@utils/injectKey'
import PropTypes from "prop-types";

const ModalSuccess = ({
  saleFullName,
  salePhoneNumber,
}) => {
  const isOpen = useOneState(KEY.UPL_ECONTRACT, 'isModalSuccessApp')

  return (
    <ModalContainer 
      hiddenBtnClose
      position='center'
      open={isOpen}
    >
      <SalesSupportCard
        image={IMGSuccessApp}
        title="Xác nhận ký thành công"
        desc="Bạn cần hỗ trợ bạn vui lòng liên hệ"
        saleFullName={saleFullName}
        salePhoneNumber={salePhoneNumber}
      />
    </ModalContainer>
  )
}

ModalSuccess.propTypes = {
  saleFullName: PropTypes.string,
  salePhoneNumber: PropTypes.string,
};

export default ModalSuccess;