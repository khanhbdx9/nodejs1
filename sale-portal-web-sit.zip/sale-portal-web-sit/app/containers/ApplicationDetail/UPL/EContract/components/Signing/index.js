import TabsWithTransition from "@components/TabsWithTransition";
import Stack from '@mui/material/Stack'
import { useOneState } from "@utils/hooks/useRedux";
import KEY from "@utils/injectKey";
import PropTypes from 'prop-types';
import { Fragment, useMemo } from 'react'

import Contracts from "./Contracts";
import LoanInfoForm from "./LoanInfoForm";
import ModalCloseEcontract from './ModalCloseEcontract'
import ModalSuccess from './ModalSuccess'
import useLogicContractInfo from '../../hooks/useLogicContractInfo'
import ConfirmEcontract from '../ConfirmEcontract'

function ContractInfo(detail) {
  const {
    monthlyPaymentDateOpt,

    rqFirstPaymentDate,
    onCancelEcontract, 
    onConfirmEcontract,
    confirmCancelEcontract,
    closeModalCancelEcontract,
    rqMaturityDate,
    accountDisbOpt,
    isContractConfirmed,
  } = useLogicContractInfo(detail)

  return (
    <Fragment>
      <Stack spacing={2}>
        <Contracts/>

        <LoanInfoForm
          detail={detail}
          rqMaturityDate={rqMaturityDate}
          accountDisbOpt={accountDisbOpt}
          rqFirstPaymentDate={rqFirstPaymentDate}
          isContractConfirmed={isContractConfirmed}
          monthlyPaymentDateOpt={monthlyPaymentDateOpt}

          onCancelEcontract={onCancelEcontract}
          onConfirmEcontract={onConfirmEcontract}
        />
      </Stack>

      <ModalSuccess 
        saleFullName={detail?.saleFullName} 
        salePhoneNumber={detail?.salePhoneNumber}
      />
      <ModalCloseEcontract
        handleClose={closeModalCancelEcontract}
        handleConfirm={() => confirmCancelEcontract(detail?.id)}
      />
    </Fragment>
  );
}

ContractInfo.propTypes = {
  detail: PropTypes.shape({
    id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
    saleFullName: PropTypes.string,
    salePhoneNumber: PropTypes.string,
  }).isRequired,
  
};

const Signing = ({ detail }) => {
  const currentLayoutSigning = useOneState(KEY.UPL_ECONTRACT, 'currentLayoutEContract');

  const LAYOUT_ECONTRACT = useMemo(() => [
    {
      label: "hợp đồng",
      props: { ...detail },
      content: (props) => <ContractInfo {...props} />,
    },
    {
      label: "OTP xác nhận hợp đồng",
      props: {  ...detail },
      content: (props) => <ConfirmEcontract {...props}/>,
    },
  ], [])

  return <TabsWithTransition 
    hiddenTabHeader
    tabs={LAYOUT_ECONTRACT}
    activeTab={currentLayoutSigning}
  />
}

Signing.propTypes = {
  detail: PropTypes.shape({
    screen: PropTypes.string,
    primaryProductName: PropTypes.string,
  }).isRequired,
};

export default Signing;
