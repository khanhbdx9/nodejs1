import { cutOffTimeAction } from '@App/actions'
import AppButton from "@components/AppButton";
import { Notifications } from '@components/Detail';
import { ActionContainer } from '@components/Styled/Form';
import { Text } from '@components/Styled/Title';
import Stack from '@mui/material/Stack';
import { useReduxSameUseState } from "@utils/hooks/useRedux";
import KEY from '@utils/injectKey'
import { redirectListApplication } from '@utils/redirect'
import PropTypes from 'prop-types';
import { useEffect } from 'react';

function Overdue() {
  const [cutOffTime, rqCutOffTime] = useReduxSameUseState(KEY.GLOBAL, 'cutOffTime', cutOffTimeAction);

  useEffect(() => {
    rqCutOffTime('UPL_SALE')
  }, [])

  return (
    <Stack spacing={2}>
      <Notifications
        type="warning"
        title="Thông báo ngoài giờ làm việc"
        subTitle="Hiện đã quá thời gian trong ngày làm việc để hệ thống thực hiện giao dịch này. Mời bạn vui lòng quay lại xác nhận sau."
      />

      <Stack spacing={1}>
        <Text $size={14}>Chúng tôi hoạt động trong khung giờ:</Text>
        <ul style={{ listStyle: 'inherit', padding: `0 30px` }}>
          <li>
            <Text 
              $size={14}  
              dangerouslySetInnerHTML={{
                __html: cutOffTime?.text || '',
              }}
            />
          </li>
          <li>
            <Text 
              $size={14}
              dangerouslySetInnerHTML={{
                __html: cutOffTime?.sat || '',
              }}
            />
          </li>
        </ul>
        <Text $size={14}>Không hoạt động trong thời gian Lễ, Tết.</Text>
      </Stack>

      <ActionContainer $position="end" $minWidth={137}>
        <AppButton label="Tôi đã hiểu" onClick={redirectListApplication}/>
      </ActionContainer>
    </Stack>
  );
}

Overdue.propTypes = {
  overdueData: PropTypes.arrayOf(
    PropTypes.shape({
      type: PropTypes.string.isRequired,
      contract: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.arrayOf(PropTypes.string)
      ]).isRequired,
      amount: PropTypes.string.isRequired
    })
  )
};

export default Overdue;

