import { IcPdf } from "@assets/icons";
import { GroupBox } from "@components/Detail";
import { Text } from "@components/Styled/Title";
import Box from "@mui/material/Box";
import Link from "@mui/material/Link";
import VPB_COLOR from '@ThemeProvider/colors';
import { ROOT_URI } from '@utils/constants'
import { openExternalLink } from "@utils/helpers";
import { URL } from "@utils/services/api";

import { ContractListContainer } from "../../Styled";

const linkEcontract = `${ROOT_URI}/${URL.unsecure.genEContract}`

const Contracts = () => {
  return (
    <GroupBox contentPadding="16px">
      <Text>
        Căn cứ trên hồ sơ mà Quý khách cung cấp, chúng tôi tạo lập bản đề nghị vay vốn như sau:
      </Text>
      <ContractListContainer>
        <Box className="contract">
          <img src={IcPdf} alt="pdf" />
          <Link 
            component="button" 
            onClick={() => openExternalLink(linkEcontract)} 
            style={{ 
              color: VPB_COLOR.darkBlue,
              textDecorationColor: VPB_COLOR.darkBlue,
            }}
          >
            <Text>Đề nghị vay vốn VPBank.pdf</Text>
          </Link>
        </Box>
      </ContractListContainer>
    </GroupBox>
  );
};

export default Contracts;
