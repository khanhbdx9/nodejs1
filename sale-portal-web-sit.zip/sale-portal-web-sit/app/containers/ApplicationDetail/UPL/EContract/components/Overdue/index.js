import AppButton from "@components/AppButton";
import { Notifications } from '@components/Detail';
import { ActionContainer } from '@components/Styled/Form';
import { Text } from '@components/Styled/Title';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Box,
  Stack,
} from '@mui/material';
import VPB_COLOR from "@ThemeProvider/colors";
import { redirectListApplication } from '@utils/redirect'
import PropTypes from 'prop-types';
import { Fragment } from 'react';
import { formatNumber } from '@utils/helpers'

const cellStyle = {
  padding: '7px 10px',
  borderRight: `1px solid ${VPB_COLOR.neutra1001}`
};

const renderContracts = (contracts) => {
  if (Array.isArray(contracts)) {
    return contracts.map((contract, index) => (
      <Box
        key={`${contract}-${index}`}
        sx={{
          borderTop: index ? `1px solid ${VPB_COLOR.neutra1001}` : 'none',
          padding: '0 10px'
        }}
      >
        <Text $line="34px">{contract}</Text>
      </Box>
    ));
  }
  return (
    <Text $line="34px" sx={{ padding: '0 10px' }}>
      {contracts}
    </Text>
  );
};

const renderTableRow = (row, index) => (
  <TableRow
    key={index}
    sx={{ backgroundColor: index % 2 !== 0 ? VPB_COLOR.shade1 : VPB_COLOR.white }}
  >
    <TableCell sx={{ padding: '0 10px', borderRight: `1px solid ${VPB_COLOR.neutra1001}` }}>
      <Text $color="lightGreen" $weight="600">{row.vi_type}</Text>
    </TableCell>
    <TableCell sx={{ padding: 0, borderRight: `1px solid ${VPB_COLOR.neutra1001}` }}>
      {renderContracts(row.contracts)}
    </TableCell>
    <TableCell sx={{ padding: '0 10px' }}>
      <Text $color="red">{formatNumber(row.total) + ' VND'}</Text>
    </TableCell>
  </TableRow>
);

function Overdue({ detail = {} }) {
  const { overdueInfos = [] } = detail;

  return (
    <Fragment>
      <Stack spacing={2}>
        <Notifications
          type="warning"
          title="Thông báo LD nợ quá hạn"
          subTitle="Hiện bạn đang còn dư nợ quá hạn tại VPBank như chi tiết dưới. Vui lòng thanh toán các dự nợ quá hạn trước khi tiếp tục với khoản vay đang đăng ký vay."
        />

        <TableContainer>
          <Table sx={{ minWidth: 425 }}>
            <TableHead sx={{ backgroundColor: VPB_COLOR.neutral }}>
              <TableRow>
                <TableCell sx={cellStyle}>
                  <Text $color="white" $weight="600">Loại</Text>
                </TableCell>
                <TableCell sx={cellStyle}>
                  <Text $color="white" $weight="600">Số hợp đồng</Text>
                </TableCell>
                <TableCell sx={{ padding: '7px 10px' }}>
                  <Text $color="white" $weight="600">Số tiền quá hạn</Text>
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody sx={{ border: `1px solid ${VPB_COLOR.neutra1001}` }}>
              {Array.isArray(overdueInfos) && overdueInfos.map(renderTableRow)}
            </TableBody>
          </Table>
        </TableContainer>

        <ActionContainer $position="end" $minWidth={137}>
          <AppButton label="Tôi đã hiểu" onClick={redirectListApplication}/>
        </ActionContainer>
      </Stack>
    </Fragment>
  );
}

Overdue.propTypes = {
  detail: PropTypes.shape({
    overdueInfos: PropTypes.arrayOf(
      PropTypes.shape({
        vi_type: PropTypes.string,
        contracts: PropTypes.oneOfType([
          PropTypes.string,
          PropTypes.arrayOf(PropTypes.string)
        ]),
        total: PropTypes.oneOfType(PropTypes.string, PropTypes.number)
      })
    )
  }).isRequired,
  
};

export default Overdue;
