import { MESSAGE_SYSTEM } from '@utils/message'

const validation = ({ isSelectedAccount, accountDisb, firstPaymentDate, monthlyPaymentDate }) => {
  const error = {};

  if(!firstPaymentDate) error.firstPaymentDate = MESSAGE_SYSTEM.rq
  if(!monthlyPaymentDate) error.monthlyPaymentDate = MESSAGE_SYSTEM.rq
  if (isSelectedAccount && !accountDisb) error.accountDisb = MESSAGE_SYSTEM.rq
  
  return error;
};

export default validation;
