import { setLoadingAction, setFieldValueGlobalAction } from '@App/actions';
import { responseCode, DateFormat1, SUCCESS, TOKEN_KEY } from '@utils/constants';
import KEY from '@utils/injectKey'
import { MESSAGE_SYSTEM } from '@utils/message';
import { redirectListApplication } from '@utils/redirect'
import { URL, apiRequest } from "@utils/services/api";
import SessionStorageService from "@utils/storage/session";
import getLd from 'lodash/get';
import moment from 'moment';
import { toast } from 'react-toastify';
import { all, call, put as dispatch, takeLatest, select } from 'redux-saga/effects';

import { 
  confirmEcontractAction, 
  verifyOtpEcontractAction, 
  cancelEcontractAction, 
  resendOtpEcontractAction,
  firstPaymentDateAction,
  maturityDateAction,
} from './actions';
// import { ECONTRACT_LAYOUT } from './constants'


// ---------------------------- OPTION ----------------------------
function* firstPaymentDateSaga(action) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(firstPaymentDateAction.request());

    const payload = {
      url: URL.unsecure.firstPaymentDate,
      params: action?.payload,
    };

    const { data: res = {} } = yield call(apiRequest.get, payload);
    const { data = [], meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        const items = Array.isArray(data) ? data.map(_d => ({
          label: moment(_d).format(DateFormat1),
          id: _d
        })) : [];

        yield dispatch(firstPaymentDateAction.success({ items }));
        break;
      }
      default: {
        toast.error(getLd(meta, 'message', MESSAGE_SYSTEM.error_02));
        break;
      }
    }
  } catch (error) {
    toast.error(error?.meta?.message || MESSAGE_SYSTEM.default);
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

function* maturityDateSaga(action) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(maturityDateAction.request());

    const payload = {
      url: URL.unsecure.maturityDate,
      params: action?.payload,
    };

    const { data: res = {} } = yield call(apiRequest.get, payload);
    const { data = "", meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        yield dispatch(maturityDateAction.success({ maturityDate: data ? moment(data).format(DateFormat1) : '' }));
        break;
      }
      default: {
        toast.error(getLd(meta, 'message', MESSAGE_SYSTEM.error_02));
        break;
      }
    }
  } catch (error) {
    toast.error(error?.meta?.message || MESSAGE_SYSTEM.default);
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

// ---------------------------- END OPTION ----------------------------

function* confirmEcontractSaga(action) {
  try {
    if(!action?.payload?.id){
      toast.error(MESSAGE_SYSTEM.notFindAppId);
      return;
    }

    yield dispatch(setLoadingAction(true));

    const payload = {
      url: URL.unsecure.rqConfirmEContract(action?.payload?.id),
    };

    const { data: res = {} } = yield call(apiRequest.post, payload);
    const { data = {}, meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        if(data?.status === 200){
          SessionStorageService.setItem(TOKEN_KEY, data?.signature);
          
          yield dispatch(confirmEcontractAction.success());

          toast.success(data?.message || '');
          return;
        }

        toast.error(data?.message || 'Đã có lỗi xảy ra khi xác nhận. Vui lòng thử lại!');
        break;
      }
      default: {
        toast.error(getLd(meta, 'message', MESSAGE_SYSTEM.error_02));
        break;
      }
    }
  } catch (error) {
    toast.error(getLd(error, 'meta.message', MESSAGE_SYSTEM.default));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

function* verifyOtpEcontractSaga({ payload }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(verifyOtpEcontractAction.request());

    const detail = yield select(state => state[KEY.GLOBAL]['detail']);
    const dataConfirmEContract = yield select(state => state[KEY.UPL_ECONTRACT]['dataConfirmEContract']);

    const body = { ...payload.data, ...dataConfirmEContract }
    if(!body.accountDisb) delete body.accountDisb;

    const request = {
      url: URL.unsecure.confirmEContract(payload?.id),
      data: body
    };

    const { data: res = {} } = yield call(apiRequest.post, request);
    const { data = {}, meta = {} } = res;

    switch (meta?.code) {
      case responseCode["IL-200"]: {
        if(data?.screen) {
          yield dispatch(setFieldValueGlobalAction('detail', {...detail, screen: data.screen}));
          return
        }

        if(data?.message === SUCCESS){
          yield dispatch(verifyOtpEcontractAction.success());
          return;
        }

        yield dispatch(verifyOtpEcontractAction.failure({
          message: data?.message || meta?.message
        }));
        break;
      }
      default: {
        yield dispatch(verifyOtpEcontractAction.failure(meta));
        break;
      }
    }
  } catch (error) {
    yield dispatch(verifyOtpEcontractAction.failure(error?.meta));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

function* resendOtpEcontractSaga() {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(resendOtpEcontractAction.request());

    const request = {
      url: URL.unsecure.rqEContract,
    };

    const { data: res = {} } = yield call(apiRequest.get, request);
    const { data = {}, meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        if(data?.signature){
          yield dispatch( resendOtpEcontractAction.success());

          SessionStorageService.setItem(TOKEN_KEY, data.signature);
          toast.success(data?.message);
          break;
        }
        
        yield dispatch(resendOtpEcontractAction.failure({
          message: data?.message || meta?.message || MESSAGE_SYSTEM?.notToken
        }));
        break;
      }
      default: {
        yield dispatch(resendOtpEcontractAction.failure(meta));
        break;
      }
    }
  } catch (error) {
    yield dispatch(resendOtpEcontractAction.failure(error?.meta));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

function* cancelEcontractSaga({ payload }) {
  try {
    yield dispatch(setLoadingAction(true));

    const request = {
      url: URL.unsecure.cancelAppByCustomer,
      data: null,
      params: payload,
    };

    const { data: res = {} } = yield call(apiRequest.post, request);
    const { data = {}, meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        if(data?.message === SUCCESS){
          yield dispatch( cancelEcontractAction.success());

          toast.success(data?.message);

          redirectListApplication()
          return
        }
        
        toast.error(data?.message || meta?.message);
        break;
      }
      default: {
        toast.error(data?.message || meta?.message);
        break;
      }
    }
  } catch (error) {
    toast.error(error?.meta?.message);
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export default function* watchAll() {
  yield all([
    takeLatest(maturityDateAction.TRIGGER, maturityDateSaga),
    takeLatest(firstPaymentDateAction.TRIGGER, firstPaymentDateSaga),
    takeLatest(confirmEcontractAction.TRIGGER, confirmEcontractSaga),
    takeLatest(verifyOtpEcontractAction.TRIGGER, verifyOtpEcontractSaga),
    takeLatest(resendOtpEcontractAction.TRIGGER, resendOtpEcontractSaga),
    takeLatest(cancelEcontractAction.TRIGGER, cancelEcontractSaga),
  ]);
}
