import { produce } from 'immer';

import { 
  verifyOtpEcontractAction, 
  resendOtpEcontractAction,
  confirmEcontractAction,
  firstPaymentDateAction,
  maturityDateAction
} from './actions';
import { 
  defaultInitialValues,
  ECONTRACT_LAYOUT,
  SET_FIELD_VALUE_ACTION,
  RESET_DATA_ECONTRACT_ACTION,
  SET_LAYOUT_ECONTRACT_ACTION,
} from './constants';

export const initialState = {
  isModalConsent: false,
  isModalCancelApp: false,
  isModalSuccessApp: false,
  isModalCancelEcontract: false,

  currentLayoutEContract: ECONTRACT_LAYOUT.E_CONTRACT,

  branchOpt: [],
  msgError: "",


  maturityDate: "",
  firstPaymentDateOpt: [],

  dataConfirmEContract: defaultInitialValues
};

const EContractReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      // --------------- SAGA -----------------
      case confirmEcontractAction.REQUEST: { break }
      case confirmEcontractAction.FAILURE: { break }
      case confirmEcontractAction.SUCCESS: {
        draft.currentLayoutEContract = ECONTRACT_LAYOUT.CONFIRM_E_CONTRACT;
        break;
      }

      case maturityDateAction.REQUEST: {
        draft.maturityDate = "";
        break 
      }
      case maturityDateAction.SUCCESS: {
        draft.maturityDate = action.payload?.maturityDate;
        break;
      }
      case maturityDateAction.FAILURE: { break }


      case firstPaymentDateAction.REQUEST: {
        draft.maturityDate = "";
        draft.firstPaymentDateOpt = []
        break 
      }
      case firstPaymentDateAction.SUCCESS: {
        draft.firstPaymentDateOpt = action.payload?.items;
        break;
      }
      case firstPaymentDateAction.FAILURE: { break }


      case resendOtpEcontractAction.REQUEST: {
        draft.msgError = "";
        break;
      }
      case resendOtpEcontractAction.SUCCESS: {
        draft.msgError = "";
        break;
      }
      case resendOtpEcontractAction.FAILURE: {
        draft.msgError = action.payload?.message || '';
        break;
      }

      case verifyOtpEcontractAction.REQUEST: {
        draft.msgError = "";
        break;
      }
      case verifyOtpEcontractAction.SUCCESS: {
        draft.msgError = "";
        draft.isModalSuccessApp = true;
        draft.currentLayoutEContract = ECONTRACT_LAYOUT.E_CONTRACT;
        break;
      }
      case verifyOtpEcontractAction.FAILURE: {
        draft.msgError = action.payload?.message || '';
        break;
      }

      // --------------- ACTION NORMAL -----------------
      case SET_LAYOUT_ECONTRACT_ACTION: {
        draft.currentLayoutEContract = action?.payload || ECONTRACT_LAYOUT.OTHER;
        break;
      }

      case SET_FIELD_VALUE_ACTION: {
        draft[action.payload.key] = action.payload.value;
        break;
      }   

      case RESET_DATA_ECONTRACT_ACTION: {
        return initialState
      }
    }
  });

export default EContractReducer;
