import { useDispatchRedux } from "@utils/hooks/useRedux";
import { useEffect, useMemo } from 'react';

import { 
  maturityDateAction,
  setFieldValueAction,
  confirmEcontractAction,
  cancelEcontractAction,
  firstPaymentDateAction,
} from '../store/actions';
import { APPROVED } from '../store/constants';

const useLogicSigning = (detail) => {
  const rqMaturityDate = useDispatchRedux(maturityDateAction);
  const rqCancelEcontract = useDispatchRedux(cancelEcontractAction);
  const rqConfirmEcontract = useDispatchRedux(confirmEcontractAction);
  const rqFirstPaymentDate = useDispatchRedux(firstPaymentDateAction);

  const setFieldValueEcontractUpl = useDispatchRedux(setFieldValueAction);

  const isContractConfirmed = useMemo(() => {
    return detail?.screen === APPROVED
  }, [detail?.screen])

  const monthlyPaymentDateOpt = useMemo(() => {
    if(!Array.isArray(detail?.monthlyPaymentDate)) return [];
    return detail.monthlyPaymentDate.map(day => ({
      label: `Ngày ${day}`,
      id: day
    }))
  }, [JSON.stringify(detail?.monthlyPaymentDate)])

  const accountDisbOpt = useMemo(() => {
    if(!Array.isArray(detail?.accountDisb)) return [];
    return detail.accountDisb.map(acc => ({
      label: acc,
      id: acc
    }))
  }, [JSON.stringify(detail?.accountDisb)])

  const onCancelEcontract = () => setFieldValueEcontractUpl('isModalCancelEcontract', true)
  
  const closeModalCancelEcontract = () => setFieldValueEcontractUpl('isModalCancelEcontract', false);

  const onConfirmEcontract = (values) =>{
    rqConfirmEcontract({ id: values.appId });

    setFieldValueEcontractUpl(
      'dataConfirmEContract', 
      {
        accountDisb: values.accountDisb,
        firstPaymentDate: values.firstPaymentDate,
        monthlyPaymentDate: values.monthlyPaymentDate,
      }
    );
  } 

  const confirmCancelEcontract = (appId) => {
    closeModalCancelEcontract();
    rqCancelEcontract({ appId })
  }

  useEffect(()=>{
    if(!isContractConfirmed) return
    setFieldValueEcontractUpl('isModalSuccessApp', true)
  },[isContractConfirmed])

  return {
    onCancelEcontract,
    onConfirmEcontract,
    confirmCancelEcontract,
    closeModalCancelEcontract,
    rqFirstPaymentDate,
    rqMaturityDate,
    monthlyPaymentDateOpt,
    accountDisbOpt,
    isContractConfirmed,
  }
}

export default useLogicSigning;