import ApplicationStep from "@components/ApplicationStep";
import { BodyDetailContainer } from "@containers/ApplicationDetail/styles";
import withStepScreenMapping from '@HOC/withStepScreenMapping';
import { useDispatchRedux } from "@utils/hooks/useRedux";
import KEY from '@utils/injectKey'
import PropTypes from 'prop-types';
import { useEffect } from 'react'

import CutOfftime from './components/CutOfftime';
import Overdue from './components/Overdue';
import Signing from "./components/Signing";
import { resetDataEcontractAction } from './store/actions'

const MAPPING_SCREEN_ECONTRACT_UPL = {
  OVERDUE: Overdue, // nợ quá hạn
  OUT_SIDE_WORKING_HOUR: CutOfftime, // cutofftime giải ngân
  E_CONTRACT: Signing, // xác nhận hợp đồng
  // VIDEO_CALL: Signing, // video call
}

const ComponentEcontractUplRender = withStepScreenMapping(MAPPING_SCREEN_ECONTRACT_UPL, KEY.UPL_ECONTRACT);

const Main = ({ detail, applicationSteps }) =>{
  const rqResetDataEcontract = useDispatchRedux(resetDataEcontractAction)

  useEffect(()=>{
    return () => rqResetDataEcontract();
  }, []);

  return (
    <BodyDetailContainer>
      <ApplicationStep steps={applicationSteps} currentStep={4}/>

      <ComponentEcontractUplRender 
        //props
        detail={detail}
        
        // init screen
        screen={detail?.screen || 'NOT FOUND'}
        productType={detail?.productType}
      />
    </BodyDetailContainer>
  )
}

Main.propTypes = {
  detail: PropTypes.shape({
    screen: PropTypes.string,
    productType: PropTypes.string,
    primaryProductName: PropTypes.string,
  }).isRequired,
  applicationSteps: PropTypes.array
};

export default Main;
