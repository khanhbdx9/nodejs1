import Box from "@mui/material/Box";
import styled from "styled-components";

export const CardItemContainer = styled(Box)`
  background-color: ${(p) => p.theme.colors.shade0};
  padding: 16px;
  display: flex;
  gap: 24px;
  border-radius: 8px;
  margin-top: unset;

  @media ${(p) => p.theme.breakpoints.tablet} {
    flex-direction: column;
    gap: 16px;
    margin-top: 120px;
    padding-bottom: 24px;
  }

  .cardImage {
    background-color: white;
    flex: 1.5;
    img {
      margin: 0 25%;
    }
    h3 {
      display: none;
      @media ${(p) => p.theme.breakpoints.tablet} {
        display: block;
      }
    }

    @media ${(p) => p.theme.breakpoints.tablet} {
      background-color: unset;
      margin-top: -130px;
    }
  }

  .cardDetail {
    flex: 2;
    display: flex;
    flex-direction: column;
    gap: 16px;
    .cardName {
      @media ${(p) => p.theme.breakpoints.tablet} {
        display: none;
      }
    }
  }
`;

export const BenefitContainer = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: 16px;
  .item {
    display: flex;
    gap: 8px;
  }
`;

export const CardListContainer = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: ${({ gap = 16 }) => gap}px;
  &.list {
    .cardImageContainer {
      background-color: ${(p) => p.theme.colors.white};
    }
  }
`;

export const CategoryListContainer = styled(Box)`
  display: flex;
  gap: 4px;
  overflow: auto;
  .item {
    cursor: pointer;
    padding: 8px 16px;
    display: flex;
    gap: 8px;
    justify-content: center;
    align-items: center;
    border-radius: 100px;
    background-color: ${(p) => p.theme.colors.white};
    flex-shrink: 0;

    &.active {
      border: 1px solid ${(p) => p.theme.colors.lightGreen};
    }
  }
`;

export const ContractListContainer = styled(Box)`
  display: flex;
  gap: 16px;
  margin-top: 16px;

  @media ${(p) => p.theme.breakpoints.tablet} {
    flex-direction: column;
  }

  .contract {
    display: flex;
    align-items: center;
    justify-content: center;
    flex: 1;
    height: 56px;
    background-color: white;
    gap: 8px;
    border-radius: 8px;

    @media ${(p) => p.theme.breakpoints.tablet} {
      flex: unset;
    }
  }
`;

export const ButtonCardList = styled(Box)`
  height: 44px;
  display: flex;
  justify-content: center;
  align-items: center;
`;

export const FormLoanContainer = styled.form`
  .MuiTypography-body1 {
    max-width: 50%;
  }

  .message {
    .MuiTypography-body1 {
      max-width: unset;
    }
  }

  .select {
    .txtlable {
      display: none;
    }
    .MuiAutocomplete-root {
      width: 147px;
      border-radius: 8px;
    }
    .MuiAutocomplete-popper {
      border: 0.5px solid ${({ theme }) => theme.colors.neutral01};
      color: ${({ theme }) => theme.colors.darkBlue} !important;
    }

    .Mui-error {
      margin: 0;
    }
  }
`;
