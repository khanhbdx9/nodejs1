import styled from 'styled-components';

const CardBeingIssuedContainer = styled.div`
  padding: 24px;

  .__cardContainer {
    margin-top: 24px;

    .header {
      padding-bottom: 16px;
    }
    .body {
      .MuiListItemText-root {
        border-top: 1px solid #CAD3DA4D;
      }
    }
    .GroupBox {
      ${({ $hasVPO }) => $hasVPO && `
        background: #C0F1D8;
        border-color: #C0F1D8;
      `}
    }

    .__cardContainer___respectfully {
      display: none;
    }
  }
`;

export { CardBeingIssuedContainer }
