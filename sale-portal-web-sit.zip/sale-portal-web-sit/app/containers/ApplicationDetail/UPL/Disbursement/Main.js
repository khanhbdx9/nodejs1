import { IMGSuccessApp } from '@assets/images';
import ApplicationStep from "@components/ApplicationStep";
import SalesSupportCard from '@components/SalesSupportCard';
import { PACKAGE } from '@utils/constants'
import PropTypes from 'prop-types';
import { useMemo } from "react";

import { CardBeingIssuedContainer } from './Styled';

const MAPPING_BY_HAS_VPO = {
  NO_VPO: {
    title: "Hoàn thành đăng ký",
    titleSaleBox: "Nhân viên hỗ trợ",
    desc: "Hồ sơ của bạn đang được xử lý. Ngân hàng sẽ thông báo đến bạn trong thời gian sớm nhất",
    isBtnBottom: false,
    image: IMGSuccessApp,
    content: [
      {
        primary: 'Họ & tên nhân viên',
        field: 'saleFullName',
        hideBorder: true
      },
      {
        primary: 'Số điện thoại',
        field: 'salePhoneNumber',
        isIconTel: true,
        enableCopy: true
      }
    ]
  },
  VPO: {
    title: "Giải ngân thành công",
    titleSaleBox: "Thông tin dịch vụ VPBank Online",
    desc: "Vui lòng kiểm tra thông tin giải ngân trong VPBank NEO",
    isBtnBottom: false,
    image: IMGSuccessApp,
    content: [
      {
        primary: 'Tên đăng nhập',
        field: 'vpoAccount',
        hideBorder: true
      },
      {
        primary: 'Mật khẩu',
        // field: 'salePhoneNumber',
        render: () => "Vui lòng kiểm tra tin nhắn từ VPBank"
      },
      {
        primary: 'Gói đăng ký',
        field: 'vpoServicePackage',
        render: val => PACKAGE[val] || ''
      }
    ]
  }
};

const Main = ({ detail, applicationSteps }) => {
  const infoProps = useMemo(() => {
    const key = detail?.hasVPO ? 'VPO' : 'NO_VPO';
    const config = MAPPING_BY_HAS_VPO[key];

    return {
      ...config,
      content: config.content.map(item => ({
        ...item,
        secondary: detail?.[item.field] || ''
      }))
    };
  }, [detail?.hasVPO]);

  return (
    <CardBeingIssuedContainer $hasVPO={detail?.hasVPO}>
      <ApplicationStep currentStep={5} steps={applicationSteps}/>
      <SalesSupportCard {...infoProps} />
    </CardBeingIssuedContainer>
  );
};

Main.propTypes = {
  detail: PropTypes.shape({
    hasVPO: PropTypes.bool,
    saleFullName: PropTypes.string,
    salePhoneNumber: PropTypes.string,
  }),
  applicationSteps: PropTypes.shape({
    label: PropTypes.string,
  })
};

export default Main;
