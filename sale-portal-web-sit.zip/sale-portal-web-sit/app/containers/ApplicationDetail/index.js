import LoadingIndicator from '@components/LoadingIndicator';
import loadable from '@utils/loadable';
import PropTypes from 'prop-types';

const Provider = ({ children }) => {
  return <>{children}</>;
};

Provider.propTypes = {
  children: PropTypes.node.isRequired,
};

const ApplicationDetail = loadable(() => import('./Main'), {
  fallback: <LoadingIndicator />,
  provider: Provider,
});

export default ApplicationDetail;
