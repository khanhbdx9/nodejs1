import { ApplicationName } from "@components/Detail";
import DetailFallback from '@Fallback/Detail';
import withStepScreenMapping from '@HOC/withStepScreenMapping';
// import TabsWithTransition from "@components/TabsWithTransition";
import KEY from '@utils/injectKey'

import CardBeingIssuedCC from "./CC/CardBeingIssued";
import CardDeliveryCC from "./CC/CardDelivery";
import EContractCC from "./CC/EContract";
import BankApproval from "./Common/BankApproval";
import CompleteApplication from "./Common/CompleteApplication";
import InitApplication from "./Common/InitApplication";
import useLogicApplicationDetail from "./hooks";
import ApplicationDetailContainer from "./styles";
import DisbursementUpl from "./UPL/Disbursement";
import EContractUpl from "./UPL/EContract";

const MAPPING_SCREEN = {
  LOADING: DetailFallback, // loading
  CC: {
    CONFIRM_APP: InitApplication, // xác nhận khởi tạo
    CHECK_APP: CompleteApplication, // Hoàn thiện hồ sơ
    BANK_APPROVED: BankApproval, // Ngân hàng phê duyệt
    E_CONTRACT: EContractCC, // Ký hợp đồng
    DISBURSEMENT: CardBeingIssuedCC, // Đang phát hành thẻ
    SHIPPING_CARD_SUCCESS: CardDeliveryCC, // Hành trình giao thẻ
  },
  UPL: {
    CONFIRM_APP: InitApplication, // xác nhận khởi tạo
    CHECK_APP: CompleteApplication, // Hoàn thiện hồ sơ
    BANK_APPROVED: BankApproval, // Ngân hàng phê duyệt
    E_CONTRACT: EContractUpl, // Ký hợp đồng
    DISBURSEMENT: DisbursementUpl, // Đang giải Ngân
  },
  OD: {
    CONFIRM_APP: InitApplication, // xác nhận khởi tạo
    CHECK_APP: CompleteApplication, // Hoàn thiện hồ sơ
    BANK_APPROVED: BankApproval, // Ngân hàng phê duyệt
    E_CONTRACT: EContractUpl, // Ký hợp đồng
    DISBURSEMENT: DisbursementUpl, // Đang giải Ngân
  }
}

const ComponentApplicationRender = withStepScreenMapping(MAPPING_SCREEN, KEY.DETAIL_APPLICATION);

function ApplicationDetail() {
  const { detail, applicationSteps } = useLogicApplicationDetail();

  return (
    <ApplicationDetailContainer>
      <ApplicationName 
        name={`Hồ sơ: ${detail?.appId || ""}`} 
      />

      <ComponentApplicationRender
        //props
        detail={detail}
        applicationSteps={applicationSteps}

        // init screen
        screen={detail?.step}
        productType={detail?.productType}
      />
    </ApplicationDetailContainer>
  );
}

export default ApplicationDetail;
