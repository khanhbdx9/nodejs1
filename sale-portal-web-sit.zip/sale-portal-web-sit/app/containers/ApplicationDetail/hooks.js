import { detailByIdAction, resetDataGlobalAction } from '@App/actions';
import { STEPS_APPLICATION } from '@utils/constants'
import { useDispatchRedux, useOneState } from "@utils/hooks/useRedux";
import KEY from "@utils/injectKey";
import { useEffect, useMemo } from 'react';
import { useParams } from 'react-router-dom';

const useLogicApplicationDetail = () => {
  const { id } = useParams();

  // Lấy dữ liệu chi tiết hồ sơ từ Redux store
  const detail = useOneState(KEY.GLOBAL, 'detail');
  const { productType } = detail;

  const rqDetailByIdAction = useDispatchRedux(detailByIdAction);
  const resetDataGlobal = useDispatchRedux(resetDataGlobalAction);

  /**
   * Effect: Gọi API lấy chi tiết hồ sơ khi có ID
   */
  useEffect(() => {
    if (!id) return;
    setTimeout(() => rqDetailByIdAction({ id }), 100);
  }, [id]);

  /**
   * Effect: Reset dữ liệu toàn cục khi component bị unmount
   */
  useEffect(() => {
    return () => resetDataGlobal();
  }, []);

  /**
   * Memo: Tính toán step tương ứng với sản phẩm
   * - Dựa vào productType và step để lấy list step từ STEPS_APPLICATION
   * - Nếu không tìm thấy, mặc định trả về theo step của CC(Thẻ tín dụng)
   */
  const applicationSteps = useMemo(() => {
    return STEPS_APPLICATION[productType || 'CC']
  }, [productType]);

  return {
    detail,
    applicationSteps,
  };
};

export default useLogicApplicationDetail;
