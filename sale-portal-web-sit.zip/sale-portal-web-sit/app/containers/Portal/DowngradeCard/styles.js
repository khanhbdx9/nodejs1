import Box from "@mui/material/Box";
import styled from "styled-components";

export const DowngradeCardContainer = styled(Box)`
  height: 100%;
  .tab {
    height: inherit;
  }
`;

export const LoanContainer = styled(Box)`
  display: flex;
  gap: 16px;
  background-color: white;
  padding: 16px;
  border-radius: 8px;
  align-items: center;
  .cardImage {
    width: 60px;
    height: 95px;
  }
`;

export const CardItemContainer = styled(Box)`
  background-color: ${(p) => p.theme.colors.shade0};
  padding: 16px;
  display: flex;
  gap: 24px;
  border-radius: 8px;
  margin-top: unset;

  @media ${(p) => p.theme.breakpoints.tablet} {
    flex-direction: column;
    gap: 16px;
    margin-top: 120px;
    padding-bottom: 24px;
  }

  .cardImage {
    background-color: white;
    flex: 1.5;
    display: flex;
    justify-content: center;
    align-items: center;

    h3 {
      display: none;
      @media ${(p) => p.theme.breakpoints.tablet} {
        display: block;
      }
    }

    @media ${(p) => p.theme.breakpoints.tablet} {
      background-color: unset;
      margin-top: -130px;
      flex-direction: column;
      gap: 16px;
    }
  }

  .cardDetail {
    flex: 2;
    display: flex;
    flex-direction: column;
    gap: 16px;
    .cardName {
      @media ${(p) => p.theme.breakpoints.tablet} {
        display: none;
      }
    }
  }
`;

export const SummaryContainer = styled(Box)`
  display: flex;
  align-items: center;
  gap: 24px;
  border-radius: 8px;
  margin-top: unset;

  @media ${(p) => p.theme.breakpoints.tablet} {
    flex-direction: column;
    gap: 16px;
    margin-top: 120px;
    /* padding-bottom: 24px; */
  }

  .cardImage {
    flex: 1;
    display: flex;
    justify-content: center;
    align-items: center;

    .cardNameMobile {
      display: none;
    }

    h3 {
      display: none;
      @media ${(p) => p.theme.breakpoints.tablet} {
        display: block;
      }
    }

    @media ${(p) => p.theme.breakpoints.tablet} {
      margin-top: -130px;
      flex-direction: column;
      gap: 8px;
      .cardNameMobile {
        display: block;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 8px;
      }
    }
  }

  .cardDetail {
    flex: 2;
    display: flex;
    flex-direction: column;
    gap: 16px;
    justify-content: space-between;
    .cardName {
      @media ${(p) => p.theme.breakpoints.tablet} {
        display: none;
      }
    }
  }
`;

export const ActionContainer = styled(Box)`
  display: flex;
  justify-content: ${({ $position }) => $position};
  gap: 16px;
  button {
    min-width: ${({ $minWidth = 131 }) => $minWidth}px;
    @media ${(p) => p.theme.breakpoints.tablet} {
      flex: 1;
    }
  }
`;

export const BenefitContainer = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: 16px;
  flex: 1;
  .item {
    display: flex;
    gap: 8px;
  }
`;

export const CardListContainer = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: ${({ gap = 16 }) => gap}px;
  /* flex: 1; */
  .cardImageContainer {
    min-height: 297px;
  }
  &.list {
    .cardImageContainer {
      background-color: ${(p) => p.theme.colors.white};
      min-height: 297px;
    }
  }
`;

export const CategoryListContainer = styled(Box)`
  display: flex;
  gap: 4px;
  overflow: auto;
  padding-bottom: 8px;
  .item {
    cursor: pointer;
    padding: 8px 16px;
    display: flex;
    gap: 8px;
    justify-content: center;
    align-items: center;
    border-radius: 100px;
    background-color: ${(p) => p.theme.colors.white};
    border: 1px solid ${(p) => p.theme.colors.shade0};
    flex-shrink: 0;

    &.active {
      border: 1px solid ${(p) => p.theme.colors.lightGreen};
    }
  }
`;

export const ContractListContainer = styled(Box)`
  display: flex;
  gap: 16px;
  margin-top: 16px;

  @media ${(p) => p.theme.breakpoints.tablet} {
    flex-direction: column;
  }

  .contract {
    display: flex;
    align-items: center;
    justify-content: center;
    flex: 1;
    height: 56px;
    background-color: white;
    gap: 8px;
    border-radius: 8px;

    @media ${(p) => p.theme.breakpoints.tablet} {
      flex: unset;
    }
  }
`;

export const ButtonCardList = styled(Box)`
  height: 44px;
  display: flex;
  justify-content: center;
  align-items: center;
`;
const ModalContentContainer = styled(Box)`
  width: 100vw;
  max-width: 680px;
  display: flex;
  gap: 16px;
  flex-direction: column;
  @media ${(p) => p.theme.breakpoints.tablet} {
    padding: 16px;
  }
`;

export const ModalAddOnServicesContainer = styled(ModalContentContainer)`
  .approvalLimit {
    height: 44px;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: ${(p) => p.theme.colors.shade0};
  }

  .virtualCard {
    display: flex;
    gap: 8px;
    padding: 8px;
    flex-direction: column;
  }
  .templateCard {
    display: flex;
    gap: 16px;
    flex-direction: column;
    .cardImageList {
      position: relative;
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: center;
      height: 220px;
      gap: 16px;
      .slickItem {
        width: 100%;
        max-width: 300px;
        @media ${(p) => p.theme.breakpoints.mobile} {
          max-width: 64%;
        }
      }
      .icon {
        background-color: ${(p) => p.theme.colors.shade0};
      }
      .left {
        transform: rotate(180deg);
      }
    }
  }
`;
export const ModalCardDetailContainer = styled(ModalContentContainer)`
  max-height: 90vh;
  overflow: auto;
  -ms-overflow-style: none; /* Internet Explorer 10+ */
  scrollbar-width: none; /* Firefox */
  padding-top: 24px;

  @media ${(p) => p.theme.breakpoints.tablet} {
    padding-bottom: 0px;
  }

  .alertContainer {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }
  .detailContainer {
    display: flex;
    flex-direction: column;
    gap: 24px;
    .items {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }

    ul {
      margin: initial;
      padding-left: 40px; /* padding-left mặc định của ul */
      list-style-type: disc; /* bullet mặc định */
      li {
        margin: initial;
        padding: initial;
        list-style-type: disc;
      }
    }
  }
  .scroll {
    height: 100%;
    overflow: auto;
  }
`;

export const TabSelectContainer = styled(Box)`
  display: flex;
  overflow: hidden;
  border-radius: 50px;
  background-color: ${(p) => p.theme.colors.shade0};

  .tabItem {
    flex: 1;
    height: 44px;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 50px;
    cursor: pointer;
    &.active {
      background-color: ${(p) => p.theme.colors.neutral};
      span {
        color: ${(p) => p.theme.colors.white};
      }
    }
  }
`;

export const BodyDetailContainer = styled(Box)`
  height: 100%;
  padding: 24px;
  display: flex;
  flex-direction: column;
  gap: ${({ gap = 16 }) => gap}px;
  background-color: ${({ theme, $color }) =>
    $color
      ? theme.colors[$color]
        ? theme.colors[$color]
        : $color
      : theme.colors.white};
  @media ${({ theme }) => theme.breakpoints.tablet} {
    padding: 16px;
  }
`;
