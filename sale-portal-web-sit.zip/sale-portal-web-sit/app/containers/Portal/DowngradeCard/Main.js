import { ApplicationName } from "@components/Detail";
import TabsWithTransition from "@components/TabsWithTransition";

import BestMatchCard from "./components/BestMatchCard";
import CardList from "./components/CardList";
import AddOnServices from "./components/Popup/AddOnServices";
import CardDetail from "./components/Popup/CardDetail";
import useLogic from "./hook";
import { DowngradeCardContainer } from "./styles";

function Main() {
  const {
    appId,
    matchCardList,
    tabView,
    finalApprovedLimit,
    listCardDraft,
    setTabView,
  } = useLogic();

  const tabData = [
    {
      label: "Chọn thẻ phù hợp nhất",
      props: { matchCardList, setTabView, finalApprovedLimit },
      content: (props) => <BestMatchCard {...props} />,
    },
    {
      label: "Danh sách thẻ",
      props: { matchCardList },
      content: (props) => <CardList {...props} />,
    },
  ];

  return (
    <DowngradeCardContainer>
      <ApplicationName name={`Hồ sơ: ${appId || ""}`} />
      <TabsWithTransition
        className="tab"
        tabs={tabData}
        hiddenTabHeader
        activeTab={tabView}
      />
      <AddOnServices
        appId={appId}
        finalApprovedLimit={finalApprovedLimit}
        listCardDraft={listCardDraft}
      />
      <CardDetail />
    </DowngradeCardContainer>
  );
}

export default Main;
