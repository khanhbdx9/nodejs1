import get from "lodash/get";

export function getSelectedCardFormValues(appId, cardSelected) {
  return {
    appId: appId,
    cardId: get(cardSelected, "card_id", ""),
    cardDesignCode: get(
      get(cardSelected, "card_design_infos", [])[0],
      "templateCode",
      ""
    ),
    glpNumber: get(cardSelected, "", ""),
    virtualCard: get(cardSelected, "physical_card") === "Y",
    virtualCardLimit: get(cardSelected, "physical_card_limit"),
  };
}
