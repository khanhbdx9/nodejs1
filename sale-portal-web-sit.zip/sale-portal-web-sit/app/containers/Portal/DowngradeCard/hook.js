import { detailByIdAction } from "@App/actions";
import { TOKEN_KEY } from "@utils/constants";
import { useOneState } from "@utils/hooks/useRedux";
import useShallowEqualSelector from "@utils/hooks/useShallowEqualSelector";
import KEYS from "@utils/injectKey";
import SessionStorageService from "@utils/storage/session";
import { jwtDecode } from "jwt-decode";
import get from "lodash/get";
import { useState, useEffect } from "react";
import { useDispatch } from "react-redux";

import { getMatchCardAction } from "./store/actions";
import { TAB_SCREEN } from "./store/constants";

const useLogic = () => {
  const dispatch = useDispatch();
  const tokenParse = jwtDecode(SessionStorageService.getItem(TOKEN_KEY));
  const [tabView, setTabView] = useState(TAB_SCREEN.cardSelect);
  const appId = get(tokenParse, "appId", "");

  const detail = useOneState(KEYS.GLOBAL, "detail");

  const { matchCardList = [] } = useShallowEqualSelector(KEYS.DOWNGRADE_CARD, [
    "matchCardList",
  ]);

  useEffect(() => {
    const timerId = setTimeout(() => {
      dispatch(detailByIdAction({ id: appId }));
      dispatch(getMatchCardAction());
    }, 0);

    return () => {
      clearTimeout(timerId);
    };
  }, []);

  return {
    appId,
    tabView,
    matchCardList,
    finalApprovedLimit: get(detail, "finalApprovedLimit", "0"),
    listCardDraft: get(detail, "listCardDraft", []),
    setTabView,
  };
};

export default useLogic;
