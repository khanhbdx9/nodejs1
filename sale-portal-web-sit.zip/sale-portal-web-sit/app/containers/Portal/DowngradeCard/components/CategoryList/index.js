import { Text } from "@components/Styled/Title";
import Box from "@mui/material/Box";
import isArray from "lodash/isArray";
import PropTypes from "prop-types";
import { useEffect } from "react";

import { CategoryListContainer } from "../../styles";

function CategoryList({ active, onChange, data = [] }) {
  useEffect(() => {
    if (active) {
      const element = document.getElementById(active);
      if (element) {
        element.scrollIntoView({
          behavior: "smooth",
          inline: "center",
          block: "center",
        });
      }
    }
  }, [active]);

  const onHandleItemClick = (e, item, index) => {
    const element = document.getElementById(item);
    if (element) {
      element.scrollIntoView({
        behavior: "smooth",
        inline: "center",
        block: "center",
      });
    }
    onChange && onChange({ id: item.id, index });
  };

  return (
    <CategoryListContainer>
      {isArray(data) &&
        data.map((item, index) => {
          return (
            <Box
              key={item.id}
              id={item.id}
              className={`item ${active === item.id && "active"}`}
              onClick={(e) => onHandleItemClick(e, item, index)}
            >
              {item.icon && (
                <img
                  src={item.icon}
                  alt="benefit-icon"
                  width={20}
                  height={20}
                />
              )}
              <Text $size={14} $color="neutral">
                {item.name}
              </Text>
            </Box>
          );
        })}
    </CategoryListContainer>
  );
}

CategoryList.propTypes = {
  active: PropTypes.string,
  onChange: PropTypes.func,
  data: PropTypes.array,
};

export default CategoryList;
