import { GroupBox } from "@components/Detail";
import EmptyFilter from "@components/EmptyFilter";
import { Text, Link } from "@components/Styled/Title";
import Box from "@mui/material/Box";
import { formatNumber } from "@utils/helpers";
import isArray from "lodash/isArray";
import size from "lodash/size";
import PropTypes from "prop-types";

import { TAB_SCREEN } from "../../store/constants";
import {
  ButtonCardList,
  CardListContainer,
  BodyDetailContainer,
} from "../../styles";
import CardItem from "../CardItem";

function BestMatchCard({
  setTabView,
  matchCardList,
  finalApprovedLimit = "0",
}) {
  return (
    <BodyDetailContainer>
      <GroupBox contentPadding="16px">
        <Text>
          Thẻ mà Quý khách hàng lựa chọn trước đó không phù hợp, vui lòng lựa
          chọn lại loại thẻ như ở dưới. Với hạn mức:{" "}
          {finalApprovedLimit && (
            <Text $color="lightGreen">
              {formatNumber(finalApprovedLimit)} VNĐ
            </Text>
          )}
        </Text>
      </GroupBox>
      <ButtonCardList>
        <Text $color="neutral" $align="center">
          Đây là danh sách thẻ phù hợp nhất với bạn
        </Text>
      </ButtonCardList>
      <CardListContainer>
        {isArray(matchCardList) &&
          matchCardList.slice(0, 2).map((item) => {
            return (
              <Box key={item.id}>
                <CardItem data={item} />
              </Box>
            );
          })}
        {!size(matchCardList) && (
          <EmptyFilter description="Không có thẻ nào phù hợp" />
        )}
      </CardListContainer>
      <ButtonCardList>
        <Link
          color="neutral"
          align="center"
          onClick={() => setTabView(TAB_SCREEN.cardList)}
        >
          Danh sách thẻ
        </Link>
      </ButtonCardList>
    </BodyDetailContainer>
  );
}

BestMatchCard.propTypes = {
  matchCardList: PropTypes.array,
  setTabView: PropTypes.func,
  finalApprovedLimit: PropTypes.string,
};

export default BestMatchCard;
