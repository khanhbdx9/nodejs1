import Title, { Text } from "@components/Styled/Title";
import Box from "@mui/material/Box";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import { formatNumber } from "@utils/helpers";
import PropTypes from "prop-types";
import { memo } from "react";

function VirtualCard({ checked, onChange, limit = "0" }) {
  return (
    <Box className="virtualCard">
      <Title>Thẻ phi vật lý</Title>
      <FormControlLabel
        control={
          <Checkbox
            checked={checked}
            onChange={(e) => {
              onChange({
                virtualCard: e.target.checked,
              });
            }}
          />
        }
        label={<Title size={16}>Đăng ký thẻ phi vật lý</Title>}
      />
      <Text $weight={500} $size={14} $color="neutral">
        Hạn mức thẻ phi vật lý: {formatNumber(limit)} VNĐ
      </Text>
    </Box>
  );
}

VirtualCard.propTypes = {
  checked: PropTypes.bool,
  onChange: PropTypes.func,
  limit: PropTypes.string,
};

export default memo(VirtualCard);
