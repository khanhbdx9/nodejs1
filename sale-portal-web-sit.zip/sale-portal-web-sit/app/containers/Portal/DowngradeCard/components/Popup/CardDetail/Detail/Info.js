import { IcBenefit } from "@assets/icons";
import AppImage from "@components/AppImage";
import { CollapseBox } from "@components/Detail";
import { Text } from "@components/Styled/Title";
import Box from "@mui/material/Box";
import Stack from '@mui/material/Stack'
import PropTypes from "prop-types";

function Info({ data = [] }) {
  return (
    <Box>
      {Array.isArray(data) &&
        data.map((item) => {
          return (
            <CollapseBox
              key={item?.title}
              background="white"
              contentClass="items"
              hideDivider
              title={
                <Stack direction="row" spacing={0.5}>
                  <AppImage 
                    src={IcBenefit} 
                    alt="Ic Benefit" 
                    width={22}
                    height={22}
                    style={{ transform: 'unset' }}
                  />
                  <Text $color="neutral">{item?.title || ''}</Text>
                </Stack>
              }
            >
              <Text $color="neutral01" dangerouslySetInnerHTML={{__html: item?.body || ''}}/>
            </CollapseBox>
          );
        })}
    </Box>
  );
}

Info.propTypes = {
  data: PropTypes.arrayOf(
    PropTypes.shape({
      title: PropTypes.string,
      body: PropTypes.string,
    })
  ),
};

export default Info;
