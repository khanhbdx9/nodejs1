import { GroupBox } from "@components/Detail";
import { Link, Text } from "@components/Styled/Title";
import Box from "@mui/material/Box";
import PropTypes from "prop-types";

function Alert({ data = "" }) {
  return (
    <>
      {data ? (
        <GroupBox contentPadding="16px" contentClass="alertContainer">
          <Link weight={600}>Lưu ý</Link>
          <Box>
            <Text $color="neutral">{data}</Text>
          </Box>
        </GroupBox>
      ) : (
        <></>
      )}
    </>
  );
}

Alert.propTypes = {
  data: PropTypes.string,
};

export default Alert;
