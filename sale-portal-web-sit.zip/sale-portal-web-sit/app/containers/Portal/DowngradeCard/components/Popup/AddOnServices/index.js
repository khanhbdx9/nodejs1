import AppButton from "@components/AppButton";
import ModalContainer from "@components/Modal/ModalContainer";
import { ActionContainer } from "@components/Styled/Form";
import Title from "@components/Styled/Title";
import Box from "@mui/material/Box";
import { formatNumber } from "@utils/helpers";
import useShallowEqualSelector from "@utils/hooks/useShallowEqualSelector";
import KEYS from "@utils/injectKey";
import get from "lodash/get";
import size from "lodash/size";
import PropTypes from "prop-types";
import { useCallback, useState, useEffect } from "react";
import { useDispatch } from "react-redux";

import TemplateCard from "./TemplateCard";
import VirtualCard from "./VirtualCard";
import { getSelectedCardFormValues } from "../../../helpers";
import {
  setToggleModalSelectedCard,
  submitSelectedCardAction,
} from "../../../store/actions";
import { SUBMIT_ACTION } from "../../../store/constants";
import { ModalAddOnServicesContainer } from "../../../styles";

function AddOnServices({
  appId = "",
  finalApprovedLimit = "0",
  listCardDraft = [],
}) {
  const dispatch = useDispatch();
  const { isOpenModalSelectedCard, cardSelected } = useShallowEqualSelector(
    KEYS.DOWNGRADE_CARD,
    ["isOpenModalSelectedCard", "cardSelected"]
  );
  const [formData, setFormData] = useState({});

  useEffect(() => {
    if (size(cardSelected)) {
      let initFormValue = getSelectedCardFormValues(appId, cardSelected);
      // check draft card
      let defaultFormValues = (listCardDraft || []).find(
        (item) => item.cardId === get(cardSelected, "card_id")
      );
      if (defaultFormValues) {
        initFormValue = { ...initFormValue, ...defaultFormValues };
      }
      setFormData(initFormValue);
    }
  }, [cardSelected, listCardDraft]);

  const onChangeFormData = useCallback(
    (value) => {
      setFormData((prev) => ({ ...prev, ...value }));
    },
    [setFormData]
  );

  const onSubmit = (action) => {
    dispatch(submitSelectedCardAction({ ...formData, action }));
  };

  return (
    <ModalContainer
      position="center"
      open={isOpenModalSelectedCard}
      handleClose={() => dispatch(setToggleModalSelectedCard())}
    >
      <ModalAddOnServicesContainer>
        <Title>Đăng ký dịch vụ bổ sung</Title>
        <Box className="approvalLimit">
          <Title>Hạn mức phê duyệt: </Title>&nbsp;
          <Title $color="lightGreen">
            {formatNumber(finalApprovedLimit)} VNĐ
          </Title>
        </Box>
        <VirtualCard
          limit={get(formData, "virtualCardLimit")}
          checked={get(formData, "virtualCard")}
          onChange={onChangeFormData}
        />
        <TemplateCard
          selected={get(formData, "cardDesignCode")}
          data={get(cardSelected, "card_design_infos", [])}
          onChange={onChangeFormData}
        />
        <ActionContainer $full={true}>
          <AppButton
            variant="outlinedSecondary"
            label="Lưu"
            onClick={() => onSubmit(SUBMIT_ACTION.save)}
          />
          <AppButton
            label="Tiếp tục"
            onClick={() => onSubmit(SUBMIT_ACTION.continue)}
          />
        </ActionContainer>
      </ModalAddOnServicesContainer>
    </ModalContainer>
  );
}

AddOnServices.propTypes = {
  appId: PropTypes.any,
  listCardDraft: PropTypes.array,
  finalApprovedLimit: PropTypes.string,
};

export default AddOnServices;
