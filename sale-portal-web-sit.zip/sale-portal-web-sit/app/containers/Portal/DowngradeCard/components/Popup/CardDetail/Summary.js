import { IcBenefit } from "@assets/icons";
import AppImage from "@components/AppImage";
import Title, { Text } from "@components/Styled/Title";
import Box from "@mui/material/Box";
import get from "lodash/get";
import PropTypes from "prop-types";
import { useMemo } from "react";

import { BenefitContainer, SummaryContainer } from "../../../styles";

function Summary({ data }) {

  const cardDesignInfos = data?.card_design_infos || [];
  const urlCard = useMemo(() => {
    const defaultCard = cardDesignInfos.find(
      (item) => String(item.templateCode).toUpperCase() === "DEFAULT"
    );
    return get(defaultCard, "url", "");
  }, [cardDesignInfos]);

  return (
    <SummaryContainer>
      <Box className="cardImage">
        <AppImage
          src={urlCard}
          alt={get(data, "name", "card")}
          width={135}
          height={217}
          isOrientation
        />
        <Box className="cardNameMobile">
          <Text $align="center" $size={14} $color="neutral">
            Thẻ tín dụng
          </Text>
          <Title $align="center">{get(data, "name")}</Title>
        </Box>
      </Box>
      <Box className="cardDetail">
        <Box className="cardName">
          <Text $color="neutral">Thẻ tín dụng</Text>
          <Title>{get(data, "name")}</Title>
        </Box>
        <BenefitContainer sx={{ padding: "16px 0px" }}>
          {(get(data, "highlights", []) || []).map((item) => {
            return (
              <Box className="item" key={item}>
                <img src={IcBenefit} width={22} height={22} />
                <Text $color="neutral">{String(item).replace("-", "")}</Text>
              </Box>
            );
          })}
        </BenefitContainer>
      </Box>
    </SummaryContainer>
  );
}

Summary.propTypes = {
  data: PropTypes.object,
};

export default Summary;
