import { IcArrowRight } from "@assets/icons";
import AppImage from "@components/AppImage";
import Title from "@components/Styled/Title";
import { IconButton } from "@mui/material";
import Box from "@mui/material/Box";
import { isArray } from "lodash";
import get from "lodash/get";
import size from "lodash/size";
import PropTypes from "prop-types";
import { memo, useRef } from "react";
import Slider from "react-slick";

import CategoryList from "../../CategoryList";


const settings = {
  arrows: false,
  dots: false,
  infinite: false,
  draggable: false,
};

function TemplateCard({ selected, data = [], onChange }) {
  const slick = useRef(null);

  const templateCardCategory =
    isArray(data) &&
    (data || []).map((item) => ({
      id: item.templateCode,
      name: item.templateName,
    }));

  const initSlideActive = data
    ? data.findIndex((item) => item.templateCode === selected)
    : 0;

  const handleOnSlideChange = (index) => {
    onChange({
      cardDesignCode: get(data[index], "templateCode"),
    });
  };

  const prev = () => {
    slick.current.slickPrev();
  };

  const next = () => {
    slick.current.slickNext();
  };

  return (
    <Box className="templateCard">
      <Title>Chọn thiết kế thẻ</Title>
      <CategoryList
        active={selected}
        data={templateCardCategory}
        onChange={({ index }) => {
          slick.current.slickGoTo(index);
        }}
      />
      <Box className="cardImageList">
        {size(data) > 1 && (
          <IconButton className="icon left" onClick={prev}>
            <AppImage src={IcArrowRight} alt="prev" width={24} height={24} />
          </IconButton>
        )}
        <Box className="slickItem">
          <Slider
            ref={slick}
            {...settings}
            initialSlide={initSlideActive}
            afterChange={handleOnSlideChange}
          >
            {data.map((card, index) => (
              <Box key={index} sx={{ padding: "0px 3px" }}>
                <AppImage
                  style={{ margin: "0 auto" }}
                  src={get(card, "url")}
                  alt="card"
                  width={"auto"}
                  height={188}
                />
              </Box>
            ))}
          </Slider>
        </Box>
        {size(data) > 1 && (
          <IconButton className="icon right" onClick={next}>
            <AppImage src={IcArrowRight} alt="prev" width={24} height={24} />
          </IconButton>
        )}
      </Box>
    </Box>
  );
}

TemplateCard.propTypes = {
  data: PropTypes.array,
  onChange: PropTypes.func,
  selected: PropTypes.string,
};

export default memo(TemplateCard);
