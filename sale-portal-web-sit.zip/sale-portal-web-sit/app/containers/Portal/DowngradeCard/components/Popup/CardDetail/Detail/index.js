import { Text } from "@components/Styled/Title";
import TabsWithTransition from "@components/TabsWithTransition";
import Box from "@mui/material/Box";
import PropTypes from "prop-types";
import { useState } from "react";

import Features from "./Features";
import Info from "./Info";
import Offer from "./Offer";
import { TabSelectContainer } from "../../../../styles";

function Detail({ detail = {} }) {
  const [tabView, setTabView] = useState(0);

  const tabData = [
    {
      label: "Tính năng",
      props: { data: detail.features },
      content: (props) => <Features {...props} />,
    },
    {
      label: "Ưu đãi",
      props: { data: detail.endows },
      content: (props) => <Offer {...props} />,
    },
    {
      label: "Thông tin",
      props: { data: detail.infos },
      content: (props) => <Info {...props} />,
    },
  ];

  return (
    <Box className="detailContainer">
      <TabSelectContainer>
        {tabData.map((item, index) => {
          return (
            <Box
              key={index}
              className={`tabItem ${tabView === index ? "active" : ""}`}
              onClick={() => setTabView(index)}
            >
              <Text>{item.label}</Text>
            </Box>
          );
        })}
      </TabSelectContainer>
      <TabsWithTransition tabs={tabData} hiddenTabHeader activeTab={tabView} />
    </Box>
  );
}

Detail.propTypes = {
  detail: PropTypes.object,
};

export default Detail;
