import AppButton from "@components/AppButton";
import ModalContainer from "@components/Modal/ModalContainer";
import { ActionContainer } from "@components/Styled/Form";
import Title from "@components/Styled/Title";
import useShallowEqualSelector from "@utils/hooks/useShallowEqualSelector";
import KEYS from "@utils/injectKey";
import get from "lodash/get";
import { useDispatch } from "react-redux";

import Alert from "./Alert";
import Detail from "./Detail";
import Summary from "./Summary";
import {
  setToggleModalCardDetail,
  setToggleModalSelectedCard,
} from "../../../store/actions";
import { ModalCardDetailContainer } from "../../../styles";

function CardDetail() {
  const dispatch = useDispatch();
  const { isOpenModalCardDetail, cardSelected } = useShallowEqualSelector(
    KEYS.DOWNGRADE_CARD,
    ["isOpenModalCardDetail", "cardSelected"]
  );

  return (
    <ModalContainer
      position="center"
      open={isOpenModalCardDetail}
      handleClose={() => dispatch(setToggleModalCardDetail())}
      paddingContent={16}
    >
      <Title style={{ alignSelf: "flex-start" }}>Chi tiết thẻ</Title>
      <ModalCardDetailContainer>
        <Summary
          data={{
            name: get(cardSelected, "name", ""),
            highlights: get(cardSelected, "highlights", []),
            card_design_infos: get(cardSelected, "card_design_infos", []),
          }}
        />
        <Detail
          detail={{
            features: get(cardSelected, "features", []),
            endows: get(cardSelected, "endows", []),
            infos: get(cardSelected, "infos", []),
          }}
        />
        <Alert data={get(cardSelected, "note", "")} />
        <ActionContainer
          $full={true}
          sx={{ position: "sticky", bottom: "0px" }}
        >
          <AppButton
            label="Chọn thẻ này"
            onClick={() => {
              dispatch(setToggleModalSelectedCard({ type: true }));
              dispatch(setToggleModalCardDetail());
            }}
          />
        </ActionContainer>
      </ModalCardDetailContainer>
    </ModalContainer>
  );
}

export default CardDetail;
