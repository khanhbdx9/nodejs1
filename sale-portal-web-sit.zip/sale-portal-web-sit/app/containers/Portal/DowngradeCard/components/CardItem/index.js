import { IcBenefit } from "@assets/icons";
import AppButton from "@components/AppButton";
import AppImage from "@components/AppImage";
import Title, { Text } from "@components/Styled/Title";
import Box from "@mui/material/Box";
import get from "lodash/get";
import PropTypes from "prop-types";
import { useMemo } from "react";
import { useDispatch } from "react-redux";

import {
  setToggleModalCardDetail,
  setToggleModalSelectedCard,
} from "../../store/actions";
import {
  ActionContainer,
  BenefitContainer,
  CardItemContainer,
} from "../../styles";

function CardItem({ data }) {
  const dispatch = useDispatch();
  const cardDesignInfos = data?.card_design_infos || [];

  const urlCard = useMemo(() => {
    const defaultCard = cardDesignInfos.find(
      (item) => String(item.templateCode).toUpperCase() === "DEFAULT"
    );
    return get(defaultCard, "url", "");
  }, [cardDesignInfos]);

  return (
    <CardItemContainer className="cardImageContainer">
      <Box className="cardImage">
        <AppImage
          src={urlCard}
          isOrientation
          alt={get(data, "name", "card")}
          height={135} // ảnh luôn luôn set là ảnh ngang sau đó sẽ kiểm tra và tự chuyển lại dọc
          width={217}
        />
        <Title $align="center">{get(data, "name")}</Title>
      </Box>
      <Box className="cardDetail">
        <Box className="cardName">
          <Text $color="neutral">Thẻ tín dụng</Text>
          <Title>{get(data, "name")}</Title>
        </Box>
        <BenefitContainer>
          {(get(data, "highlights", []) || []).map((item, index) => {
            return (
              <Box className="item" key={index}>
                <AppImage 
                  src={IcBenefit} 
                  alt="Ic Benefit" 
                  width={22}
                  height={22}
                  style={{ transform: 'unset', minWidth: 22 }}
                />
                <Text $color="neutral">{item}</Text>
              </Box>
            );
          })}
        </BenefitContainer>
        <ActionContainer>
          <AppButton
            variant="outlinedSecondary"
            label="Chi tiết"
            onClick={() =>
              dispatch(setToggleModalCardDetail({ type: true, data }))
            }
          />
          <AppButton
            variant="outlined"
            label="Chọn thẻ này"
            onClick={() =>
              dispatch(setToggleModalSelectedCard({ type: true, data }))
            }
          />
        </ActionContainer>
      </Box>
    </CardItemContainer>
  );
}

CardItem.propTypes = {
  data: PropTypes.object,
};

export default CardItem;
