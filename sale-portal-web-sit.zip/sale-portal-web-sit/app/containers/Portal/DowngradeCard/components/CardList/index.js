import EmptyFilter from "@components/EmptyFilter";
import useShallowEqualSelector from "@utils/hooks/useShallowEqualSelector";
import KEYS from "@utils/injectKey";
import get from "lodash/get";
import isArray from "lodash/isArray";
import size from "lodash/size";
import uniq from "lodash/uniq";
import PropTypes from "prop-types";
import React, { useEffect, useMemo, useState } from "react";
import { useDispatch } from "react-redux";

import { getListBenefitsAction } from "../../store/actions";
import { CardListContainer, BodyDetailContainer } from "../../styles";
import CardItem from "../CardItem";
import CategoryList from "../CategoryList";

const ALL_OPTION = "all";
function CardList({ matchCardList }) {
  const dispatch = useDispatch();
  const [isBenefitActive, setBenefitActive] = useState(ALL_OPTION);
  const { benefitsList = [] } = useShallowEqualSelector(KEYS.DOWNGRADE_CARD, [
    "benefitsList",
  ]);

  useEffect(() => {
    setTimeout(() => {
      dispatch(getListBenefitsAction());
    }, 100);
  }, []);

  const benefitListOptions = useMemo(() => {
    const ids = matchCardList.map((item) => get(item, "benefit_ids", []));
    const uniqIds = uniq(ids.flat());
    return benefitsList
      .map((item) => ({
        id: item.id,
        name: item.name,
        icon: item.url_image,
      }))
      .filter((item) => uniqIds.includes(item.id));
  }, [benefitsList, matchCardList]);

  const listCardByBenefit = useMemo(() => {
    let listCardFiltered = matchCardList;
    if (isBenefitActive !== ALL_OPTION) {
      listCardFiltered = matchCardList.filter((item) =>
        get(item, "benefit_ids", []).includes(isBenefitActive)
      );
    }
    return listCardFiltered;
  }, [matchCardList, isBenefitActive]);

  return (
    <BodyDetailContainer $color="shade0" gap={3}>
      {!!size(benefitListOptions) && (
        <CategoryList
          data={[{ id: ALL_OPTION, name: "Tất cả" }, ...benefitListOptions]}
          active={isBenefitActive}
          onChange={({ id }) => {
            setBenefitActive(id);
          }}
        />
      )}
      <CardListContainer className="list" gap={3}>
        {isArray(listCardByBenefit) &&
          !!size(listCardByBenefit) &&
          listCardByBenefit.map((item) => {
            return (
              <React.Fragment key={item.id}>
                <CardItem data={item} />
              </React.Fragment>
            );
          })}
        {!size(listCardByBenefit) && (
          <EmptyFilter description="Danh sách hiện tại đang trống" />
        )}
      </CardListContainer>
    </BodyDetailContainer>
  );
}

CardList.propTypes = {
  matchCardList: PropTypes.array,
};

export default CardList;
