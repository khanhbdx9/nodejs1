import { setLoadingAction, detailByIdAction } from "@App/actions";
import ROUTE from "@routers/constants";
import { responseCode, TOKEN_KEY } from "@utils/constants";
import history from "@utils/history";
import { MESSAGE_SYSTEM } from "@utils/message";
import { URL, apiRequest } from "@utils/services/api";
import SessionStorageService from "@utils/storage/session";
import get from "lodash/get";
import { toast } from "react-toastify";
import { all, call, put, takeLatest } from "redux-saga/effects";

import {
  getListBenefitsAction,
  getMatchCardAction,
  setToggleModalSelectedCard,
  submitSelectedCardAction,
} from "./actions";
import { SUBMIT_ACTION } from "./constants";

function* submitSelectedCardSaga({ payload }) {
  try {
    const request = {
      url: URL.unsecure.setSelectedCard,
      data: payload,
    };

    yield put(setLoadingAction(true));
    yield put(submitSelectedCardAction.request());

    const respond = yield call(apiRequest.post, request);
    const { meta, data } = get(respond, "data") || {};

    if (get(meta, "code") === responseCode["IL-200"] && get(data, "token")) {
      yield put(detailByIdAction({ id: payload.appId }));

      if (payload.action === SUBMIT_ACTION.save) {
        toast.success(MESSAGE_SYSTEM.saveTemplateCard);
        return;
      }
      
      // Set token
      SessionStorageService.setToken(TOKEN_KEY, data.token);
      history.push(
        `${ROUTE.portal.ApplicationDetail.replace(":id", payload.appId)}?dg=active`
      );
    } else {
      throw {};
    }
  } catch (error) {
    toast.error(get(error, "meta.message", MESSAGE_SYSTEM.default));
  } finally {
    yield put(setToggleModalSelectedCard());
    yield put(setLoadingAction(false));
  }
}

function* getMatchCardSaga() {
  try {
    yield put(setLoadingAction(true));
    yield put(getMatchCardAction.request());

    const request = {
      url: URL.unsecure.getMatchCardList,
    };

    const respond = yield call(apiRequest.get, request);
    const { data, meta } = get(respond, "data") || {};
    if (get(meta, "code") === responseCode["IL-200"] && data) {
      yield put(getMatchCardAction.success({ items: data }));
    } else {
      throw {};
    }
  } catch (error) {
    yield put(getMatchCardAction.failure());
    toast.error(get(error, "meta.message", MESSAGE_SYSTEM.default));
  } finally {
    yield put(setLoadingAction(false));
  }
}

function* getListBenefitsSaga() {
  try {
    yield put(setLoadingAction(true));
    yield put(getListBenefitsAction.request());

    const request = {
      url: URL.card.getListBenefits,
      params: { page: 0, size: 9999 },
    };

    const respond = yield call(apiRequest.get, request);
    const { data, meta } = get(respond, "data") || {};
    if (get(meta, "code") === responseCode["IL-200"] && data) {
      yield put(getListBenefitsAction.success({ items: data }));
    } else {
      throw {};
    }
  } catch (error) {
    yield put(getListBenefitsAction.failure());
    toast.error(get(error, "meta.message", MESSAGE_SYSTEM.default));
  } finally {
    yield put(setLoadingAction(false));
  }
}

export default function* watchAll() {
  yield all([
    takeLatest(getMatchCardAction.TRIGGER, getMatchCardSaga),
    takeLatest(submitSelectedCardAction.TRIGGER, submitSelectedCardSaga),
    takeLatest(getListBenefitsAction.TRIGGER, getListBenefitsSaga)
  ]);
}
