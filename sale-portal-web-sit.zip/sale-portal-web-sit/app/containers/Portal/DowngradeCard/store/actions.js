import { createRoutine } from "redux-saga-routines";

import {
  GET_SELECTED_CARD,
  GET_MATCH_CARD,
  SET_TOGGLE_MODAL_SELECTED_CARD,
  GET_LIST_BENEFITS,
  SET_TOGGLE_MODAL_CARD_DETAIL,
} from "./constants";

export const submitSelectedCardAction = createRoutine(GET_SELECTED_CARD);
export const getMatchCardAction = createRoutine(GET_MATCH_CARD);
export const getListBenefitsAction = createRoutine(GET_LIST_BENEFITS);
export const setToggleModalSelectedCard = (payload) => {
  return {
    type: SET_TOGGLE_MODAL_SELECTED_CARD,
    payload,
  };
};
export const setToggleModalCardDetail = (payload) => {
  return {
    type: SET_TOGGLE_MODAL_CARD_DETAIL,
    payload,
  };
};
