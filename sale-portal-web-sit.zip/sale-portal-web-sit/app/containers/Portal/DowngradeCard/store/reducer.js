import { produce } from "immer";
import get from "lodash/get";

import {
  getListBenefitsAction,
  getMatchCardAction,
  submitSelectedCardAction,
} from "./actions";
import {
  SET_TOGGLE_MODAL_CARD_DETAIL,
  SET_TOGGLE_MODAL_SELECTED_CARD,
} from "./constants";

export const initialState = {
  cardSelected: {},
  matchCardList: [],
  benefitsList: [],
  isOpenModalSelectedCard: false,
  isOpenModalCardDetail: false,
};

 
const OtpReducer = (state = initialState, action) =>
  produce(state, (draft) => {
    switch (action.type) {
      case submitSelectedCardAction.REQUEST: {
        break;
      }
      case submitSelectedCardAction.SUCCESS: {
        break;
      }
      case submitSelectedCardAction.FAILURE: {
        break;
      }
      case getMatchCardAction.REQUEST: {
        draft.matchCardList = [];
        break;
      }
      case getMatchCardAction.SUCCESS: {
        draft.matchCardList = get(action.payload, "items");
        break;
      }
      case getMatchCardAction.FAILURE: {
        draft.matchCardList = [];
        break;
      }

      // benefit
      case getListBenefitsAction.REQUEST: {
        draft.benefitsList = [];
        break;
      }
      case getListBenefitsAction.SUCCESS: {
        draft.benefitsList = get(action, "payload.items");
        break;
      }
      case getListBenefitsAction.FAILURE: {
        draft.benefitsList = [];
        break;
      }

      // selectedCard
      case SET_TOGGLE_MODAL_SELECTED_CARD: {
        draft.isOpenModalSelectedCard = get(action, "payload.type", false);
        draft.cardSelected = get(action, "payload.data", {}) || {};
        break;
      }
      // card detail
      case SET_TOGGLE_MODAL_CARD_DETAIL: {
        draft.isOpenModalCardDetail = get(action, "payload.type", false);
        draft.cardSelected = get(action, "payload.data", {}) || {};
        break;
      }
    }
  });

export default OtpReducer;
