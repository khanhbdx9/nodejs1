export const GET_SELECTED_CARD = "app/GET_SELECTED_CARD";
export const GET_MATCH_CARD = "app/GET_MATCH_CARD";
export const SET_TOGGLE_MODAL_SELECTED_CARD =
  "app/SET_TOGGLE_MODAL_SELECTED_CARD";
export const SET_TOGGLE_MODAL_CARD_DETAIL = "app/SET_TOGGLE_MODAL_CARD_DETAIL";
export const GET_LIST_BENEFITS = "app/GET_LIST_BENEFITS";
export const TAB_SCREEN = {
  cardSelect: 0,
  cardList: 1,
};
export const SUBMIT_ACTION = {
  save: "SAVE",
  continue: "CONTINUE",
};
