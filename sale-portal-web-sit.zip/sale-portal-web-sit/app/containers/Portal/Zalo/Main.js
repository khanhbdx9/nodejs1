import AppButton from "@components/AppButton";
import NewFeature from "@components/NewFeature"
import VPB_COLOR from '@ThemeProvider/colors';
import { useSearchParams } from '@utils/helpers';
import { useDispatchRedux, useOneState } from "@utils/hooks/useRedux";
import KEY from '@utils/injectKey'
import SessionStorageService from "@utils/storage/session";
import { useEffect } from 'react';

import { rqTokenZaloAction } from './store/actions';
import { STATUS } from './store/constants';

const Main = () => {
  SessionStorageService.clear();

  const { id, pk } = useSearchParams();

  const status = useOneState(KEY.ZALO, 'status');

  const rqTokenZalo = useDispatchRedux(rqTokenZaloAction);
  
  const handleRequestZalo = () => rqTokenZalo({ id, token: pk })

  useEffect(()=>{
    if(pk && id) setTimeout(() => handleRequestZalo(), 100)
  }, [id, pk])

  const mess = STATUS[status];

  return <div style={{ flex: 1, background: VPB_COLOR.white }} className="dgrid">
    <NewFeature 
      minHeight="100wv"
      dest={mess?.dest}
      title={mess?.title}
      isHiddenBtn={!mess?.isFail}
      externalBottom={mess?.isRetry && (
        <AppButton 
          label="Thử lại" 
          variant="outlined" 
          style={{ width: 250 }}
          onClick={handleRequestZalo}
        />
      )}
    />
  </div>
}

export default Main;