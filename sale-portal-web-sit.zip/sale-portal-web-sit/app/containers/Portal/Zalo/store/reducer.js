import { produce } from 'immer';

import { rqTokenZaloAction } from './actions';
import { STATUS } from './constants';

export const initialState = {
  branchOpt: [],
  countRetry: 0,

  status: STATUS.REQUEST.key,
};

const ZaloReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case rqTokenZaloAction.REQUEST: {
        draft.status = STATUS.REQUEST.key;
        break;
      }
      case rqTokenZaloAction.SUCCESS: {
        break;
      }
      case rqTokenZaloAction.FAILURE: {
        const countRetry = state.countRetry + 1;
        
        if(countRetry > 3){
          draft.status = STATUS.FAIL.key;
          return
        }

        draft.countRetry = countRetry;
        draft.status = action?.payload?.status || STATUS.FAIL.key;
        break;
      }
    }
  });

export default ZaloReducer;
