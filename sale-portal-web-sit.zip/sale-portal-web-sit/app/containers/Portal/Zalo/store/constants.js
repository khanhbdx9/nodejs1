import KEY from '@utils/injectKey'

export const STATUS = {
  REQUEST: {
    key: 'REQUEST',
    title: 'Hệ Thống Đang Xử Lý',
    dest: 'Chúng tôi rất vui mừng thông báo Hồ Sơ của bạn đang được ngân hàng xử lý. Vui lòng Chờ đợi trong giây lát'
  },
  RETRY: {
    key: 'RETRY',
    isRetry: true,
    title: 'Thông Báo',
    dest: 'Hệ thống chưa lấy được thông tin hồ sơ của bạn. Vui lòng nhấn nút "Thử lại"!'
  },
  FAIL: {
    key: 'FAIL',
    isFail: true,
    title: 'Thông Báo',
    dest: 'Hệ thống chưa tìm được hồ sơ của bạn. Vui lòng đăng nhập lại!'
  }
}

export const REQUEST_TOKEN_ZALO_ACTION = `${KEY.ZALO}/REQUEST_TOKEN_ZALO_ACTION`;
