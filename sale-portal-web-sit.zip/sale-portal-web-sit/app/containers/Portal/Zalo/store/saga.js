import { setLoadingAction } from '@App/actions';
import { setTokenAction } from '@App/actions'
import ROUTE from '@routers/constants';
import { responseCode, TOKEN_KEY } from '@utils/constants';
import history from '@utils/history';
import { URL, apiRequest } from "@utils/services/api";
import SessionStorageService from "@utils/storage/session";
import { all, call, put as dispatch, takeLatest } from 'redux-saga/effects';

import { rqTokenZaloAction } from './actions'
import { STATUS } from './constants';

function* rqTokenZaloSaga(action) {
  try {
    yield dispatch(rqTokenZaloAction.request());

    const { id = '', token = '' } = action.payload;

    SessionStorageService.setItem(TOKEN_KEY, token);

    const payload = {url: URL.unsecure.zns(id)};

    const { data: res = {} } = yield call(apiRequest.get, payload);
    const { data = [], meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        if(!data?.token){
          yield dispatch(rqTokenZaloAction.failure({ status: STATUS.RETRY.key }));
          return
        }

        yield dispatch(setTokenAction({ detail: data.token }));
        
        SessionStorageService.setItem(TOKEN_KEY, `Bearer ${data.token}`);
        history.push(ROUTE.portal.ApplicationDetail.replaceAll(':id', id));
        break;
      }
      default: {
        yield dispatch(rqTokenZaloAction.failure({ status: STATUS.RETRY.key }));
        break;
      }
    }
  } catch (error) {
    if(error?.meta?.fe_code === responseCode['IL-4001']) return

    yield dispatch(rqTokenZaloAction.failure({ status: STATUS.RETRY.key }));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export default function* watchAll() {
  yield all([
    takeLatest(rqTokenZaloAction.TRIGGER, rqTokenZaloSaga),
  ]);
}
