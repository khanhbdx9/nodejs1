import { createRoutine } from 'redux-saga-routines';

import * as KEY_CONSTANT from './constants';

export const rqTokenZaloAction = createRoutine(KEY_CONSTANT.REQUEST_TOKEN_ZALO_ACTION);
