import Skeleton from '@mui/material/Skeleton';
import Stack from '@mui/material/Stack';
import styled from 'styled-components';

const SkeletonContainer = styled(Stack)`
  padding: 24px;
`;

const SkeletonStyled = styled(Skeleton)`
  border-radius: 4px;
`;

const DetailFallback = () => {
  return (
    <SkeletonContainer spacing={2}>
      <SkeletonStyled variant="rectangular" width="100%" height={60} />

      <SkeletonStyled variant="rectangular" width="100%" height={180} />

      <SkeletonStyled variant="rectangular" width="100%" height={407} />

      <Stack spacing={1} direction="row" sx={{ justifyContent: 'end' }}>
        <SkeletonStyled variant="rectangular" width={180} height={48} />
        <SkeletonStyled variant="rectangular" width={180} height={48} />
      </Stack>
      
    </SkeletonContainer>
  );
};

export default DetailFallback;
