import Skeleton from '@mui/material/Skeleton';
import Stack from '@mui/material/Stack';
import PropTypes from 'prop-types';
import styled from 'styled-components';

const SkeletonContainer = styled(Stack)`
  padding: 0px;
`;

const SkeletonStyled = styled(Skeleton)`
  border-radius: 4px;
`;

const ListAppFallback = () => {
  return (
    <SkeletonContainer spacing={2}>
      <Stack spacing={1}>
        <SkeletonStyled animation="wave" variant="rectangular" width="100%" height={146}/>
        <SkeletonStyled animation="wave" variant="rectangular" width="100%" height={146}/>
        <SkeletonStyled animation="wave" variant="rectangular" width="100%" height={146}/>
      </Stack>
    </SkeletonContainer>
  );
};

ListAppFallback.propTypes = {
  isHeader: PropTypes.bool,
};

export default ListAppFallback;
