import { createBrowserHistory } from 'history';
const basename = import.meta.env.VITE_PUBLIC_PATH;
const history = createBrowserHistory({ basename });
export default history;
