/* eslint-disable react-hooks/rules-of-hooks */
import * as deviceDetect from './deviceDetect';

// const useLogicCheckBrowserMobile = () => {
//   return true;
// }

const useLogicCheckBrowserDesktop = () => {
  return true;
}

export default function checkDeviceSupportTS() {
  // if (deviceDetect.platform.any()) {
  //   return useLogicCheckBrowserMobile();
  // }

  return useLogicCheckBrowserDesktop();
}
