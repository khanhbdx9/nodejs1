import { STATUS } from "../../constants";

export default {
  core: {
    ward: `core/v2/public/wards/get-all?status=${STATUS.ACTIVE}`,
    district: `core/v2/public/district?status=${STATUS.ACTIVE}`,
    province: `core/v2/public/province?status=${STATUS.ACTIVE}`,
    deliveryBranch: 'core/v2/public/delivery-branch/find-by-province',
    getWorkingTime: 'core/v2/public/working-time/get-workingTime',
  },
  gateway: {
    settingEkyc: "gateway/v2/public/ocr/setting",
    storageFileDownload: "gateway/v2/public/storage-file/download",
    getFile: `gateway/v2/public/storage-file/get-file`,
    getFileHhb:'gateway/v2/public/storage-file/get-file-hhb'
  },
  unsecure: {
    requestLogin: `/unsecure/v2/public/portal/login`,
    resendOtp: `/unsecure/v2/public/otp/request`,
    verifyOtp: `/unsecure/v2/public/otp/verify`,
    otpConfirmAppInit: (appId) =>
      `/unsecure/v2/public/portal/confirm-init-app/${appId}`,
    getApplication: `/unsecure/v2/public/portal/list`,
    detailByApplicationId: (id) => `/unsecure/v2/public/portal/detail/${id}`,
    kycOcrFront: "unsecure/v2/public/kyc/ocr-front",
    kycOcrBack: "unsecure/v2/public/kyc/ocr-back",
    kycOcrQR: "unsecure/v2/public/kyc/ocr-qr",
    liveness: "unsecure/v2/public/kyc/liveness",
    genConfirmDataPersonal:
      "unsecure/v2/public/portal/gen-confirm-data-personal",
    requestConfirmInitApp: (id) =>
      `unsecure/v2/public/portal/request-confirm-init-app/${id}`,
    resendConfirmInitApp: `unsecure/v2/public/portal/resend-confirm-init-app`,
    detailFlowZalo: (id) => `unsecure/v2/public/portal/detail/zns/${id}`,
    getMatchCardList: `unsecure/v2/public/portal/get-match-card`,
    setSelectedCard: `unsecure/v2/public/portal/selected-card`,
    getListDocument: `unsecure/v2/public/portal/list-document`,
    getTypeDocument: id => `unsecure/v2/public/portal/get-document-for-cus/${id}`,
    zns: (id) => `unsecure/v2/public/portal/zns/${id}`,
    selectedDeliveryCard: `/unsecure/v2/public/portal/selected-delivery-card`,
    genEContract: 'unsecure/v2/public/portal/gen-e-contract',
    genCasa: 'unsecure/v2/public/portal/gen-casa',
    rqEContract: 'unsecure/v2/public/otp/request-e-contract',
    rqConfirmEContract: id => `unsecure/v2/public/portal/request-confirm-e-contract/${id}`,
    confirmEContract: id => `unsecure/v2/public/portal/confirm-e-contract/${id}`,
    cancelAppByCustomer: `unsecure/v2/public/portal/cancel-app-by-customer`,
    cancelCustByCustomer: `unsecure/v2/public/portal/cancel-cust-by-customer`,
    downloadDocument: "unsecure/v2/public/customer-universal/download-document",
    firstPaymentDate: 'unsecure/v2/public/api/application-upl/get-first-monthly-repayment',
    maturityDate: 'unsecure/v2/public/api/application-upl/get-maturity-date',
  },
  card: {
    getListBenefits: `card/v2/public/benefits`,
  },
};
// https://jarvis-api-sit.vpbank.com.vn/unsecure/v2/public/api/application-upl/get-maturity-date?firstMonthlyRepayment=2025-01-01&appId=12345%27