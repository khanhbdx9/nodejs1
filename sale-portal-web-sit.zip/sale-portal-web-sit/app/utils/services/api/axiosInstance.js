import { VERSION, ROOT_URI, API_TIMEOUT } from "@utils/constants";
import { getSupportID } from "@utils/helpers";
import { MESSAGE_SYSTEM } from "@utils/message";
import authService from "@utils/services/authService";
import axios from "axios";
import getLd from "lodash/get";
import { toast } from "react-toastify";

const axiosInstance = axios.create({
  baseURL: ROOT_URI,
  timeout: API_TIMEOUT,
});

axiosInstance.interceptors.request.use(
  (config) => {
    const token = authService.getToken();
    if (token)  config.headers["Authorization"] = token;
    return config;
  },
  (error) => Promise.reject(error)
);

axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    const errResponse = getLd(error, "response") || error;
    if (errResponse) {
      // show error code
      const feCode = getLd(errResponse, "data.meta.fe_code");
      const errorMessage = feCode || getSupportID(JSON.stringify(errResponse));
      document.getElementById(
        "codeError"
      ).innerHTML = `${VERSION} | Err: ${errorMessage}`;

      // error case: 401
      if (error.response.status === 401) {
        toast.error(MESSAGE_SYSTEM.notToken)
        authService.logout();
      }
      
      return Promise.reject(getLd(errResponse, "data") || errResponse);
    } else if (error.request) {
      return Promise.reject({ message: "Không thể kết nối đến máy chủ." });
    } else {
      return Promise.reject({ message: error.message });
    }
  }
);

export default axiosInstance;
