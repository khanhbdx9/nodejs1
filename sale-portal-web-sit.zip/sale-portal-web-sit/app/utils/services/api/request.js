// src/services/apiService.js
import axiosInstance from "./axiosInstance";

const handleRequest = async ({
  url,
  method,
  params,
  data = {},
  config = {},
}) => {
  return axiosInstance({
    url,
    method,
    params,
    data,
    ...config,
  });
};

const apiRequest = {
  get: ({ url, params = {}, config = {} }) => {
    return handleRequest({
      method: "GET",
      url,
      params,
      config,
    });
  },

  post: ({ url, params, data = {}, config = {} }) => {
    return handleRequest({
      method: "POST",
      url,
      params,
      data,
      config,
    });
  },
  put: ({ url, params, data = {}, config = {} }) => {
    return handleRequest({
      method: "PUT",
      url,
      params,
      data,
      config,
    });
  },
  delete: ({ url, params, data = {}, config = {} }) => {
    return handleRequest({
      method: "DELETE",
      url,
      params,
      data,
      config,
    });
  },

  patch: ({ url, data = {}, config = {} }) => {
    return handleRequest({
      method: "PATCH",
      url,
      data,
      config,
    });
  },

  download: async ({ url, fileName }) => {
    try {
      const response = await handleRequest({
        method: "GET",
        url,
      });
      const objURL = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = objURL;
      const contentDisposition = response.headers["content-disposition"];
      let file = fileName;
      if (
        contentDisposition &&
        contentDisposition.indexOf("attachment") !== -1
      ) {
        const filenameRegex = /file[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
        const matches = filenameRegex.exec(contentDisposition);
        if (matches != null && matches[1]) {
          file = matches[1].replace(/['"]/g, "");
        }
      }
      link.setAttribute("download", file);
      document.body.appendChild(link);
      link.click();
    } catch (error) {
      return Promise.reject(error);
    }
  },
};

export default apiRequest;
