import ROUTE from "@routers/constants";
import { TOKEN_KEY, TOKEN_COOKIE, USER_INFO } from "@utils/constants";
import { rmCookie } from "@utils/cookie";
import history from "@utils/history";
import SessionStorageService from "@utils/storage/session";

const authService = {
  getToken: () => {
    return SessionStorageService.getItem(TOKEN_KEY);
  },

  getUserInfo: () => {
    return SessionStorageService.getItem(USER_INFO);
  },

  isAuthenticated: () => {
    return !!SessionStorageService.getItem(TOKEN_KEY);
  },

  logout: () => {
    rmCookie(TOKEN_COOKIE);
    rmCookie(TOKEN_KEY);
    SessionStorageService.clear();
    history.push(ROUTE.common.Login);
  },
};

export default authService;
