import { IcVay, IcWallet } from "@assets/icons"
import { IMGCardDefault } from "@assets/images"
import VPB_COLOR from '@ThemeProvider/colors'

export const ENV = import.meta.env.VITE_ENV;
export const VERSION = `v-${import.meta.env.VERSION}`;
export const NODE_ENV = import.meta.env.VITE_ENV;
export const ROOT_URI = import.meta.env.VITE_ROOT_URI;
export const ROOT_URI_IL = import.meta.env.VITE_ROOT_URI_IL;
export const ROOT_URI_JARVIS = import.meta.env.VITE_ROOT_URI_JARVIS;
export const KEY_GG_CAPTCHA = import.meta.env.VITE_SITE_KEY_GG_CAPCHA;
export const PATH = import.meta.env.VITE_PUBLIC_PATH;

export const COUNT_TIMEOUT = 3;
export const API_TIMEOUT = "150000";
export const RESTART_ON_REMOUNT = "@@saga-injector/restart-on-remount";
export const DAEMON = "@@saga-injector/daemon";
export const ONCE_TILL_UNMOUNT = "@@saga-injector/once-till-unmount";

export const TOKEN_KEY = "token";
export const USER_INFO = "user_info";
export const OTP_REQUEST = "otp_request";
export const REFERER_KEY = "vp-referrer";
export const STREAM_APPID = "streamAppId";
export const TOKEN_COOKIE = "Authorization";

export const TOKEN_SESSION = "__tk-session";
export const SUCCESS = "SUCCESS";

export const CALL_API_GET_DETAIL = "CALL_API_GET_DETAIL";
export const TOKEN_KEY_SESSION = "____fp-session-key";
export const KEY_BY_RECORD_FROM_MAIN = "____fp-key-number-oder";
export const REDIRECT_FROM_MAIN_HOST_KEY_SESSION = "____fp-check-redirect-host";

export const SDK_TS = {
  sdkVersion: "5.23.2",
  myCdnUrlPrefix: "https://vision-vnetwork-cdn.goevo.vn/",
};

export const typeImgOCR = {
  type: "image/jpeg",
};
export const typePdf = {
  type: "application/pdf",
};

export const DateFormat1 = 'DD/MM/YYYY';

export const PAGE_SIZE_ALL = 99999999;

export const responseCode = {
  "IL-200": "IL-200",
  "IL-4003": "IL-4003",
  "IL-4001": "IL-4001",
  "PARTNER-200": "PARTNER-200",
};

export const STATUS = {
  ACTIVE: "ACTIVE",
  INACTIVE: "INACTIVE",
};

export const PRODUCTS = {
  CC: {
    name: 'Thẻ tín dụng',
    icon: IMGCardDefault,
  },
  UPL: {
    name: 'Vay',
    icon: IcVay,
    subName: 'Vay tín chấp',
  },
  OD: {
    name: "Thấu chi",
    icon: IcWallet,
  },
  CASA: {
    name: "TKTT",
    icon: IcWallet,
  },
  NEO: {
    name: "VPBank NEO",
    icon: IcWallet,
  },
  null: {
    name: "Khác",
    icon: IcWallet,
  }
}

export const APPLICATION_STEP = {
  CONFIRM_APP: {
    step: 1,
    key: 'CONFIRM_APP',
    name: "Xác Nhận Hồ Sơ",
    note: 'Vui lòng xác nhận khởi tạo hồ sơ',
    statusAttr: {
      bg: VPB_COLOR.shade0,
      text: VPB_COLOR.neutral,
    },
    button:{
      name: 'Xác nhận khởi tạo',
    },
  },
  CHECK_APP: {
    step: 2,
    key: 'CHECK_APP',
    name: "Hoàn Thiện Hồ Sơ",
    note: 'Hồ sơ đang được hoàn thiện bởi nhân viên VPBank',
    statusAttr: {
      bg: VPB_COLOR.babyBlue,
      text: VPB_COLOR.blue,
    },
    button:{
      name: 'Chi tiết hồ sơ',
      attr: { variant: 'outlined' }
    },
  },
  BANK_APPROVED: {
    step: 3,
    key: 'BANK_APPROVED',
    name: "Ngân Hàng Phê Duyệt",
    note: 'Ngân hàng đang thực hiện phê duyệt, vui lòng chờ trong giây lát',
    statusAttr: {
      bg: VPB_COLOR.lightPastelYellow,
      text: VPB_COLOR.yellow,
    },
    button:{
      name: 'Chi tiết hồ sơ',
      attr: { variant: 'outlined' }
    },
  },
  E_CONTRACT: {
    step: 4,
    key: 'E_CONTRACT',
    name: "Ký Hợp Đồng",
    note: 'Hồ sơ của bạn đã được phê duyệt thành công, vui lòng ký hợp đồng điện tử',
    statusAttr: {
      bg: VPB_COLOR.babyBlue,
      text: VPB_COLOR.blue,
    },
    button:{
      name: 'Ký hợp đồng',
      attr: {}
    },
  },
  DISBURSEMENT: {
    step: 5,
    key: 'DISBURSEMENT',
    note: 'Hồ sơ của bạn đang được xử lý, vui lòng chờ trong giây lát',
    name_CC: "Đang Phát Hành Thẻ",
    name_UPL: "Đang Giải Ngân",
    name_OD: "Đang Giải Ngân",
    statusAttr: {
      bg: VPB_COLOR.babyBlue,
      text: VPB_COLOR.blue,
    },
    button:{
      name: 'Chi tiết hồ sơ',
      attr: { variant: 'outlined' }
    },
  },
  SHIPPING_CARD_SUCCESS: {
    step: 6,
    key: 'SHIPPING_CARD_SUCCESS',
    name: "Hành trình giao thẻ",
    note: 'Thẻ đang được giao đến bạn',
    statusAttr: {
      bg: VPB_COLOR.lightMint,
      text: VPB_COLOR.lightGreen,
    },
    button:{
      name: 'Chi tiết hồ sơ',
      attr: { variant: 'outlined' }
    },
  },
  CANCELED: {
    step: 7,
    key: 'CANCELED',
    name: "Từ Chối",
    note: 'Rất tiếc, hồ sơ của bạn đang bị từ chối bởi ngân hàng.',
    statusAttr: {
      bg: VPB_COLOR.softBlush,
      text: VPB_COLOR.red,
    },
    button:{
      name: 'Chi tiết hồ sơ',
      attr: { variant: 'outlined' }
    },
  },
  OTHER: {
    step: 8,
    name: "",
    note: 'KHÁC',
    key: 'OTHER',
    statusAttr: {
      bg: VPB_COLOR.softBlush,
      text: VPB_COLOR.red,
    },
    button:{
      name: 'Chi tiết hồ sơ',
      attr: { 
        variant: 'outlined', 
        style: { display: 'none' } 
      }
    },
  },
  E_CONTRACTED: {
    step: 9,
    name: "Đã ký hợp đồng",
    note: 'Bạn đã hoàn thành bước Ký hợp đồng, vui lòng chờ đợi Ngân hàng đang kiểm tra hồ sơ lần cuối trước khi tiến hành Phát hành thẻ/Giải ngân',
    key: 'E_CONTRACTED',
    statusAttr: {
      bg: VPB_COLOR.lightMint,
      text: VPB_COLOR.lightGreen,
    },
    button: {
      attr: {  style: { display: 'none' } }
    },
  },
}

export const STEPS_APPLICATION = {
  CC: [
    { label: "Xác nhận khởi tạo"},
    { label: "Hoàn thiện hồ sơ"},
    { label: "VPBank phê duyệt"},
    { label: "Ký hợp đồng"},
    { label: "Đang phát hành"},
    { label: "Hành trình giao thẻ"},
  ],
  UPL: [
    { label: "Xác nhận khởi tạo"},
    { label: "Hoàn thiện hồ sơ"},
    { label: "VPBank phê duyệt"},
    { label: "Ký hợp đồng"},
    { label: "Đang giải ngân"},
  ]
}

export const PACKAGE = {
  STANDARD: 'Gói Tiêu chuẩn',
  INQUIRY: 'Gói Cơ bản',
}