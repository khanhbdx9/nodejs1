// ".": Thông báo lỗi từ FE
// >= "..": Lỗi từ BE ko trả ra mes

export const MESSAGE_SYSTEM = {
  default: 'Lỗi hệ thống, không xác định', // lỗi chung
  FILE_NOTFOUND: 'Không tìm thấy file hợp đồng.',

  // Không trả ra message thông báo từ BE
  error_01: 'Đã xảy ra lỗi, xin vui lòng thử lại..', // res trả về code IL-200 nhưng screen trả về sai so với quy định hoặc không có.
  error_02: 'Cập nhật thông tin không thành công..', // res trả về khác code IL-200.
  error_03: 'Đã xảy ra lỗi, xin vui lòng thử lại...', // Lỗi không có appId
  // END Không trả ra message thông báo từ BE

  // API !== 200 và không có message
  notFound: 'Không lấy được thông tin',
  errorApp:'Có lỗi xảy ra. Vui lòng thử lại!',

  notFindAppId: 'Không tồn tại hồ sơ!',
  cccdError: "Thông tin CCCD không hợp lệ!",
  cccdRequired: "Vui lòng nhập thông tin!",
  phoneError: "Số điện thoại không hợp lệ!",
  phoneRequired: "Vui lòng nhập thông tin!",
  copySuccess: "Sao chép thành công!",
  notToken: "Đã hết phiên làm việc, vui lòng đăng nhập lại!",
  provice: 'Không lấy được danh sách tỉnh/thành phố',
  documentNotFound: "Không lấy được tài liệu, chứng từ",
  saveTemplateCard: "Lưu thành công",
  zalo: 'Không tìm thấy hồ sơ của bạn. Vui lòng thử lại sau!',
  rq: 'Vui lòng chọn thông tin!'
};
