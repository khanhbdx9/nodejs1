import { branchByProvinceCodeAction } from '@App/actions';
import { useReduxSameUseState } from '@utils/hooks/useRedux';
import KEY from '@utils/injectKey';
import { useEffect } from 'react';

const useBranchByProvinceCode = ({ provinceCode } = {}) => {
  const [branchOpt, fetchBranchByProvinceCode] = useReduxSameUseState(KEY.GLOBAL, 'branchOpt', branchByProvinceCodeAction);

  useEffect(() => {
    if (provinceCode) {
      fetchBranchByProvinceCode({ provinceCode });
    }
  }, [provinceCode]);

  return {
    branchOpt,
    fetchBranchByProvinceCode,
  };
};

export default useBranchByProvinceCode;
