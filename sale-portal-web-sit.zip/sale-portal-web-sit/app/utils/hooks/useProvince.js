import { listProvinceAction } from '@App/actions';
import useShallowEqualSelector from '@utils/hooks/useShallowEqualSelector';
import KEY from '@utils/injectKey';
import { useEffect } from 'react';
import { useDispatch } from 'react-redux';

const useProvince = ({ autoFetch = true } = {}) => {
  const dispatch = useDispatch();
  const { provinceOpt = [] } = useShallowEqualSelector(KEY.GLOBAL, ['provinceOpt']);

  const fetchProvince = () => dispatch(listProvinceAction());

  useEffect(() => {
    if (autoFetch) {
      fetchProvince();
    }
  }, [autoFetch]);

  return {
    provinceOpt,
    fetchProvince,
  };
};

export default useProvince;
