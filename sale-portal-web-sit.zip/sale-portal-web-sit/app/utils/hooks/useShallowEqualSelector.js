import { useSelector, shallowEqual } from 'react-redux';

/**
 * Creates a dynamic selector for selecting fields from state.
 * 
 * @param {string} key - The key in the state to access.
 * @param {Array} fields - Array of fields to retrieve from the state.
 * @returns {Function} - A selector function to be used with `useSelector`.
 */
function createDynamicSelector(key, fields) {
  return state => {
    const selectedFields = fields.reduce((acc, field) => {
      if (state[key] && state[key][field] !== undefined) {
        acc[field] = state[key][field];
      }
      return acc;
    }, {});

    return selectedFields;
  };
}

/**
 * Custom hook for useSelector with shallowEqual for optimized re-renders.
 * 
 * @param {string} key - The key in the state to access.
 * @param {Array} fields - Array of fields to retrieve from the state.
 * @returns {Object} The selected fields from the state.
 */
export default function useShallowEqualSelector(key, fields) {
  // Tạo dynamic selector từ createDynamicSelector
  const selector = createDynamicSelector(key, fields);

  // Sử dụng useSelector với shallowEqual để tối ưu hóa render
  return useSelector(selector, shallowEqual);
}
