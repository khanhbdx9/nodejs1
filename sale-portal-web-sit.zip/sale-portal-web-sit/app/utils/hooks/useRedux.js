import { useDispatch } from "react-redux";

import useShallowEqualSelector from "./useShallowEqualSelector";

/**
 * Hook dùng để gọi action redux.
 * Nhận vào một action creator và trả về hàm dispatch với tham số.
 *
 * @param {Function} func - action creator
 * @returns {Function} - function để dispatch action
 */
const useDispatchRedux = (func) => {
  const dispatch = useDispatch();

  const setValueModal = (...args) => {
    if (typeof func !== "function") return;
    dispatch(func(...args));
  };

  return setValueModal;
};

/**
 * Hook dùng để lấy một phần cụ thể của state trong redux store.
 *
 * @param {string} key - tên reducer trong store
 * @param {string} state - tên property trong reducer
 * @returns {*} - giá trị state tương ứng
 */
const useOneState = (key, state) => {
  const value = useShallowEqualSelector(key, [state]);
  return value[state];
};

/**
 * Hook kết hợp giữa đọc một giá trị từ redux và trả về hàm cập nhật giá trị đó.
 *
 * @param {string} key - tên reducer
 * @param {string} state - property trong reducer
 * @param {Function} func - action creator tương ứng
 * @returns {[any, Function]} - [giá trị, hàm dispatch]
 */
const useReduxSameUseState = (key, state, func) => {
  const setValue = useDispatchRedux(func);
  const value = useOneState(key, state);

  return [value, setValue];
};

export { useReduxSameUseState, useOneState, useDispatchRedux };
