import { OTP_REQUEST, TOKEN_KEY, TOKEN_SESSION, USER_INFO } from "../constants";

const SessionStorageService = {
  setItem: (key, value) => {
    try {
      const valueFormatted =
        typeof value === "string" ? value : JSON.stringify(value);
      sessionStorage.setItem(key, valueFormatted);
    } catch (error) {
      console.error("Lỗi khi lưu vào sessionStorage:", error);
    }
  },

  setToken: (key, value) => {
    try {
      sessionStorage.setItem(key, `Bearer ${value}`);
    } catch (error) {
      console.error("Lỗi khi lưu vào sessionStorage:", error);
    }
  },

  getItem: (key) => {
    const value = sessionStorage.getItem(key);
    if (!value) return null;
    try {
      return JSON.parse(value);
    } catch {
      return value;
    }
  },

  removeItem: (key) => {
    try {
      sessionStorage.removeItem(key);
    } catch (error) {
      console.error("Lỗi khi xóa dữ liệu từ sessionStorage:", error);
    }
  },

  clear: () => {
    try {
      sessionStorage.removeItem(TOKEN_KEY);
      sessionStorage.removeItem(USER_INFO);
      sessionStorage.removeItem(OTP_REQUEST);
      sessionStorage.removeItem(TOKEN_SESSION);
    } catch (error) {
      console.error("Lỗi khi xóa tất cả dữ liệu từ sessionStorage:", error);
    }
  },
};

export default SessionStorageService;
