import { setUserInfoAction } from "@App/actions";
import ROUTE from '@routers/constants';
import { TOKEN_SESSION, TOKEN_KEY } from "@utils/constants";
import history from '@utils/history';
import KEY from "@utils/injectKey";
import { MESSAGE_SYSTEM } from "@utils/message";
import authService from '@utils/services/authService'
import SessionStorageService from "@utils/storage/session";
import { toast } from "react-toastify";

import { store } from '../configureStore';

export const nextScreen = ({ screen }) => { };

export const redirectReEnter = type => { };

export const handleErrorSdkTS = ({ code = '' }) => {
  // https://ekyc.trustingsocial.com/sdks/Web-SDK#possible-error-objects
  // link check error TS result
  if (['no_permission'].includes(code)) {
    return history.push(ROUTE.common.GuidelineSettingCamera);
  }
  if (['not_supported'].includes(code)) {
    return history.push(ROUTE.common.ChangeDevice);
  }
};

export const redirectDOM = href => {
  window.location.href = href;
};

export const redirectListApplication = () => {
  const tokens = SessionStorageService.getItem(TOKEN_SESSION);
  const tokenListApp = tokens?.[KEY.LIST_APPLICATION];

  if (!tokenListApp) {
    toast.error(MESSAGE_SYSTEM.notToken);
    authService.logout();
    return;
  }

  store.dispatch(setUserInfoAction(authService.getUserInfo()));

  SessionStorageService.setItem(TOKEN_KEY, `Bearer ${tokenListApp}`);
  history.push(ROUTE.common.ListApplication);
}
