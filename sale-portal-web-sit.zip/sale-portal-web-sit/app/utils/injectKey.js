const KEY = {
  GLOBAL: "global",
  INIT_APPLICATION: "initApplication",
  LIST_APPLICATION: "listApplication",
  LOGIN: "login",
  OTP_INPUT: "otp_input",
  OTP: "otp",
  OTP_CONFIRM_APP_INIT: "OTPConfirmAppInit",
  OCR_FRONT: "ocrFront",
  OCR_BACK: "ocrBack",
  OCR_QR: "ocrQr",
  LIVENESS: "liveness",
  COMPLETE_APPLICATION: "completeApplication",
  BANK_APPROVAL: "bankApproval",
  ZALO: "ZALO",
  E_CONTRACT: "E_CONTRACT",
  DETAIL_APPLICATION: 'DETAIL_APPLICATION',
  DOWNGRADE_CARD: "downgradeCard",
  UPL_ECONTRACT: 'UPL_ECONTRACT'
};

export default KEY;
