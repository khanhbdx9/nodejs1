import MainLayout from "@layouts/MainLayout";
import ROUTE from '@routers/constants';
import authService from "@utils/services/authService";
import PropTypes from 'prop-types';
import { Route, Redirect } from 'react-router-dom';

const RouterInterceptor = ({ component: Component, ...rest }) => {
  const isAuthenticated = authService.isAuthenticated();

  return (
    <Route
      {...rest}
      render={props => {
        if (isAuthenticated) {
          return (
            <MainLayout>
              <Component {...props} />
            </MainLayout>
          );
        }
        return <Redirect to={ROUTE.common.Login} />;
      }}
    />
  );
};

RouterInterceptor.propTypes = {
  component: PropTypes.elementType.isRequired,
};

export default RouterInterceptor;
