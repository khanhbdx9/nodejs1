/* eslint-disable no-eval */
/* eslint-disable spaced-comment */
/* eslint-disable vars-on-top */
/* eslint-disable no-else-return */
/* eslint-disable no-underscore-dangle */
/* eslint-disable object-shorthand */
/* eslint-disable no-var */
/* eslint-disable func-names */
import { isIOS } from './helpers';

export const detectIncognito = function() {
  return new Promise(function(resolve, reject) {
    var browserName = 'Unknown';

    function __callback(isPrivate) {
      resolve({
        isPrivate: isPrivate,
        browserName: browserName,
      });
    }

    function identifyChromium() {
      var ua = navigator.userAgent;
      if (ua.match(/Chrome/)) {
        if (navigator.brave !== undefined) {
          return 'Brave';
        } else if (ua.match(/Edg/)) {
          return 'Edge';
        } else if (ua.match(/OPR/)) {
          return 'Opera';
        }
        return 'Chrome';
      } else {
        return 'Chromium';
      }
    }

    function assertEvalToString(value) {
      return value === eval.toString().length;
    }

    function isSafari() {
      // var v = navigator.vendor;
      // return (
      //   v !== undefined && v.indexOf('Apple') === 0 && assertEvalToString(37)
      // );
      const safari = /(Version\/)[1-9]/i.test(navigator.userAgent);
      return safari;
    }

    function isChrome() {
      if (isIOS()) {
        const safari = /(CriOS\/)[1-9]/i.test(navigator.userAgent);
        return safari;
      }
      var v = navigator.vendor;
      return (
        v !== undefined && v.indexOf('Google') === 0 && assertEvalToString(33)
      );
    }

    function isFirefox() {
      return (
        document.documentElement !== undefined &&
        document.documentElement.style.MozAppearance !== undefined &&
        assertEvalToString(37)
      );
    }

    function isMSIE() {
      return navigator.msSaveBlob !== undefined && assertEvalToString(39);
    }

    /**
     * Safari (Safari for iOS & macOS)
     **/

    function newSafariTest() {
      try {
        if (isIOS()) {
          return __callback(false);
        } else {
          var db = window.indexedDB.open('test', 1);
          db.onupgradeneeded = function(i) {
            var res = i.target.result;
            try {
              res
                .createObjectStore('test', {
                  autoIncrement: true,
                })
                .put(new Blob());
              __callback(false);
            } catch (e) {
              if (/BlobURLs are not yet supported/.test(e.message)) {
                __callback(true);
              } else {
                __callback(false);
              }
            }
          };
        }
      } catch (e) {
        __callback(false);
      }
    }

    function oldSafariTest() {
      var openDB = window.openDatabase;
      var storage = window.localStorage;
      try {
        openDB(null, null, null, null);
      } catch (e) {
        return __callback(true);
      }
      try {
        storage.setItem('test', '1');
        storage.removeItem('test');
      } catch (e) {
        return __callback(true);
      }
      return __callback(false);
    }

    function safariPrivateTest() {
      if (navigator.maxTouchPoints !== undefined) {
        newSafariTest();
      } else {
        oldSafariTest();
      }
    }

    /**
     * Chrome
     **/

    function getQuotaLimit() {
      var w = window;
      if (
        w.performance !== undefined &&
        w.performance.memory !== undefined &&
        w.performance.memory.jsHeapSizeLimit !== undefined
      ) {
        return performance.memory.jsHeapSizeLimit;
      }
      return 1073741824;
    }

    // >= 76
    function storageQuotaChromePrivateTest() {
      if (!navigator.webkitTemporaryStorage) {
        return __callback(false);
      }
      navigator.webkitTemporaryStorage.queryUsageAndQuota(
        function(usage, quota) {
          __callback(quota < getQuotaLimit());
        },
        function(e) {
          reject(
            new Error(
              `detectIncognito somehow failed to query storage quota: ${
                e.message
              }`,
            ),
          );
        },
      );
    }

    function chromePrivateTest() {
      // if (Promise !== undefined && Promise.allSettled !== undefined) {
      //   storageQuotaChromePrivateTest();
      // } else {
      //   oldChromePrivateTest();
      // }
      storageQuotaChromePrivateTest();
    }

    /**
     * Firefox
     **/

    function firefoxPrivateTest() {
      __callback(navigator.serviceWorker === undefined);
    }

    /**
     * MSIE
     **/

    function msiePrivateTest() {
      __callback(window.indexedDB === undefined);
    }

    function main() {
      if (isSafari()) {
        browserName = 'Safari';
        safariPrivateTest();
      } else if (isChrome()) {
        browserName = identifyChromium();
        chromePrivateTest();
      } else if (isFirefox()) {
        browserName = 'Firefox';
        firefoxPrivateTest();
      } else if (isMSIE()) {
        browserName = 'Internet Explorer';
        msiePrivateTest();
      } else {
        reject(new Error('detectIncognito cannot determine the browser'));
      }
    }

    main();
  });
};
