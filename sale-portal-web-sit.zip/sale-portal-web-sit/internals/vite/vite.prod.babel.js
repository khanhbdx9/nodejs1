import { createHtmlPlugin } from "vite-plugin-html";

export default {
  plugins: [
    createHtmlPlugin({
      minify: true,
      filename: "index.html",
      template: "app/index.html",
    }),
  ],
  build: {
    minify: "terser",
    sourcemap: false,
    cssCodeSplit: true, // Tách riêng CSS cho từng chunk
    cssMinify: true, // Tối ưu CSS nếu có
    terserOptions: {
      compress: {
        drop_console: true, // Bỏ console logs
      },
      output: {
        comments: false, // Bỏ bình luận trong mã nguồn
      },
    },
    assetsInclude: (file) => {
      // Chỉ bao gồm các file trong public, ngoại trừ thư mục "excluded-folder"
      if (file.includes('public/uat')) {
        return false; // Loại trừ thư mục này khỏi build
      }
      return true; // Bao gồm các file khác
    },
  },
};
