/* eslint-disable no-undef */
import { rename } from "fs";
import path from "path";
import { createHtmlPlugin } from "vite-plugin-html";

export default {
  plugins: [
    createHtmlPlugin({
      minify: true,
      filename: "index.html",
      template: "app/indexSit.html",
    }),
    {
      name: "rename-html",
      writeBundle: () => {
        rename(
          path.join(__dirname, "../../build/theo-doi-ho-so/app", "indexSit.html"),
          path.join(__dirname, "../../build/theo-doi-ho-so", "index.html"),
          (err) => {
            if (err) throw err;
            console.log("Đã đổi tên file HTML!");
          }
        );
      },
    },
  ],
  build: {
    minify: "terser",
    sourcemap: true,
  },
};
