/* eslint-disable no-undef */
import { rename } from "fs";
import path from "path";
import { createHtmlPlugin } from "vite-plugin-html";

export default {
  plugins: [
    createHtmlPlugin({
      minify: true,
      filename: "index.html",
      template: "app/indexUat.html",
    }),
    {
      name: "rename-html",
      writeBundle: () => {
        rename(
          path.join(__dirname, "../../build/theo-doi-ho-so/app", "indexUat.html"),
          path.join(__dirname, "../../build/theo-doi-ho-so", "index.html"),
          (err) => {
            if (err) throw err;
            console.log("Đã đổi tên file HTML!");
          }
        );
      },
    },
  ],
  build: {
    minify: "terser",
    sourcemap: true,
    cssCodeSplit: true, // Tách riêng CSS cho từng chunk
    cssMinify: true, // Tối ưu CSS nếu có
    terserOptions: {
      compress: {
        drop_console: false, // Bỏ console logs
      },
      output: {
        comments: false, // Bỏ bình luận trong mã nguồn
      },
    },
  },
};
