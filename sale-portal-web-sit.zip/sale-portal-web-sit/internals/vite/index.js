export { default as sit } from "./vite.sit.babel";
export { default as uat } from "./vite.uat.babel";
export { default as debug } from "./vite.debug.babel";
export { default as production } from "./vite.prod.babel";
