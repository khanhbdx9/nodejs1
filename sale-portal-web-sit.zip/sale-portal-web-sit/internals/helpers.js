import fs from "fs";
import { resolve } from "path";

export const createAliases = (baseDir) => {
  const aliases = {};
  const dirs = fs
    .readdirSync(baseDir)
    .filter((file) => fs.statSync(resolve(baseDir, file)).isDirectory());
  dirs.forEach((dir) => {
    aliases[`@${dir}`] = resolve(baseDir, dir);
  });
  return aliases;
};

export const getHash = () =>
  Math.random()
    .toString(36)
    .substring(2, 15) +
  Math.random()
    .toString(36)
    .substring(2, 15);