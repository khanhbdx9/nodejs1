import js from "@eslint/js";
import importPlugin from "eslint-plugin-import";
import react from "eslint-plugin-react";
import reactHooks from "eslint-plugin-react-hooks";
import reactRefresh from "eslint-plugin-react-refresh";
import globals from "globals";

export default [
  { ignores: ["dist"] }, // Ignores the 'dist' folder

  {
    files: ["**/*.{js,jsx}"], // Apply rules to JS and JSX files
    languageOptions: {
      ecmaVersion: 2020,
      globals: globals.browser,
      parserOptions: {
        ecmaVersion: "latest",
        ecmaFeatures: { jsx: true },
        sourceType: "module", // Enabling ES module imports
      },
    },
    settings: { react: { version: "detect" } }, // Automatically detects React version
    plugins: {
      react,
      import: importPlugin,
      "react-hooks": reactHooks,
      "react-refresh": reactRefresh, // For React fast refresh during dev
    },
    rules: {
      ...js.configs.recommended.rules,
      ...react.configs.recommended.rules,
      ...react.configs["jsx-runtime"].rules,
      ...reactHooks.configs.recommended.rules,

      // Custom rules
      "react/jsx-no-target-blank": "off", // Disabling target-blank warning
      "react/display-name": ["off"], // Turning off the display-name rule (for anonymous components)
      "react-hooks/exhaustive-deps": "off", // Disabling exhaustive deps check for hooks (might need this for performance)
      "react-refresh/only-export-components": [
        "warn",
        { allowConstantExport: true }, // Warn when components are not exported as constant
      ],

      // Import order rule
      "import/order": [
        "error",
        {
          groups: [
            ["builtin", "external"], // Order groups for modules
            ["internal"], 
            ["parent", "sibling", "index"]
          ],
          alphabetize: {
            order: "asc", // Alphabetize imports
            caseInsensitive: true, // Case-insensitive sorting
          },
          // Add a blank line between groups of imports
          "newlines-between": "always",
        },
      ],

      // Additional custom rules (optional)
      "no-console": "warn", // Warn on console statements
      "no-debugger": "warn", // Warn on debugger statements
      "no-unused-vars": "warn", // Warn on unused variables
    },
  },
];
